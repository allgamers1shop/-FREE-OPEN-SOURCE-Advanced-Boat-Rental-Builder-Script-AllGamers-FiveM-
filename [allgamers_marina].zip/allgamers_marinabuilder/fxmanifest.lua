fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'AllGamers'
description 'Modular Marina Builder, synchronized rental launches and ownable businesses'
version '1.0.0'

dependency '/onesync'

ui_page 'web/index.html'

shared_scripts {
    'config.lua',
    'shared/math.lua',
    'shared/assets.lua',
    'shared/rpc.lua',
}

client_scripts {
    'client/bridge.lua',
    'client/world.lua',
    'client/builder.lua',
    'client/dui.lua',
    'client/motion.lua',
    'client/audio.lua',
}

server_scripts {
    'server/bridge.lua',
    'server/core.lua',
    'server/business.lua',
    'server/rental.lua',
    'server/main.lua',
}

files {
    'data/asset_manifest.json',
    'data/snap_points.json',
    'data/animation_points.json',
    'data/assembled_layout.json',
    'stream/ff_marina_builder.ytyp',
    'web/index.html',
    'web/dui.html',
    'web/studio.css',
    'web/terminal.css',
    'web/studio.js',
    'web/terminal.js',
    'web/audio.js',
    'web/sounds/*.ogg',
    'web/assets/*.png',
    'web/assets/*.webp',
    'logo/*.png',
    'web/fonts/*.woff2',
}

data_file 'DLC_ITYP_REQUEST' 'stream/ff_marina_builder.ytyp'

escrow_ignore {
    'config.lua',
    'client/bridge.lua',
    'server/bridge.lua',
    'web/**',
    'data/**',
    'DOCS.md',
}
