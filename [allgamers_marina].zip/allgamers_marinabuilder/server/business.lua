-- ALLGAMERS MARINA BUSINESS
-- Ownable marina purchase, fleet, treasury, staff and settings.
MarinaBusiness = {}
local M = MarinaBusiness
local Config = MarinaConfig
local Bridge = MarinaServerBridge
local Core = MarinaCore
local Math = MarinaMath

local function fail(message, code)
    return Core.fail(message, code)
end

local function identityOf(source)
    return Bridge.getIdentifier(source)
end

local function findOnlineByIdentity(identity)
    if not identity then return nil end
    for _, id in ipairs(GetPlayers()) do
        local src = tonumber(id)
        if src and Bridge.getIdentifier(src) == identity then return src end
    end
end

local function findOnlineByServerId(target)
    target = math.floor(tonumber(target) or 0)
    if target < 1 then return nil end
    if GetPlayerName(target) then return target end
end

local function fleetTotal(marina)
    local total = 0
    for _, row in pairs(marina.fleet or {}) do
        total = total + (tonumber(row.stock) or 0)
    end
    return total
end

local function buildFleetView(marina)
    local list = {}
    for _, def in ipairs(Config.vehicles or {}) do
        local row = marina.fleet[def.id] or { stock = 0, available = 0, rented = 0, maintenance = 0, enabled = true }
        list[#list + 1] = {
            id = def.id,
            label = def.label,
            price = Core.vehiclePrice(marina, def.id),
            purchasePrice = math.floor(tonumber(def.purchasePrice) or 0),
            available = row.available or 0,
            rented = row.rented or 0,
            maintenance = row.maintenance or 0,
            stock = row.stock or 0,
            enabled = Core.isVehicleEnabled(marina, def.id),
        }
    end
    return list
end

local function buildEmployees(marina)
    local list = {}
    for _, employee in ipairs(marina.employees or {}) do
        list[#list + 1] = {
            identity = employee.identity,
            name = employee.name or employee.identity,
            role = employee.role == 'manager' and 'manager' or 'staff',
            online = findOnlineByIdentity(employee.identity) ~= nil,
        }
    end
    return list
end

local function buildBusiness(source, marina)
    local identity = identityOf(source)
    local role = Core.roleFor(identity, marina)
    if not role and Bridge.isAdmin(source) then
        -- Admins can inspect but do not get owner powers unless they own it.
        return nil
    end
    if not role then return nil end

    return {
        role = role,
        balance = marina.balance or 0,
        earnings = marina.earnings or 0,
        rentalCount = marina.rentalCount or 0,
        canEdit = role == 'owner' or role == 'manager',
        owner = {
            isYou = marina.owner == identity,
            identity = marina.owner,
        },
        fleet = buildFleetView(marina),
        employees = buildEmployees(marina),
        history = marina.history or {},
    }
end

local function catalogFor(marina, station)
    local list = {}
    for _, def in ipairs(Config.vehicles or {}) do
        if def.kind == station.kind then
            local row = marina.fleet[def.id] or { stock = 0, available = 0, rented = 0, maintenance = 0, enabled = true }
            local available = row.available or 0
            if marina.mode == 'public' then
                available = math.max(available, 0)
            end
            list[#list + 1] = {
                id = def.id,
                label = def.label,
                price = Core.vehiclePrice(marina, def.id),
                deposit = math.floor(tonumber(def.deposit) or 0),
                image = def.image,
                available = available,
                stock = row.stock or 0,
                enabled = Core.isVehicleEnabled(marina, def.id),
            }
        end
    end
    return list
end

function M.menu(source, payload)
    local marina = Core.get(payload and payload.marinaId)
    if not marina then return fail('Marina not found.') end
    local station = Core.findStation(marina, payload and payload.stationId)
    if not station or station.enabled == false then return fail('Launch bay not found.') end

    local identity = identityOf(source)
    local role = Core.roleFor(identity, marina)
    local canBuy = marina.mode == 'ownable' and not marina.owner and role == nil
    local canBuild = Core.canEditLayout(source, marina)
    local rental = MarinaRental and MarinaRental.personal(source) or false

    return {
        ok = true,
        marina = {
            id = marina.id,
            name = marina.name,
            mode = marina.mode,
            purchasePrice = marina.purchasePrice,
        },
        station = {
            id = station.id,
            kind = station.kind,
        },
        catalog = catalogFor(marina, station),
        plans = Config.plans,
        accounts = Core.accountBalances(source),
        rental = rental or false,
        canBuy = canBuy,
        canBuild = canBuild,
        business = buildBusiness(source, marina),
    }
end

function M.buy(source, payload)
    local marina = Core.get(payload and payload.marinaId)
    if not marina then return fail('Marina not found.') end
    if marina.mode ~= 'ownable' then return fail('This marina is not for sale.') end
    if marina.owner then return fail('This marina is already owned.') end

    local identity = identityOf(source)
    if not identity then return fail('Character is not ready yet.') end
    if Core.roleFor(identity, marina) then return fail('Employees cannot purchase this marina.') end

    local account = payload.account == 'cash' and 'cash' or 'bank'
    local price = math.floor(tonumber(marina.purchasePrice) or Config.business.defaultPurchasePrice)
    if price < 0 or price > Config.limits.maxPrice then return fail('Invalid purchase price.') end
    if not Bridge.removeMoney(source, account, price) then
        return fail('Insufficient funds.')
    end

    marina.owner = identity
    marina.balance = 0
    marina.earnings = 0
    marina.employees = {}
    Core.pushHistory(marina, 'purchase', -price, 'Business purchase', identity)
    Core.persist()
    Core.sync()
    return { ok = true }
end

local function requireRole(source, marina, allowed)
    local identity = identityOf(source)
    local role = Core.roleFor(identity, marina)
    if Bridge.isAdmin(source) and not role then
        -- Admins without ownership cannot mutate business funds.
        return nil, fail('Business access required.')
    end
    if not role then return nil, fail('Business access required.') end
    for _, name in ipairs(allowed) do
        if role == name then return role, identity end
    end
    return nil, fail('You do not have permission for that.')
end

local function fleetBuy(source, marina, payload)
    local role, identity = requireRole(source, marina, { 'owner', 'manager' })
    if not role then return identity end -- identity holds fail result

    local def = MarinaAssets.vehicle(payload.vehicleId)
    if not def then return fail('Unknown vessel.') end
    local count = math.max(1, math.floor(tonumber(payload.count) or 1))
    if fleetTotal(marina) + count > (Config.limits.maxFleet or 50) then
        return fail('Fleet capacity reached.')
    end

    local cost = math.floor((tonumber(def.purchasePrice) or 0) * count)
    if cost <= 0 then return fail('Invalid vessel cost.') end
    if (marina.balance or 0) < cost then return fail('Business balance is too low.') end

    marina.balance = marina.balance - cost
    local row = marina.fleet[def.id]
    row.stock = (row.stock or 0) + count
    row.available = (row.available or 0) + count
    Core.pushHistory(marina, 'fleet_buy', -cost, ('Bought %sx %s'):format(count, def.label), identity)
    Core.persist()
    return { ok = true }
end

local function fleetRepair(source, marina, payload)
    local role, identityOrFail = requireRole(source, marina, { 'owner', 'manager', 'staff' })
    if not role then return identityOrFail end

    local def = MarinaAssets.vehicle(payload.vehicleId)
    if not def then return fail('Unknown vessel.') end
    local row = marina.fleet[def.id]
    local count = math.max(1, math.floor(tonumber(payload.count) or 1))
    if (row.maintenance or 0) < count then return fail('No vessels need repair.') end

    local cost = math.floor((tonumber(Config.rental.repairCost) or 1000) * count)
    if (marina.balance or 0) < cost then return fail('Business balance is too low.') end

    marina.balance = marina.balance - cost
    row.maintenance = row.maintenance - count
    row.available = (row.available or 0) + count
    Core.pushHistory(marina, 'fleet_repair', -cost, ('Repaired %sx %s'):format(count, def.label), identityOrFail)
    Core.persist()
    return { ok = true }
end

local function fleetRefuel(source, marina, payload)
    local role, identityOrFail = requireRole(source, marina, { 'owner', 'manager', 'staff' })
    if not role then return identityOrFail end

    local def = MarinaAssets.vehicle(payload.vehicleId)
    if not def then return fail('Unknown vessel.') end
    local row = marina.fleet[def.id]
    local count = math.max(1, math.floor(tonumber(payload.count) or 1))
    -- Refuel moves a unit from maintenance (or keeps available); if no maintenance, charge upkeep on available.
    if (row.maintenance or 0) >= count then
        local cost = math.floor((tonumber(Config.rental.refuelCost) or 200) * count)
        if (marina.balance or 0) < cost then return fail('Business balance is too low.') end
        marina.balance = marina.balance - cost
        row.maintenance = row.maintenance - count
        row.available = (row.available or 0) + count
        Core.pushHistory(marina, 'fleet_refuel', -cost, ('Refueled %sx %s'):format(count, def.label), identityOrFail)
        Core.persist()
        return { ok = true }
    end

    if (row.available or 0) < 1 then return fail('No vessel available to refuel.') end
    local cost = math.floor(tonumber(Config.rental.refuelCost) or 200)
    if (marina.balance or 0) < cost then return fail('Business balance is too low.') end
    marina.balance = marina.balance - cost
    Core.pushHistory(marina, 'fleet_refuel', -cost, ('Refueled %s'):format(def.label), identityOrFail)
    Core.persist()
    return { ok = true }
end

local function settings(source, marina, payload)
    local role, identityOrFail = requireRole(source, marina, { 'owner', 'manager' })
    if not role then return identityOrFail end

    if type(payload.prices) == 'table' then
        for vehicleId, price in pairs(payload.prices) do
            if MarinaAssets.vehicle(vehicleId) then
                marina.prices[vehicleId] = math.floor(Math.clamp(tonumber(price) or 0, 0, Config.limits.maxPrice))
            end
        end
    end

    if type(payload.enabled) == 'table' then
        for vehicleId, enabled in pairs(payload.enabled) do
            if MarinaAssets.vehicle(vehicleId) then
                local on = enabled == true or enabled == 'true'
                marina.enabled[vehicleId] = on
                if marina.fleet[vehicleId] then marina.fleet[vehicleId].enabled = on end
            end
        end
    end

    if type(payload.name) == 'string' then
        local name = payload.name:gsub('^%s*(.-)%s*$', '%1')
        if name == '' then return fail('Name cannot be empty.') end
        marina.name = name:sub(1, 48)
        Core.sync()
    end

    Core.persist()
    return { ok = true }
end

local function deposit(source, marina, payload)
    local role, identityOrFail = requireRole(source, marina, { 'owner', 'manager' })
    if not role then return identityOrFail end

    local amount = math.floor(tonumber(payload.amount) or 0)
    if amount < 1 or amount > Config.limits.maxPrice then return fail('Invalid amount.') end
    local account = payload.account == 'cash' and 'cash' or 'bank'
    if not Bridge.removeMoney(source, account, amount) then return fail('Insufficient funds.') end

    marina.balance = (marina.balance or 0) + amount
    Core.pushHistory(marina, 'deposit', amount, 'Owner deposit', identityOrFail)
    Core.persist()
    return { ok = true }
end

local function withdraw(source, marina, payload)
    local role, identityOrFail = requireRole(source, marina, { 'owner' })
    if not role then return identityOrFail end
    if marina.owner ~= identityOrFail then return fail('Only the owner can withdraw.') end

    local amount = math.floor(tonumber(payload.amount) or 0)
    if amount < 1 or amount > Config.limits.maxPrice then return fail('Invalid amount.') end
    if (marina.balance or 0) < amount then return fail('Business balance is too low.') end

    local account = payload.account == 'cash' and 'cash' or 'bank'
    marina.balance = marina.balance - amount
    if not Bridge.addMoney(source, account, amount) then
        marina.balance = marina.balance + amount
        return fail('Could not credit your account.')
    end
    Core.pushHistory(marina, 'withdraw', -amount, 'Owner withdrawal', identityOrFail)
    Core.persist()
    return { ok = true }
end

local function employeeAdd(source, marina, payload)
    local role, identityOrFail = requireRole(source, marina, { 'owner', 'manager' })
    if not role then return identityOrFail end

    local hireRole = payload.role == 'manager' and 'manager' or 'staff'
    if hireRole == 'manager' and role ~= 'owner' then
        return fail('Only the owner can hire managers.')
    end

    local target = findOnlineByServerId(payload.target)
    if not target then return fail('Player is not online.') end
    local targetIdentity = identityOf(target)
    if not targetIdentity then return fail('That player is not ready yet.') end
    if targetIdentity == marina.owner then return fail('The owner is already on the team.') end

    for _, employee in ipairs(marina.employees or {}) do
        if employee.identity == targetIdentity then return fail('That player is already employed.') end
    end
    if #(marina.employees or {}) >= (Config.limits.maxEmployees or 20) then
        return fail('Employee limit reached.')
    end

    marina.employees[#marina.employees + 1] = {
        identity = targetIdentity,
        name = Bridge.getName(target),
        role = hireRole,
    }
    Core.pushHistory(marina, 'employee_add', 0, ('Hired %s as %s'):format(Bridge.getName(target), hireRole), identityOrFail)
    Core.persist()
    Core.sync(target)
    return { ok = true }
end

local function employeeRemove(source, marina, payload)
    local role, identityOrFail = requireRole(source, marina, { 'owner', 'manager' })
    if not role then return identityOrFail end

    local targetIdentity = tostring(payload.identity or '')
    if targetIdentity == '' then return fail('Missing employee.') end

    local removed
    local nextList = {}
    for _, employee in ipairs(marina.employees or {}) do
        if employee.identity == targetIdentity then
            if employee.role == 'manager' and role ~= 'owner' then
                return fail('Only the owner can remove managers.')
            end
            removed = employee
        else
            nextList[#nextList + 1] = employee
        end
    end
    if not removed then return fail('Employee not found.') end

    marina.employees = nextList
    Core.pushHistory(marina, 'employee_remove', 0, ('Removed %s'):format(removed.name or targetIdentity), identityOrFail)
    Core.persist()
    local online = findOnlineByIdentity(targetIdentity)
    if online then Core.sync(online) end
    return { ok = true }
end

local function transfer(source, marina, payload)
    local role, identityOrFail = requireRole(source, marina, { 'owner' })
    if not role then return identityOrFail end
    if MarinaRental and MarinaRental.hasActiveAtMarina(marina.id) then
        return fail('Finish active rentals before transferring ownership.')
    end

    local target = findOnlineByServerId(payload.target)
    if not target then return fail('Player is not online.') end
    local targetIdentity = identityOf(target)
    if not targetIdentity then return fail('That player is not ready yet.') end
    if targetIdentity == marina.owner then return fail('You already own this marina.') end

    marina.owner = targetIdentity
    -- Previous owner employees list kept; strip new owner if listed.
    local nextList = {}
    for _, employee in ipairs(marina.employees or {}) do
        if employee.identity ~= targetIdentity then nextList[#nextList + 1] = employee end
    end
    marina.employees = nextList
    Core.pushHistory(marina, 'transfer', 0, ('Transferred to %s'):format(Bridge.getName(target)), identityOrFail)
    Core.persist()
    Core.sync()
    return { ok = true }
end

local function sell(source, marina, payload)
    local role, identityOrFail = requireRole(source, marina, { 'owner' })
    if not role then return identityOrFail end
    if MarinaRental and MarinaRental.hasActiveAtMarina(marina.id) then
        return fail('Finish active rentals before selling.')
    end

    local account = payload.account == 'cash' and 'cash' or 'bank'
    local payout = math.floor((tonumber(marina.purchasePrice) or 0) * (tonumber(Config.business.sellBackFraction) or 0.5))
    local balance = math.floor(tonumber(marina.balance) or 0)
    local total = payout + balance

    marina.owner = nil
    marina.balance = 0
    marina.employees = {}
    for _, def in ipairs(Config.vehicles or {}) do
        marina.fleet[def.id] = { stock = 0, available = 0, rented = 0, maintenance = 0, enabled = true }
    end
    Core.pushHistory(marina, 'sell', total, 'Business sold back', identityOrFail)

    if total > 0 and not Bridge.addMoney(source, account, total) then
        -- Extremely rare; keep history but warn.
        print(('[allgamers_marinabuilder] sell payout failed for src=%s amount=%s'):format(source, total))
    end

    Core.persist()
    Core.sync()
    return { ok = true }
end

function M.handle(source, payload)
    local marina = Core.get(payload and payload.marinaId)
    if not marina then return fail('Marina not found.') end
    if marina.mode ~= 'ownable' or not marina.owner then
        return fail('No business is attached to this marina.')
    end

    local operation = tostring(payload.operation or '')
    if operation == 'fleetBuy' then return fleetBuy(source, marina, payload) end
    if operation == 'fleetRepair' then return fleetRepair(source, marina, payload) end
    if operation == 'fleetRefuel' then return fleetRefuel(source, marina, payload) end
    if operation == 'settings' then return settings(source, marina, payload) end
    if operation == 'deposit' then return deposit(source, marina, payload) end
    if operation == 'withdraw' then return withdraw(source, marina, payload) end
    if operation == 'employeeAdd' then return employeeAdd(source, marina, payload) end
    if operation == 'employeeRemove' then return employeeRemove(source, marina, payload) end
    if operation == 'transfer' then return transfer(source, marina, payload) end
    if operation == 'sell' then return sell(source, marina, payload) end
    return fail('Unknown business operation.')
end

function M.creditRental(marina, fee, identity, vehicleLabel)
    if not marina or marina.mode ~= 'ownable' or not marina.owner then return end
    local share = math.floor((tonumber(fee) or 0) * (tonumber(Config.business.ownerShare) or 1.0))
    if share <= 0 then return end
    marina.balance = (marina.balance or 0) + share
    marina.earnings = (marina.earnings or 0) + share
    marina.rentalCount = (marina.rentalCount or 0) + 1
    Core.pushHistory(marina, 'rental', share, vehicleLabel and ('Rental · ' .. vehicleLabel) or 'Rental income', identity)
end
