-- ALLGAMERS SERVER BRIDGE
-- The only server file to touch for integrations. config.lua picks what is used:
--   framework = 'auto' | 'qbx' | 'qb' | 'esx' | 'standalone' | 'custom'
--   keys      = 'auto' | 'qbx' | 'qb' | 'none' | 'custom'
-- Built-in choices need no edits. Choose 'custom' and fill in the CUSTOM block below.
MarinaServerBridge = {}
local M, Config = MarinaServerBridge, MarinaConfig

-------------------------------------------------------------------------------
-- CUSTOM: your own framework identity, money and vehicle keys. Used only with 'custom'.
-------------------------------------------------------------------------------
local Custom = {}

function Custom.getIdentifier(source)
    return nil
end

function Custom.getBalances(source)
    return { cash = 0, bank = 0 }
end

function Custom.removeMoney(source, account, amount)
    return false
end

function Custom.addMoney(source, account, amount)
    return false
end

function Custom.giveKeys(source, vehicle, plate)
end

function Custom.removeKeys(source, vehicle, plate)
end

function Custom.getName(source)
    return GetPlayerName(source) or ('Player %s'):format(source)
end

function Custom.isAdmin(source)
    return false
end

-------------------------------------------------------------------------------
-- Built-in behaviour. Nothing below needs changes.
-------------------------------------------------------------------------------
local function resourceStarted(name)
    return GetResourceState(name) == 'started'
end

local function resolveFramework()
    local mode = Config.framework
    if mode == 'custom' then return 'custom' end
    if mode == 'auto' then
        if resourceStarted('qbx_core') then return 'qbx' end
        if resourceStarted('qb-core') then return 'qb' end
        if resourceStarted('es_extended') then return 'esx' end
        return 'standalone'
    end
    return mode
end

local function resolveKeys()
    local mode = Config.keys
    if mode == 'custom' then return 'custom' end
    if mode == 'auto' then
        if resourceStarted('qbx_vehiclekeys') then return 'qbx' end
        if resourceStarted('qb-vehiclekeys') then return 'qb' end
        return 'none'
    end
    return mode
end

local framework = resolveFramework()
local QBCore, ESX

if framework == 'qbx' or framework == 'qb' then
    local ok, core = pcall(function()
        return exports['qb-core']:GetCoreObject()
    end)
    if ok then QBCore = core end
end

if framework == 'esx' then
    local ok, obj = pcall(function()
        return exports['es_extended']:getSharedObject()
    end)
    if ok then ESX = obj end
end

local function currentKeysMode()
    return resolveKeys()
end

local function trimPlate(plate)
    if not plate then return nil end
    plate = tostring(plate):match('^%s*(.-)%s*$')
    if not plate or plate == '' then return nil end
    return string.upper(plate)
end

local function standaloneBucket(license)
    local key = ('standalone:%s'):format(license)
    local raw = GetResourceKvpString(key)
    if raw and raw ~= '' then
        local ok, data = pcall(json.decode, raw)
        if ok and type(data) == 'table' then return data end
    end
    local start = Config.standalone or {}
    return {
        cash = tonumber(start.startingCash) or 10000,
        bank = tonumber(start.startingBank) or 100000,
    }
end

local function saveStandaloneBucket(license, data)
    SetResourceKvp(('standalone:%s'):format(license), json.encode(data))
end

local function playerLicense(source)
    for i = 0, GetNumPlayerIdentifiers(source) - 1 do
        local id = GetPlayerIdentifier(source, i)
        if id and id:find('license:') == 1 then return id end
    end
    return ('src:%s'):format(source)
end

function M.getIdentifier(source)
    if framework == 'custom' then return Custom.getIdentifier(source) end

    if framework == 'qbx' or framework == 'qb' then
        if not QBCore then return nil end
        local player = QBCore.Functions.GetPlayer(source)
        if not player then return nil end
        return player.PlayerData.citizenid
    end

    if framework == 'esx' then
        if not ESX then return nil end
        local player = ESX.GetPlayerFromId(source)
        if not player then return nil end
        return player.getIdentifier()
    end

    return playerLicense(source)
end

function M.getName(source)
    if framework == 'custom' then return Custom.getName(source) end

    if framework == 'qbx' or framework == 'qb' then
        local player = QBCore and QBCore.Functions.GetPlayer(source)
        if player then
            local info = player.PlayerData.charinfo or {}
            local first = info.firstname or ''
            local last = info.lastname or ''
            local full = (first .. ' ' .. last):gsub('^%s*(.-)%s*$', '%1')
            if full ~= '' then return full end
        end
    elseif framework == 'esx' then
        local player = ESX and ESX.GetPlayerFromId(source)
        if player then
            local name = player.getName and player.getName() or nil
            if name and name ~= '' then return name end
        end
    end

    return GetPlayerName(source) or ('Player %s'):format(source)
end

function M.getBalances(source)
    if framework == 'custom' then return Custom.getBalances(source) end

    if framework == 'qbx' or framework == 'qb' then
        local player = QBCore and QBCore.Functions.GetPlayer(source)
        if not player then return { cash = 0, bank = 0 } end
        local money = player.PlayerData.money or {}
        return {
            cash = tonumber(money.cash) or 0,
            bank = tonumber(money.bank) or 0,
        }
    end

    if framework == 'esx' then
        local player = ESX and ESX.GetPlayerFromId(source)
        if not player then return { cash = 0, bank = 0 } end
        local cash = player.getAccount('money')
        local bank = player.getAccount('bank')
        return {
            cash = cash and cash.money or 0,
            bank = bank and bank.money or 0,
        }
    end

    local bucket = standaloneBucket(playerLicense(source))
    return {
        cash = tonumber(bucket.cash) or 0,
        bank = tonumber(bucket.bank) or 0,
    }
end

function M.removeMoney(source, account, amount)
    amount = math.floor(tonumber(amount) or 0)
    if amount <= 0 then return true end
    account = account == 'bank' and 'bank' or 'cash'

    if framework == 'custom' then
        return Custom.removeMoney(source, account, amount) == true
    end

    if framework == 'qbx' or framework == 'qb' then
        local player = QBCore and QBCore.Functions.GetPlayer(source)
        if not player then return false end
        local balance = player.Functions.GetMoney(account)
        if not balance or balance < amount then return false end
        player.Functions.RemoveMoney(account, amount, 'marina-rental')
        return true
    end

    if framework == 'esx' then
        local player = ESX and ESX.GetPlayerFromId(source)
        if not player then return false end
        local esxAccount = account == 'cash' and 'money' or 'bank'
        local bal = player.getAccount(esxAccount)
        if not bal or bal.money < amount then return false end
        player.removeAccountMoney(esxAccount, amount)
        return true
    end

    local license = playerLicense(source)
    local bucket = standaloneBucket(license)
    if (tonumber(bucket[account]) or 0) < amount then return false end
    bucket[account] = (tonumber(bucket[account]) or 0) - amount
    saveStandaloneBucket(license, bucket)
    return true
end

function M.addMoney(source, account, amount)
    amount = math.floor(tonumber(amount) or 0)
    if amount <= 0 then return true end
    account = account == 'bank' and 'bank' or 'cash'

    if framework == 'custom' then
        return Custom.addMoney(source, account, amount) == true
    end

    if framework == 'qbx' or framework == 'qb' then
        local player = QBCore and QBCore.Functions.GetPlayer(source)
        if not player then return false end
        player.Functions.AddMoney(account, amount, 'marina-refund')
        return true
    end

    if framework == 'esx' then
        local player = ESX and ESX.GetPlayerFromId(source)
        if not player then return false end
        local esxAccount = account == 'cash' and 'money' or 'bank'
        player.addAccountMoney(esxAccount, amount)
        return true
    end

    local license = playerLicense(source)
    local bucket = standaloneBucket(license)
    bucket[account] = (tonumber(bucket[account]) or 0) + amount
    saveStandaloneBucket(license, bucket)
    return true
end

function M.giveKeys(source, vehicle, plate)
    local mode = currentKeysMode()
    plate = trimPlate(plate)
    if (not plate or plate == '') and vehicle and vehicle ~= 0 and DoesEntityExist(vehicle) then
        plate = trimPlate(GetVehicleNumberPlateText(vehicle))
    end
    if not plate or plate == '' then return end

    local netId = nil
    if vehicle and vehicle ~= 0 and DoesEntityExist(vehicle) then
        SetVehicleNumberPlateText(vehicle, plate)
        SetVehicleDoorsLocked(vehicle, 1)
        netId = NetworkGetNetworkIdFromEntity(vehicle)
    end

    if mode == 'none' then return end
    if mode == 'custom' then
        Custom.giveKeys(source, vehicle, plate)
        return
    end
    if mode == 'qbx' and resourceStarted('qbx_vehiclekeys') then
        pcall(function()
            exports.qbx_vehiclekeys:GiveKeys(source, vehicle)
        end)
        return
    end
    if resourceStarted('qb-vehiclekeys') then
        pcall(function()
            exports['qb-vehiclekeys']:GiveKeys(source, plate)
        end)
        if netId then
            TriggerClientEvent('vehiclekeys:client:SetOwner', source, plate)
        end
        return
    end
end

function M.removeKeys(source, vehicle, plate)
    local mode = currentKeysMode()
    plate = trimPlate(plate)
    if (not plate or plate == '') and vehicle and vehicle ~= 0 and DoesEntityExist(vehicle) then
        plate = trimPlate(GetVehicleNumberPlateText(vehicle))
    end
    if not plate or plate == '' then return end

    if mode == 'none' then return end
    if mode == 'custom' then
        Custom.removeKeys(source, vehicle, plate)
        return
    end
    if mode == 'qbx' and resourceStarted('qbx_vehiclekeys') then
        pcall(function()
            exports.qbx_vehiclekeys:RemoveKeys(source, vehicle)
        end)
        return
    end
    if resourceStarted('qb-vehiclekeys') then
        pcall(function()
            exports['qb-vehiclekeys']:RemoveKeys(source, plate)
        end)
        TriggerClientEvent('qb-vehiclekeys:client:RemoveKeys', source, plate)
    end
end

local function playerHasGroup(source, groupName)
    if not groupName or groupName == '' then return false end
    local clean = groupName:gsub('^group%.', '')

    if framework == 'qbx' or framework == 'qb' then
        local player = QBCore and QBCore.Functions.GetPlayer(source)
        if not player then return false end
        local perms = player.PlayerData.permission or player.PlayerData.group
        if type(perms) == 'string' then
            return perms == clean or perms == groupName or perms == 'admin' or perms == 'god'
        end
        if type(perms) == 'table' then
            if perms[clean] or perms[groupName] or perms.admin or perms.god then return true end
        end
        if QBCore.Functions.HasPermission then
            local ok, allowed = pcall(QBCore.Functions.HasPermission, source, clean)
            if ok and allowed then return true end
            ok, allowed = pcall(QBCore.Functions.HasPermission, source, 'admin')
            if ok and allowed then return true end
        end
    elseif framework == 'esx' then
        local player = ESX and ESX.GetPlayerFromId(source)
        if player and player.getGroup then
            local g = player.getGroup()
            if g == clean or g == groupName or g == 'admin' or g == 'superadmin' then return true end
        end
    end

    return IsPlayerAceAllowed(source, groupName) or IsPlayerAceAllowed(source, clean)
end

function M.isAdmin(source)
    if framework == 'custom' then
        if Custom.isAdmin(source) then return true end
    end
    if Config.adminAce and IsPlayerAceAllowed(source, Config.adminAce) then return true end
    if IsPlayerAceAllowed(source, 'command') then return true end
    for _, group in ipairs(Config.adminGroups or {}) do
        if playerHasGroup(source, group) then return true end
    end
    return false
end

function M.framework()
    return framework
end

function M.keysMode()
    return currentKeysMode()
end

print(('[allgamers_marinabuilder] bridge ready · framework=%s · keys=%s'):format(framework, currentKeysMode()))
