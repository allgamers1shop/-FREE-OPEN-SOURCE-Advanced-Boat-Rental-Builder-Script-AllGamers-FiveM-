-- ALLGAMERS MARINA RENTAL
-- Vessel spawn, launch / return phases, deposits and travel broadcasts.
MarinaRental = {}
local M = MarinaRental
local Config = MarinaConfig
local Bridge = MarinaServerBridge
local Core = MarinaCore
local Math = MarinaMath
local resource = GetCurrentResourceName()

local rentalsById = {}
local rentalsBySource = {}
local travels = {} -- key marinaId:stationId -> travel
local stationBusy = {} -- station key -> rentalId
local RENTALS_FILE = 'rentals.json'

local function fail(message, code)
    return Core.fail(message, code)
end

local function stationKey(marinaId, stationId)
    return tostring(marinaId) .. ':' .. tostring(stationId)
end

local function nowMs()
    return Core.nowMs()
end

local function findPlan(planId)
    for _, plan in ipairs(Config.plans or {}) do
        if plan.id == planId then return plan end
    end
end

local function makePlate()
    local chars = 'ABCDEFGHJKLMNPRSTUVWXYZ0123456789'
    local plate = 'AG'
    for _ = 1, 6 do
        local index = math.random(1, #chars)
        plate = plate .. chars:sub(index, index)
    end
    return plate
end

local function publicRental(rental)
    if not rental then return false end
    return {
        id = rental.id,
        marinaId = rental.marinaId,
        stationId = rental.stationId,
        returnStationId = rental.returnStationId,
        vehicleId = rental.vehicleId,
        plate = rental.plate,
        netId = rental.netId,
        phase = rental.phase,
        expiresAt = rental.expiresAt,
        deposit = rental.deposit,
        planId = rental.planId,
        fee = rental.fee,
        account = rental.account,
    }
end

local function persistRentals()
    local list = {}
    for _, rental in pairs(rentalsById) do
        list[#list + 1] = {
            id = rental.id,
            identifier = rental.identifier,
            marinaId = rental.marinaId,
            stationId = rental.stationId,
            vehicleId = rental.vehicleId,
            plate = rental.plate,
            phase = rental.phase,
            expiresAt = rental.expiresAt,
            deposit = rental.deposit,
            fee = rental.fee,
            account = rental.account,
            planId = rental.planId,
            source = rental.source,
        }
    end
    SaveResourceFile(resource, RENTALS_FILE, json.encode(list), -1)
end

local function pushRental(source, rental)
    TriggerClientEvent(resource .. ':rental', source, publicRental(rental))
end

local function broadcastTravel(travel)
    local key = stationKey(travel.marinaId, travel.stationId)
    if travel.phase == 'idle' then
        travels[key] = nil
    else
        travels[key] = travel
    end
    TriggerClientEvent(resource .. ':travel', -1, travel)
end

local function phaseDuration(phase)
    local cfg = Config.rental
    if phase == 'opening' then return (cfg.openingSeconds or 8) * 1000 end
    if phase == 'launching' or phase == 'returning' then return (cfg.launchSeconds or 7) * 1000 end
    if phase == 'closing' then return (cfg.closingSeconds or 6) * 1000 end
    return 8000
end

local function setPhase(rental, phase, marinaId, stationId)
    rental.phase = phase
    rental.phaseAt = nowMs()
    if marinaId then rental.marinaId = marinaId end
    if stationId then rental.stationId = stationId end

    local bayStationId = rental.stationId
    if phase == 'returning' or phase == 'closing' then
        bayStationId = rental.returnStationId or rental.stationId
    end

    broadcastTravel({
        marinaId = rental.marinaId,
        stationId = bayStationId,
        rentalId = rental.id,
        vehicleId = rental.vehicleId,
        netId = rental.netId,
        phase = phase,
        phaseAt = rental.phaseAt,
        duration = phaseDuration(phase),
        serverNow = nowMs(),
    })
    if rental.source then pushRental(rental.source, rental) end
end

local function deleteVehicle(rental)
    if rental.vehicle and DoesEntityExist(rental.vehicle) then
        if rental.source then
            Bridge.removeKeys(rental.source, rental.vehicle, rental.plate)
        end
        DeleteEntity(rental.vehicle)
    end
    rental.vehicle = nil
    rental.netId = nil
end

local function releaseFleet(marina, vehicleId, toMaintenance)
    if not marina or not marina.fleet or not marina.fleet[vehicleId] then return end
    local row = marina.fleet[vehicleId]
    row.rented = math.max(0, (row.rented or 0) - 1)
    if toMaintenance then
        row.maintenance = (row.maintenance or 0) + 1
    else
        row.available = (row.available or 0) + 1
    end
    if marina.mode == 'public' then
        local stock = math.floor(tonumber(Config.business.publicStockPerModel) or 10)
        row.stock = stock
        if (row.available or 0) > stock then row.available = stock end
    end
end

local function reserveFleet(marina, vehicleId)
    local row = marina.fleet[vehicleId]
    if not row or (row.available or 0) < 1 then return false end
    if not Core.isVehicleEnabled(marina, vehicleId) then return false end
    row.available = row.available - 1
    row.rented = (row.rented or 0) + 1
    return true
end

local function clearRental(rental, reason)
    if not rental then return end
    local key = stationKey(rental.marinaId, rental.returnStationId or rental.stationId)
    if stationBusy[key] == rental.id then stationBusy[key] = nil end
    local launchKey = stationKey(rental.marinaId, rental.stationId)
    if stationBusy[launchKey] == rental.id then stationBusy[launchKey] = nil end

    broadcastTravel({
        marinaId = rental.marinaId,
        stationId = rental.returnStationId or rental.stationId,
        rentalId = rental.id,
        vehicleId = rental.vehicleId,
        netId = rental.netId,
        phase = 'idle',
        phaseAt = nowMs(),
        duration = 0,
        serverNow = nowMs(),
    })
    if rental.stationId ~= (rental.returnStationId or rental.stationId) then
        broadcastTravel({
            marinaId = rental.marinaId,
            stationId = rental.stationId,
            rentalId = rental.id,
            vehicleId = rental.vehicleId,
            netId = rental.netId,
            phase = 'idle',
            phaseAt = nowMs(),
            duration = 0,
            serverNow = nowMs(),
        })
    end

    deleteVehicle(rental)
    rentalsById[rental.id] = nil
    if rental.source and rentalsBySource[rental.source] == rental then
        rentalsBySource[rental.source] = nil
        pushRental(rental.source, false)
        if reason then Core.notify(rental.source, reason, 'inform') end
    end
    persistRentals()
end

local function spawnVehicle(station, vehicleDef, plate)
    local model = joaat(vehicleDef.model)
    if not model or model == 0 then return nil end
    local spawn = station.spawn
    local offset = tonumber(vehicleDef.originOffset) or 0.0
    local vehicle = CreateVehicle(model, spawn.x, spawn.y, spawn.z + offset, spawn.heading or station.root.heading or 0.0, true, true)
    if not vehicle or vehicle == 0 then return nil end

    local deadline = GetGameTimer() + 5000
    while not DoesEntityExist(vehicle) and GetGameTimer() < deadline do
        Wait(0)
    end
    if not DoesEntityExist(vehicle) then return nil end

    SetEntityHeading(vehicle, spawn.heading or station.root.heading or 0.0)
    SetVehicleNumberPlateText(vehicle, plate)
    SetVehicleDoorsLocked(vehicle, 2)
    if SetEntityOrphanMode then
        pcall(SetEntityOrphanMode, vehicle, 2)
    end
    return vehicle
end

local function playerDistance(source, point)
    local ped = GetPlayerPed(source)
    if not ped or ped == 0 then return math.huge end
    local coords = GetEntityCoords(ped)
    return Math.distance({ x = coords.x, y = coords.y, z = coords.z }, point)
end

local function vehicleDistance(rental, point)
    if not rental.vehicle or not DoesEntityExist(rental.vehicle) then return math.huge end
    local coords = GetEntityCoords(rental.vehicle)
    return Math.distance({ x = coords.x, y = coords.y, z = coords.z }, point)
end

local function damageFee(rental)
    if not rental.vehicle or not DoesEntityExist(rental.vehicle) then
        return tonumber(Config.rental.damageFee) or 500
    end
    local engine, body = 1000.0, 1000.0
    local okEngine, eng = pcall(GetVehicleEngineHealth, rental.vehicle)
    local okBody, bod = pcall(GetVehicleBodyHealth, rental.vehicle)
    if okEngine and eng then engine = eng end
    if okBody and bod then body = bod end
    if engine < 700.0 or body < 700.0 then
        return tonumber(Config.rental.damageFee) or 500
    end
    return 0
end

local function finishReturn(rental)
    local marina = Core.get(rental.marinaId)
    local late = rental.expiresAt and os.time() > rental.expiresAt
    local fee = damageFee(rental)
    if late then fee = fee + (tonumber(Config.rental.damageFee) or 500) end

    local refund = math.max(0, (rental.deposit or 0) - fee)
    local toMaintenance = fee > 0
    if marina then
        releaseFleet(marina, rental.vehicleId, toMaintenance)
        Core.persist()
    end

    if rental.source and refund > 0 then
        Bridge.addMoney(rental.source, rental.account or 'bank', refund)
    end

    local message
    if refund >= (rental.deposit or 0) then
        message = 'Rental returned. Full deposit refunded.'
    elseif refund > 0 then
        message = ('Rental returned. Deposit refunded minus $%s in fees.'):format(fee)
    else
        message = 'Rental returned. Deposit was withheld for damage or late return.'
    end

    SetTimeout(phaseDuration('closing'), function()
        local still = rentalsById[rental.id]
        if not still then return end
        clearRental(still, message)
    end)
end

local function advanceOpening(rental)
    SetTimeout(phaseDuration('opening'), function()
        local still = rentalsById[rental.id]
        if not still or still.phase ~= 'opening' then return end
        setPhase(still, 'launching')
        SetTimeout(phaseDuration('launching'), function()
            local live = rentalsById[rental.id]
            if not live or live.phase ~= 'launching' then return end
            local plan = findPlan(live.planId)
            live.expiresAt = os.time() + math.floor((plan and plan.minutes or 30) * 60)
            setPhase(live, 'active')
            if live.vehicle and DoesEntityExist(live.vehicle) then
                SetVehicleDoorsLocked(live.vehicle, 1)
                Bridge.giveKeys(live.source, live.vehicle, live.plate)
            end
            local key = stationKey(live.marinaId, live.stationId)
            -- After the door-close window the bay is free for other customers.
            SetTimeout(phaseDuration('closing'), function()
                if stationBusy[key] == live.id then stationBusy[key] = nil end
                local current = rentalsById[live.id]
                if current and current.phase == 'active' then
                    broadcastTravel({
                        marinaId = current.marinaId,
                        stationId = current.stationId,
                        rentalId = current.id,
                        vehicleId = current.vehicleId,
                        netId = current.netId,
                        phase = 'idle',
                        phaseAt = nowMs(),
                        duration = 0,
                        serverNow = nowMs(),
                    })
                end
            end)
            persistRentals()
        end)
    end)
end

function M.travels()
    local list = {}
    for _, travel in pairs(travels) do
        list[#list + 1] = travel
    end
    return list
end

function M.personal(source)
    return publicRental(rentalsBySource[source])
end

function M.hasActiveAtMarina(marinaId)
    marinaId = tostring(marinaId or '')
    for _, rental in pairs(rentalsById) do
        if rental.marinaId == marinaId then return true end
    end
    return false
end

function M.rent(source, payload)
    if rentalsBySource[source] then return fail('You already have a vessel out.') end
    local marina = Core.get(payload and payload.marinaId)
    if not marina then return fail('Marina not found.') end
    local station = Core.findStation(marina, payload and payload.stationId)
    if not station or station.enabled == false then return fail('Launch bay not found.') end

    local key = stationKey(marina.id, station.id)
    if stationBusy[key] or travels[key] then
        return fail('This launch bay is busy. Please wait.')
    end

    if playerDistance(source, station.terminal) > ((Config.rental.interactionDistance or 4.0) + 3.0) then
        return fail('Move closer to the terminal.')
    end

    local def = MarinaAssets.vehicle(payload.vehicleId)
    if not def then return fail('Unknown vessel.') end
    if def.kind ~= station.kind then return fail('This vessel does not fit this bay.') end
    if not Core.isVehicleEnabled(marina, def.id) then return fail('This vessel is paused.') end

    local plan = findPlan(payload.planId)
    if not plan then return fail('Invalid rental plan.') end

    local price = Core.vehiclePrice(marina, def.id)
    local fee = math.floor(price * (tonumber(plan.multiplier) or 1.0))
    local deposit = math.floor(tonumber(def.deposit) or 0)
    local total = fee + deposit
    local account = payload.account == 'cash' and 'cash' or 'bank'
    local identity = Bridge.getIdentifier(source)
    if not identity then return fail('Character is not ready yet.') end

    local activeCount = 0
    for _, rental in pairs(rentalsById) do
        if rental.identifier == identity then activeCount = activeCount + 1 end
    end
    if activeCount >= (Config.rental.maxPerPlayer or 1) then
        return fail('You already have a vessel out.')
    end

    if not reserveFleet(marina, def.id) then
        return fail('No vessels available right now.')
    end

    if not Bridge.removeMoney(source, account, total) then
        releaseFleet(marina, def.id, false)
        return fail('Insufficient funds.')
    end

    local plate = makePlate()
    local vehicle = spawnVehicle(station, def, plate)
    if not vehicle then
        Bridge.addMoney(source, account, total)
        releaseFleet(marina, def.id, false)
        return fail('Could not prepare the vessel. Try again.')
    end

    local netId = NetworkGetNetworkIdFromEntity(vehicle)
    local rental = {
        id = ('rent_%s_%s'):format(os.time(), math.random(1000, 9999)),
        identifier = identity,
        source = source,
        marinaId = marina.id,
        stationId = station.id,
        vehicleId = def.id,
        plate = plate,
        vehicle = vehicle,
        netId = netId,
        phase = 'opening',
        phaseAt = nowMs(),
        deposit = deposit,
        fee = fee,
        account = account,
        planId = plan.id,
        expiresAt = nil,
    }

    rentalsById[rental.id] = rental
    rentalsBySource[source] = rental
    stationBusy[key] = rental.id

    if marina.mode == 'ownable' then
        MarinaBusiness.creditRental(marina, fee, identity, def.label)
    end
    Core.persist()

    setPhase(rental, 'opening')
    persistRentals()
    advanceOpening(rental)

    -- Reservation timeout: cancel if still opening/launching too long.
    local timeoutMs = (tonumber(Config.rental.reservationTimeout) or 45) * 1000
    SetTimeout(timeoutMs + phaseDuration('opening') + phaseDuration('launching'), function()
        local still = rentalsById[rental.id]
        if not still then return end
        if still.phase == 'opening' or still.phase == 'launching' then
            local m = Core.get(still.marinaId)
            if m then releaseFleet(m, still.vehicleId, false); Core.persist() end
            if still.source then
                Bridge.addMoney(still.source, still.account or 'bank', (still.fee or 0) + (still.deposit or 0))
            end
            clearRental(still, 'Reservation timed out. You have been refunded.')
        end
    end)

    return { ok = true }
end

function M.returnVessel(source, payload)
    local rental = rentalsBySource[source]
    if not rental then return fail('You have no active rental.') end
    if rental.phase ~= 'active' then return fail('Your vessel is not ready to return yet.') end

    local marina = Core.get(payload and payload.marinaId) or Core.get(rental.marinaId)
    if not marina or marina.id ~= rental.marinaId then
        return fail('Return this vessel to a bay at the same marina.')
    end
    local station = Core.findStation(marina, payload and payload.stationId)
    if not station then return fail('Launch bay not found.') end

    local def = MarinaAssets.vehicle(rental.vehicleId)
    if not def or def.kind ~= station.kind then
        return fail('Use a compatible launch bay for this vessel.')
    end

    local key = stationKey(marina.id, station.id)
    if stationBusy[key] and stationBusy[key] ~= rental.id then
        return fail('This launch bay is busy.')
    end

    local limit = Config.rental.returnDistance or 12.0
    if vehicleDistance(rental, station.exit) > limit then
        return fail('Park the vessel closer to the launch bay.')
    end
    if playerDistance(source, station.exit) > (limit + 5.0) then
        return fail('Stand near the launch bay to return.')
    end

    -- Player must be outside the vehicle (client checks, server re-checks via ped).
    local ped = GetPlayerPed(source)
    if ped ~= 0 and rental.vehicle and DoesEntityExist(rental.vehicle) then
        local veh
        local ok, result = pcall(GetVehiclePedIsIn, ped, false)
        if ok then veh = result end
        if veh == rental.vehicle then
            return fail('Step out of the vessel before returning it.')
        end
    end

    rental.returnStationId = station.id
    stationBusy[key] = rental.id
    Bridge.removeKeys(source, rental.vehicle, rental.plate)
    setPhase(rental, 'returning')
    persistRentals()

    SetTimeout(phaseDuration('returning'), function()
        local still = rentalsById[rental.id]
        if not still or still.phase ~= 'returning' then return end
        setPhase(still, 'closing')
        finishReturn(still)
    end)

    return { ok = true }
end

function M.onPlayerDropped(source)
    local rental = rentalsBySource[source]
    if not rental then return end
    -- Keep the rental alive briefly; detach source. Vehicle remains until expiry sweep.
    rental.source = nil
    rentalsBySource[source] = nil
end

function M.attachSource(source)
    local identity = Bridge.getIdentifier(source)
    if not identity then return end
    for _, rental in pairs(rentalsById) do
        if rental.identifier == identity and not rental.source then
            rental.source = source
            rentalsBySource[source] = rental
            if rental.netId then
                pushRental(source, rental)
            end
            break
        end
    end
end

CreateThread(function()
    while true do
        Wait(15000)
        local now = os.time()
        for _, rental in pairs(rentalsById) do
            if rental.phase == 'active' and rental.expiresAt and now > (rental.expiresAt + 300) then
                -- 5 minutes past expiry with no return: force recover.
                local marina = Core.get(rental.marinaId)
                if marina then
                    releaseFleet(marina, rental.vehicleId, true)
                    Core.persist()
                end
                if rental.source then
                    Core.notify(rental.source, 'Your rental expired. The deposit was withheld.', 'error')
                end
                clearRental(rental)
            end
        end
    end
end)

-- Drop orphan rentals from a previous session (vehicles are gone after restart).
CreateThread(function()
    Wait(1000)
    local raw = LoadResourceFile(resource, RENTALS_FILE)
    if not raw or raw == '' then return end
    local ok, data = pcall(json.decode, raw)
    if not ok or type(data) ~= 'table' then return end
    -- On restart, refund deposits and restore fleet availability.
    for _, entry in ipairs(data) do
        local marina = Core.get(entry.marinaId)
        if marina and entry.vehicleId then
            releaseFleet(marina, entry.vehicleId, false)
            if entry.identifier and entry.deposit then
                -- Cannot refund offline reliably across frameworks; credit business history only.
                Core.pushHistory(marina, 'rental_refund', 0, 'Restart recovery · deposit unsettled', entry.identifier)
            end
        end
    end
    Core.persist()
    SaveResourceFile(resource, RENTALS_FILE, '[]', -1)
end)
