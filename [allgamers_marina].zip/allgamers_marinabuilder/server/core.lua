-- ALLGAMERS MARINA CORE
-- Layout persistence, validation, snapshot / sync, create / save / edit / delete.
MarinaCore = {}
local M = MarinaCore
local Config = MarinaConfig
local Bridge = MarinaServerBridge
local Math = MarinaMath
local resource = GetCurrentResourceName()

local marinas = {} -- id -> marina
local globalRevision = 0
local MARINAS_FILE = 'marinas.json'

local function nowMs()
    return (os.time() * 1000) + (GetGameTimer() % 1000)
end

local function fail(message, code)
    return { ok = false, error = message or 'Request failed.', code = code }
end

local function clone(value)
    if type(value) ~= 'table' then return value end
    local out = {}
    for k, v in pairs(value) do out[k] = clone(v) end
    return out
end

local function loadJson(name, fallback)
    local raw = LoadResourceFile(resource, name)
    if not raw or raw == '' then return fallback end
    local ok, data = pcall(json.decode, raw)
    if ok and type(data) == 'table' then return data end
    return fallback
end

local function saveJson(name, data)
    return SaveResourceFile(resource, name, json.encode(data), -1)
end

local function uid(prefix)
    return ('%s_%s_%s'):format(prefix or 'id', os.time(), math.random(1000, 9999))
end

local function finiteCoord(v)
    return Math.finite(tonumber(v) or 0)
end

local function normalizeRoot(root)
    if type(root) ~= 'table' then return nil end
    local x, y, z = tonumber(root.x), tonumber(root.y), tonumber(root.z)
    if not (finiteCoord(x) and finiteCoord(y) and finiteCoord(z)) then return nil end
    return {
        x = x + 0.0,
        y = y + 0.0,
        z = z + 0.0,
        heading = (tonumber(root.heading) or 0.0) % 360,
    }
end

local function normalizePiece(piece)
    if type(piece) ~= 'table' then return nil end
    local asset = tostring(piece.asset or '')
    if asset == '' or not MarinaAssets.catalog[asset] then return nil end
    local root = normalizeRoot(piece)
    if not root then return nil end
    return {
        id = type(piece.id) == 'string' and piece.id ~= '' and piece.id or uid('piece'),
        asset = asset,
        x = root.x,
        y = root.y,
        z = root.z,
        heading = root.heading,
        parentId = type(piece.parentId) == 'string' and piece.parentId or nil,
        parentSocket = type(piece.parentSocket) == 'string' and piece.parentSocket or nil,
        childSocket = type(piece.childSocket) == 'string' and piece.childSocket or nil,
    }
end

local function normalizeStation(station)
    if type(station) ~= 'table' then return nil end
    local kind = station.kind == 'boat' and 'boat' or (station.kind == 'jetski' and 'jetski' or nil)
    if not kind then return nil end
    local root = normalizeRoot(station.root)
    local terminal = normalizeRoot(station.terminal)
    local spawn = normalizeRoot(station.spawn)
    local exit = normalizeRoot(station.exit)
    local pickup = normalizeRoot(station.pickup)
    if not (root and terminal and spawn and exit and pickup) then return nil end
    return {
        id = type(station.id) == 'string' and station.id ~= '' and station.id or uid('station'),
        kind = kind,
        root = root,
        terminal = terminal,
        spawn = spawn,
        exit = exit,
        pickup = pickup,
        enabled = station.enabled ~= false,
        parentId = type(station.parentId) == 'string' and station.parentId or nil,
        parentSocket = type(station.parentSocket) == 'string' and station.parentSocket or nil,
    }
end

local function ensureBusinessFields(marina)
    marina.balance = math.floor(tonumber(marina.balance) or 0)
    marina.earnings = math.floor(tonumber(marina.earnings) or 0)
    marina.rentalCount = math.floor(tonumber(marina.rentalCount) or 0)
    marina.employees = type(marina.employees) == 'table' and marina.employees or {}
    marina.history = type(marina.history) == 'table' and marina.history or {}
    marina.prices = type(marina.prices) == 'table' and marina.prices or {}
    marina.enabled = type(marina.enabled) == 'table' and marina.enabled or {}
    marina.fleet = type(marina.fleet) == 'table' and marina.fleet or {}

    for _, def in ipairs(Config.vehicles or {}) do
        local row = marina.fleet[def.id]
        if type(row) ~= 'table' then
            if marina.mode == 'public' then
                local stock = math.floor(tonumber(Config.business.publicStockPerModel) or 10)
                marina.fleet[def.id] = {
                    stock = stock,
                    available = stock,
                    rented = 0,
                    maintenance = 0,
                    enabled = true,
                }
            else
                marina.fleet[def.id] = {
                    stock = 0,
                    available = 0,
                    rented = 0,
                    maintenance = 0,
                    enabled = true,
                }
            end
        else
            row.stock = math.max(0, math.floor(tonumber(row.stock) or 0))
            row.available = math.max(0, math.floor(tonumber(row.available) or 0))
            row.rented = math.max(0, math.floor(tonumber(row.rented) or 0))
            row.maintenance = math.max(0, math.floor(tonumber(row.maintenance) or 0))
            if marina.enabled[def.id] ~= nil then
                row.enabled = marina.enabled[def.id] ~= false
            elseif row.enabled == nil then
                row.enabled = true
            end
        end
    end
end

local function normalizeMarina(entry, forceId)
    if type(entry) ~= 'table' then return nil end
    local coords = normalizeRoot(entry.coords)
    if not coords then return nil end

    local pieces, stations = {}, {}
    for _, piece in ipairs(entry.pieces or {}) do
        local p = normalizePiece(piece)
        if p then pieces[#pieces + 1] = p end
    end
    for _, station in ipairs(entry.stations or {}) do
        local s = normalizeStation(station)
        if s then stations[#stations + 1] = s end
    end

    local mode = entry.mode == 'ownable' and 'ownable' or 'public'
    local blip = type(entry.blip) == 'table' and {
        enabled = entry.blip.enabled ~= false,
        sprite = math.floor(tonumber(entry.blip.sprite) or 410),
        color = math.floor(tonumber(entry.blip.color) or 3),
        scale = tonumber(entry.blip.scale) or 0.75,
    } or { enabled = true, sprite = 410, color = 3, scale = 0.75 }

    local marina = {
        id = forceId or (type(entry.id) == 'string' and entry.id ~= '' and entry.id) or uid('marina'),
        revision = math.max(1, math.floor(tonumber(entry.revision) or 1)),
        name = tostring(entry.name or 'Marina'):sub(1, 48),
        mode = mode,
        purchasePrice = math.floor(Math.clamp(tonumber(entry.purchasePrice) or Config.business.defaultPurchasePrice, 0, Config.limits.maxPrice)),
        coords = coords,
        blip = blip,
        pieces = pieces,
        stations = stations,
        owner = type(entry.owner) == 'string' and entry.owner ~= '' and entry.owner or nil,
        balance = math.floor(tonumber(entry.balance) or 0),
        earnings = math.floor(tonumber(entry.earnings) or 0),
        rentalCount = math.floor(tonumber(entry.rentalCount) or 0),
        employees = type(entry.employees) == 'table' and entry.employees or {},
        history = type(entry.history) == 'table' and entry.history or {},
        prices = type(entry.prices) == 'table' and entry.prices or {},
        enabled = type(entry.enabled) == 'table' and entry.enabled or {},
        fleet = type(entry.fleet) == 'table' and entry.fleet or {},
    }

    if mode == 'public' then marina.owner = nil end
    ensureBusinessFields(marina)
    return marina
end

local function countMarinas()
    local n = 0
    for _ in pairs(marinas) do n = n + 1 end
    return n
end

local function validateDraft(draft, existingId)
    if type(draft) ~= 'table' then return nil, 'Invalid marina data.' end

    local limits = Config.limits
    if not existingId and countMarinas() >= (limits.maxMarinas or 64) then
        return nil, 'Marina limit reached.'
    end

    local pieces = draft.pieces or {}
    local stations = draft.stations or {}
    if #pieces > (limits.maxPieces or 300) then return nil, 'Too many pieces.' end
    if #stations > (limits.maxStations or 16) then return nil, 'Too many launch stations.' end

    local coords = normalizeRoot(draft.coords)
    if not coords then return nil, 'Marina location is invalid.' end

    for _, other in pairs(marinas) do
        if other.id ~= existingId then
            if Math.distance(coords, other.coords) < (limits.minMarinaGap or 30.0) then
                return nil, 'Too close to another marina.'
            end
        end
    end

    local radius = limits.buildRadius or 180.0
    for _, piece in ipairs(pieces) do
        local p = normalizePiece(piece)
        if not p then return nil, 'Unknown or invalid marina piece.' end
        if Math.distance(coords, p) > radius then return nil, 'A piece is outside the build radius.' end
    end
    for _, station in ipairs(stations) do
        local s = normalizeStation(station)
        if not s then return nil, 'Invalid launch station.' end
        if Math.distance(coords, s.root) > radius then return nil, 'A station is outside the build radius.' end
    end

    local marina = normalizeMarina(draft, existingId)
    if not marina then return nil, 'Could not validate marina.' end
    return marina
end

local function publicMarina(marina)
    return {
        id = marina.id,
        revision = marina.revision,
        name = marina.name,
        mode = marina.mode,
        purchasePrice = marina.purchasePrice,
        coords = clone(marina.coords),
        blip = clone(marina.blip),
        pieces = clone(marina.pieces),
        stations = clone(marina.stations),
        owner = marina.owner and true or false,
    }
end

local function persist()
    local list = {}
    for _, marina in pairs(marinas) do
        list[#list + 1] = marina
    end
    table.sort(list, function(a, b) return tostring(a.id) < tostring(b.id) end)
    if not saveJson(MARINAS_FILE, list) then
        print(('[allgamers_marinabuilder] failed to save %s'):format(MARINAS_FILE))
        return false
    end
    return true
end

function M.nowMs()
    return nowMs()
end

function M.fail(message, code)
    return fail(message, code)
end

function M.get(id)
    return marinas[tostring(id or '')]
end

function M.all()
    return marinas
end

function M.persist()
    return persist()
end

function M.bumpRevision()
    globalRevision = globalRevision + 1
    return globalRevision
end

function M.roleFor(identity, marina)
    if not marina or not identity then return nil end
    if marina.owner == identity then return 'owner' end
    for _, employee in ipairs(marina.employees or {}) do
        if employee.identity == identity then
            return employee.role == 'manager' and 'manager' or 'staff'
        end
    end
    return nil
end

function M.rolesFor(source)
    local identity = Bridge.getIdentifier(source)
    local roles = {}
    if not identity then return roles end
    for id, marina in pairs(marinas) do
        local role = M.roleFor(identity, marina)
        if role then roles[id] = role end
    end
    return roles
end

function M.canEditLayout(source, marina)
    if Bridge.isAdmin(source) then return true end
    local role = M.roleFor(Bridge.getIdentifier(source), marina)
    return role == 'owner' or role == 'manager'
end

function M.findStation(marina, stationId)
    if not marina then return nil end
    stationId = tostring(stationId or '')
    for _, station in ipairs(marina.stations or {}) do
        if station.id == stationId then return station end
    end
end

function M.pushHistory(marina, kind, amount, detail, identity)
    marina.history = marina.history or {}
    marina.history[#marina.history + 1] = {
        kind = kind,
        amount = math.floor(tonumber(amount) or 0),
        detail = detail,
        at = os.time(),
        identity = identity,
    }
    while #marina.history > 120 do
        table.remove(marina.history, 1)
    end
end

function M.vehiclePrice(marina, vehicleId)
    local def = MarinaAssets.vehicle(vehicleId)
    if not def then return nil end
    local override = marina and marina.prices and marina.prices[vehicleId]
    local price = math.floor(tonumber(override) or def.price or 0)
    return Math.clamp(price, 0, Config.limits.maxPrice)
end

function M.isVehicleEnabled(marina, vehicleId)
    local fleet = marina and marina.fleet and marina.fleet[vehicleId]
    if fleet and fleet.enabled == false then return false end
    if marina and marina.enabled and marina.enabled[vehicleId] == false then return false end
    return true
end

function M.accountBalances(source)
    local raw = Bridge.getBalances(source) or {}
    local out = {}
    for _, account in ipairs(Config.accounts or { 'cash', 'bank' }) do
        out[account] = math.floor(tonumber(raw[account]) or 0)
    end
    return out
end

function M.layoutPayload()
    local list = {}
    for _, marina in pairs(marinas) do
        list[#list + 1] = publicMarina(marina)
    end
    table.sort(list, function(a, b) return tostring(a.id) < tostring(b.id) end)
    return list
end

function M.snapshot(source, includePersonal)
    local rental, travels
    if includePersonal ~= false and MarinaRental then
        rental = MarinaRental.personal(source)
        travels = MarinaRental.travels()
    end
    return {
        ok = true,
        revision = globalRevision,
        serverNow = nowMs(),
        marinas = M.layoutPayload(),
        rental = rental or false,
        travels = travels or {},
        admin = Bridge.isAdmin(source),
        roles = M.rolesFor(source),
    }
end

function M.sync(target)
    globalRevision = globalRevision + 1
    if target then
        TriggerClientEvent(resource .. ':sync', target, M.snapshot(target))
        return
    end
    for _, id in ipairs(GetPlayers()) do
        local src = tonumber(id)
        if src then
            TriggerClientEvent(resource .. ':sync', src, M.snapshot(src))
        end
    end
end

function M.notify(source, description, kind)
    TriggerClientEvent(resource .. ':notify', source, {
        description = description,
        type = kind or 'inform',
    })
end

function M.create(source, draft)
    if not Bridge.isAdmin(source) then return fail('Administrator permission required.') end
    local marina, err = validateDraft(draft, nil)
    if not marina then return fail(err) end

    -- Fresh id for every create so draft ids never collide with live data.
    marina.id = uid('marina')
    marina.revision = 1
    marina.owner = nil
    marina.balance = 0
    marina.earnings = 0
    marina.rentalCount = 0
    marina.employees = {}
    marina.history = {}
    marina.prices = {}
    ensureBusinessFields(marina)

    marinas[marina.id] = marina
    persist()
    M.sync()
    return { ok = true, id = marina.id, revision = marina.revision, marina = publicMarina(marina) }
end

function M.save(source, draft)
    local existing = M.get(draft and draft.id)
    if not existing then return fail('Marina not found.') end
    if not M.canEditLayout(source, existing) then return fail('You cannot edit this marina.') end
    if MarinaRental and MarinaRental.hasActiveAtMarina(existing.id) then
        return fail('Finish active rentals before saving layout changes.')
    end

    local marina, err = validateDraft(draft, existing.id)
    if not marina then return fail(err) end

    marina.revision = (existing.revision or 0) + 1
    marina.owner = existing.owner
    marina.balance = existing.balance
    marina.earnings = existing.earnings
    marina.rentalCount = existing.rentalCount
    marina.employees = existing.employees
    marina.history = existing.history
    marina.prices = existing.prices
    marina.enabled = existing.enabled
    marina.fleet = existing.fleet
    marina.mode = existing.mode -- mode is fixed after create
    marina.purchasePrice = existing.purchasePrice
    ensureBusinessFields(marina)

    marinas[marina.id] = marina
    persist()
    M.sync()
    return { ok = true, id = marina.id, revision = marina.revision, marina = publicMarina(marina) }
end

function M.edit(source, payload)
    local marina = M.get(payload and payload.id)
    if not marina then return fail('Marina not found.') end
    if not M.canEditLayout(source, marina) then return fail('You cannot edit this marina.') end
    if MarinaRental and MarinaRental.hasActiveAtMarina(marina.id) then
        return fail('Finish active rentals before opening the builder.')
    end
    return { ok = true, editable = clone(marina), marina = clone(marina) }
end

function M.delete(source, payload)
    if not Bridge.isAdmin(source) then return fail('Administrator permission required.') end
    local marina = M.get(payload and payload.id)
    if not marina then return fail('Marina not found.') end
    if MarinaRental and MarinaRental.hasActiveAtMarina(marina.id) then
        return fail('Finish active rentals before deleting this marina.')
    end
    marinas[marina.id] = nil
    persist()
    M.sync()
    return { ok = true }
end

function M.load()
    marinas = {}
    local data = loadJson(MARINAS_FILE, {})
    local sourceList = data
    if data.marinas and type(data.marinas) == 'table' then sourceList = data.marinas end
    if #sourceList == 0 and next(sourceList) then
        -- map-style save
        for _, entry in pairs(sourceList) do
            local marina = normalizeMarina(entry)
            if marina then marinas[marina.id] = marina end
        end
    else
        for _, entry in ipairs(sourceList) do
            local marina = normalizeMarina(entry)
            if marina then marinas[marina.id] = marina end
        end
    end
    globalRevision = 1
    print(('[allgamers_marinabuilder] loaded %d marina(s)'):format(countMarinas()))
end

M.load()
