-- ALLGAMERS MARINA MAIN
-- Wires MarinaRPC actions to core / business / rental modules.
local Bridge = MarinaServerBridge
local Core = MarinaCore
local Business = MarinaBusiness
local Rental = MarinaRental

MarinaRPC.register('snapshot', function(source, _)
    Rental.attachSource(source)
    return Core.snapshot(source)
end)

MarinaRPC.register('create', function(source, payload)
    return Core.create(source, payload)
end)

MarinaRPC.register('save', function(source, payload)
    return Core.save(source, payload)
end)

MarinaRPC.register('edit', function(source, payload)
    return Core.edit(source, payload)
end)

MarinaRPC.register('delete', function(source, payload)
    return Core.delete(source, payload)
end)

MarinaRPC.register('menu', function(source, payload)
    Rental.attachSource(source)
    return Business.menu(source, payload)
end)

MarinaRPC.register('buy', function(source, payload)
    return Business.buy(source, payload)
end)

MarinaRPC.register('rent', function(source, payload)
    return Rental.rent(source, payload)
end)

MarinaRPC.register('return', function(source, payload)
    return Rental.returnVessel(source, payload)
end)

MarinaRPC.register('business', function(source, payload)
    return Business.handle(source, payload)
end)

AddEventHandler('playerDropped', function()
    local src = source
    Rental.onPlayerDropped(src)
end)

AddEventHandler('onResourceStart', function(name)
    if name ~= GetCurrentResourceName() then return end
    print(('[allgamers_marinabuilder] server ready · framework=%s'):format(Bridge.framework()))
end)

-- Soft re-attach when frameworks finish loading a character.
AddEventHandler('QBCore:Server:PlayerLoaded', function(player)
    local src = type(player) == 'table' and player.PlayerData and player.PlayerData.source or source
    if src then SetTimeout(500, function() Rental.attachSource(src) end) end
end)

RegisterNetEvent('esx:playerLoaded', function(playerId)
    local src = tonumber(playerId) or source
    if src then SetTimeout(500, function() Rental.attachSource(src) end) end
end)
