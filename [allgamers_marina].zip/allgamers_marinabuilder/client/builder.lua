-- In-game construction: preview locally, commit one revision on Save.
-- The player keeps the normal gameplay camera and controls the whole time; the
-- preview is projected a few metres in front of the PLAYER, onto the deck plane.
MarinaBuilder = { active = false, draft = nil, placing = false }
local M, Math, Config = MarinaBuilder, MarinaMath, MarinaConfig
local ghost, selected, position, attach, stage, stationDraft
local rotation, height, reach, snapEnabled = 0, 0, 4.0, true
local generation, counter, dirty = 0, 0, false
local history = {}
local ghostParts = {}
local placementValid, surfaceKind, attachSnapped
local index, lastKey, indexInvalidate, socketIndex
local taps = { [24] = 0, [38] = 0, [32] = 0, key = 0, page = 0 }
local lastPlaced, lastMode
local seamHeadings
local inputSource, inputAt = {}, {}

local SEAM_TYPES = { structure = true, half_edge = true, hangar_segment = true, land_approach = true }
local DECOR_CATEGORIES = { edge = true, mooring = true, utility = true, interaction = true, signage = true }
local SEAM_EPSILON = 0.35
local WIDE_PIECE = 3.5

local function clone(t) return json.decode(json.encode(t)) end
local function uid(prefix)
    counter = counter + 1
    return prefix .. '_' .. GetGameTimer() .. '_' .. counter
end

---GetShapeTestResult returns the hit flag as a boolean on some builds and as 0/1 on
---others. Both have to count, otherwise every probe looks like empty sky.
local function didHit(value)
    return value == true or value == 1
end

local function horizontal(a, b)
    local dx, dy = (a.x or 0) - (b.x or 0), (a.y or 0) - (b.y or 0)
    return math.sqrt(dx * dx + dy * dy)
end

local function freeHeading()
    return ((M.draft and M.draft.coords.heading or 0) + rotation) % 360
end

-------------------------------------------------------------------------------
-- Ghost preview
-------------------------------------------------------------------------------

---Outlines live only on preview entities, never on the streamed marina props, and
---are switched off again before the entity is deleted.
local function outline(entity, enable)
    if entity and DoesEntityExist(entity) then SetEntityDrawOutline(entity, enable and true or false) end
end

local function ghostClear()
    generation = generation + 1
    if ghost and DoesEntityExist(ghost) then
        outline(ghost, false)
        DeleteEntity(ghost)
    end
    ghost = nil
    for _, part in ipairs(ghostParts) do
        if DoesEntityExist(part.entity) then
            outline(part.entity, false)
            DeleteEntity(part.entity)
        end
    end
    ghostParts = {}
end

local function connectSides(asset)
    local names, seen = {}, {}
    for _, socket in ipairs(asset.sockets or {}) do
        if SEAM_TYPES[socket.type] then
            local h = math.floor(((socket.heading or 0) % 360) / 90 + 0.5) % 4
            local side = ({ 'N', 'W', 'S', 'E' })[h + 1]
            if not seen[side] then seen[side] = true names[#names + 1] = side end
        end
    end
    return names
end

local function catalog()
    local list = {}
    for _, asset in pairs(MarinaAssets.catalog) do
        if not asset.sides then asset.sides = connectSides(asset) end
        list[#list+1] = asset
    end
    table.sort(list, function(a,b) return a.id < b.id end)
    return list
end

function M.panel()
    M.placing = false
    if M.deleting then M.stopDelete() end
    M.pendingStation = nil
    ghostClear()
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'builder', draft = M.draft, catalog = catalog(), dirty = dirty, maxPieces = Config.limits.maxPieces })
end

local function pushHistory()
    history[#history+1] = clone(M.draft)
    if #history > 30 then table.remove(history,1) end
    dirty = true
end

function M.close()
    M.active, M.placing = false, false
    M.stopDelete()
    M.pendingStation = nil
    ghostClear()
    stationDraft, stage = nil, nil
    SendNUIMessage({ action = 'builderClose' })
    SetNuiFocus(false,false)
    SetNuiFocusKeepInput(false)
end

function M.start(draft)
    if MarinaDui.active then MarinaDui.close() end
    M.active, M.draft, history, dirty = true, clone(draft), {}, false
    M.draft.pieces, M.draft.stations = M.draft.pieces or {}, M.draft.stations or {}
    indexInvalidate()
    M.panel()
end

local function makeGhost(asset, assemblyKind)
    ghostClear()
    local token = generation
    CreateThread(function()
        local p = M.draft.coords
        local entity = MarinaWorld.create(asset,p,nil,nil,true)
        -- The model may finish loading after the player already picked something else.
        if token ~= generation or not M.active then
            if entity then outline(entity, false) DeleteEntity(entity) end
            return
        end
        ghost = entity
        if not ghost then
            MarinaClientBridge.notify({type='error',description='Could not load model: '..asset})
            M.panel()
            return
        end
        outline(ghost, true)
        if assemblyKind then
            -- Whole station preview, without the separate tablet placement. The list
            -- carries the moving parts too (doors, ramp, cradle, pistons): the ghost
            -- used to show the shell only, so the finished station never matched it.
            for _, part in ipairs(MarinaAssets.preview[assemblyKind] or MarinaAssets.assemblies[assemblyKind] or {}) do
                if part.model ~= asset then
                    local e = MarinaWorld.create(part.model,p,part.position,part.quaternion_wxyz,true)
                    if token ~= generation then
                        if e then outline(e, false) DeleteEntity(e) end
                        return
                    end
                    if e then
                        outline(e, true)
                        ghostParts[#ghostParts+1] = {entity=e,position=part.position,q=part.quaternion_wxyz,model=part.model}
                    end
                elseif ghost then
                    ghostParts[#ghostParts+1] = {entity=ghost,position=part.position,q=part.quaternion_wxyz,primary=true,model=part.model}
                end
            end
        end
    end)
end

function M.select(asset, mode)
    selected, stage, lastKey, lastMode = asset, mode or 'piece', nil, nil
    if stage == 'station' then
        makeGhost(asset == 'jetski' and 'ff_marina_capsule_shell' or 'ff_marina_hangar_front',asset)
    else makeGhost(asset) end
    rotation, height = 0, 0
    reach = Config.builder.placementDistance or 4.0
    placementValid = false
    M.placing = true
    SetNuiFocus(false,false)
    SetNuiFocusKeepInput(false)
    local sides
    local child = stage ~= 'station' and MarinaAssets.catalog[asset] or nil
    if child then
        local names = connectSides(child)
        sides = #names > 0 and table.concat(names, ' ') or 'none'
    end
    SendNUIMessage({ action = 'placing', sides = sides,
        label = stage == 'station' and (asset .. ' station · place dock connection') or asset:gsub('ff_marina_',''):gsub('_',' '),
        note = stage == 'station' and 'Chevrons show where the vehicle exits; the white ring is the pickup point.' or nil })
end

-------------------------------------------------------------------------------
-- Where the preview sits
-------------------------------------------------------------------------------

---One placement Z model: the authored deck top. Once the marina has a first piece
---every later piece uses that same deck height, so nothing floats or stair-steps.
---Before that, the deck is derived from the water line, then from the ground.
---@return number? z, string? kind
local function deckHeight(x, y)
    local base = (M.draft and M.draft.coords.z or 0.0) + 50.0

    if M.draft and #M.draft.pieces > 0 then return M.draft.pieces[1].z, 'deck' end

    local water, waterZ
    if GetWaterHeightNoWaves ~= nil then water, waterZ = GetWaterHeightNoWaves(x, y, base) end
    if not water then water, waterZ = GetWaterHeight(x, y, base) end
    if water then return waterZ + (Config.builder.defaultDeckAboveWater or 1.05), 'water' end

    local found, groundZ = GetGroundZFor_3dCoord(x, y, base, false)
    if found and groundZ then return groundZ, 'ground' end

    -- Map geometry only (flag 1): the preview ghost and the local marina props are
    -- objects, so they can never be hit by this probe and cannot drag the preview.
    local handle = StartExpensiveSynchronousShapeTestLosProbe(x, y, base, x, y, base - 120.0, 1, PlayerPedId(), 7)
    local _, hit, coords = GetShapeTestResult(handle)
    if didHit(hit) and coords then return coords.z, 'probe' end
    return nil, nil
end

---Target a few metres in front of the player, using the gameplay camera yaw.
---The camera sits behind the ped, so the distance is measured from the PED, and
---the horizontal reach is always clamped: looking down aims closer, never further.
---@return table point, boolean hasSurface, string? kind
local function aim()
    local ped = PlayerPedId()
    local origin = GetEntityCoords(ped)
    local camRot = GetGameplayCamRot(2)
    local yaw = math.rad(camRot.z)
    local pitch = math.rad(math.max(-89.0, math.min(89.0, camRot.x + 0.0)))
    local forward = { x = -math.sin(yaw), y = math.cos(yaw) }
    local dir = { x = forward.x * math.cos(pitch), y = forward.y * math.cos(pitch), z = math.sin(pitch) }
    local minReach = Config.builder.minPlacementDistance or 2.5
    local cam = GetGameplayCamCoord ~= nil and GetGameplayCamCoord() or origin
    local x, y, z, kind

    local length = reach + 8.0
    local handle = StartExpensiveSynchronousShapeTestLosProbe(cam.x, cam.y, cam.z,
        cam.x + dir.x * length, cam.y + dir.y * length, cam.z + dir.z * length, 1, ped, 7)
    local _, hit, coords = GetShapeTestResult(handle)
    local planeZ, planeKind = deckHeight(origin.x + forward.x * reach, origin.y + forward.y * reach)
    if dir.z < -0.02 and planeZ then
        local t = (cam.z - planeZ) / -dir.z
        if t > 0 then x, y, z, kind = cam.x + dir.x * t, cam.y + dir.y * t, planeZ, planeKind end
    end
    if didHit(hit) and coords and (not planeZ or coords.z > planeZ - 0.3) then
        local dh = math.sqrt((coords.x - cam.x) ^ 2 + (coords.y - cam.y) ^ 2 + (coords.z - cam.z) ^ 2)
        local dp = x and math.sqrt((x - cam.x) ^ 2 + (y - cam.y) ^ 2 + (z - cam.z) ^ 2) or math.huge
        if dh < dp then x, y, z, kind = coords.x, coords.y, coords.z, 'hit' end
    end
    if not x then
        x, y = origin.x + forward.x * reach, origin.y + forward.y * reach
        z, kind = deckHeight(x, y)
    end

    local dx, dy = x - origin.x, y - origin.y
    local planar = math.sqrt(dx * dx + dy * dy)
    local ux, uy = forward.x, forward.y
    if planar > 0.05 then ux, uy = dx / planar, dy / planar end
    local clamped = math.max(minReach, math.min(reach, planar))
    if math.abs(clamped - planar) > 0.01 then
        x, y = origin.x + ux * clamped, origin.y + uy * clamped
        local nz, nkind = deckHeight(x, y)
        if nz then z, kind = nz, nkind end
    end

    return { x = x, y = y, z = z or origin.z }, z ~= nil, kind
end

-------------------------------------------------------------------------------
-- Snapping
-------------------------------------------------------------------------------

---Every socket of every placed piece, in world space, bucketed on a 4 m grid and
---rebuilt only when the draft changes. Resolving straight off the draft was
---O(pieces^2 * sockets^2) per frame: from roughly twenty pieces on it ate the
---frame, the preview lagged behind the aim and control edges were dropped, which
---is what made snapping look like it only worked on the first few pieces.
local CELL <const> = 4.0
local FINE <const> = 0.25
local SEAM_Z <const> = 0.6
local STICKY <const> = 0.35
local CONTINUE <const> = 0.35
local HALF_EDGE_COST <const> = 0.6
local HALF_EDGE_SPAN <const> = 2.6
local SOLID = { floor = true, coast = true }

function indexInvalidate() index = nil end

local function bucketPush(map, key, entry)
    local bucket = map[key]
    if bucket then bucket[#bucket + 1] = entry else map[key] = { entry } end
end

local function cellKey(x, y)
    return math.floor(x / CELL) .. ':' .. math.floor(y / CELL)
end

local function fineKey(x, y, z)
    return ('%d:%d:%d'):format(math.floor(x / FINE + 0.5), math.floor(y / FINE + 0.5),
        math.floor(z / SEAM_Z + 0.5))
end

---Two neighbours always emit the same seam twice, once per piece, and only the
---parent side was ever marked claimed. The free twin kept being handed out, so a
---rail or a station root could mount on a seam buried between two tiles. Every
---socket that sits on another piece's seam is marked here, once per draft change:
---the tiles also carry an edge socket on the very same point as the half edge one,
---and that one has to close with the seam.
---@param entries table every indexed socket
---@param seams table the structural sockets among them, the evidence of a join
local function markShared(entries, seams)
    if #seams == 0 then return end
    local fine = {}
    for _, entry in ipairs(seams) do bucketPush(fine, fineKey(entry.x, entry.y, entry.z), entry) end
    for _, entry in ipairs(entries) do
        for dx = -1, 1 do
            for dy = -1, 1 do
                for dz = -1, 1 do
                    local bucket = fine[fineKey(entry.x + dx * FINE, entry.y + dy * FINE, entry.z + dz * SEAM_Z)]
                    for i = 1, bucket and #bucket or 0 do
                        local other = bucket[i]
                        if other.pieceId ~= entry.pieceId and math.abs(other.z - entry.z) <= SEAM_Z
                            and horizontal(other, entry) < SEAM_EPSILON then
                            -- Only the entry is marked. Marking the evidence too let a
                            -- decor socket that happens to land on a tile seam close
                            -- that seam: a corner rail killed the edge centre next to it.
                            entry.shared = true
                        end
                    end
                end
            end
        end
    end
end

---The authored sockets only cover edge centres and quarter points, so an L shaped
---corner part had nothing to aim at and ended up hanging off the deck. These four
---are derived from the tile footprint: local sign of the corner, then the heading
---that lays the part's two arms along the two edges that meet there.
local CORNERS <const> = {
    { 1, 1, 180.0, 'CORNER_NE' },
    { -1, -1, 0.0, 'CORNER_SW' },
    { -1, 1, 270.0, 'CORNER_NW' },
    { 1, -1, 90.0, 'CORNER_SE' },
}

local function buildIndex()
    local cells, pieceCells, entries, seams, corners, claimed = {}, {}, {}, {}, {}, {}
    for _, piece in ipairs(M.draft.pieces) do
        if piece.parentId and piece.parentSocket then
            claimed[piece.parentId .. '#' .. piece.parentSocket] = true
            -- The child end of a seam is consumed by the same join.
            if piece.childSocket then claimed[piece.id .. '#' .. piece.childSocket] = true end
        end
    end
    for _, station in ipairs(M.draft.stations) do
        if station.parentId and station.parentSocket then
            claimed[station.parentId .. '#' .. station.parentSocket] = true
        end
    end
    for _, piece in ipairs(M.draft.pieces) do
        local asset = MarinaAssets.catalog[piece.asset]
        for _, socket in ipairs(asset and asset.sockets or {}) do
            local world = Math.world(piece, socket)
            local entry = { piece = piece, pieceId = piece.id, socket = socket, type = socket.type,
                x = world.x, y = world.y, z = world.z, heading = world.heading,
                claimed = claimed[piece.id .. '#' .. socket.name] == true }
            bucketPush(cells, cellKey(world.x, world.y), entry)
            entries[#entries + 1] = entry
            if SEAM_TYPES[socket.type] then seams[#seams + 1] = entry end
        end
        if asset and asset.bounds and SOLID[asset.category] then
            local hx = (asset.bounds.max.x - asset.bounds.min.x) * 0.5
            local hy = (asset.bounds.max.y - asset.bounds.min.y) * 0.5
            for _, corner in ipairs(CORNERS) do
                local world = Math.world(piece, { x = corner[1] * hx, y = corner[2] * hy, z = 0.0 })
                local entry = { piece = piece, pieceId = piece.id, socket = { name = corner[4] },
                    type = 'corner', x = world.x, y = world.y, z = world.z,
                    heading = ((piece.heading or 0) + corner[3]) % 360, claimed = false }
                bucketPush(cells, cellKey(world.x, world.y), entry)
                entries[#entries + 1] = entry
                corners[#corners + 1] = entry
            end
        end
        bucketPush(pieceCells, cellKey(piece.x, piece.y), piece)
    end
    markShared(entries, seams)
    -- A corner two tiles share is an inside corner: nothing is mounted there.
    markShared(corners, corners)
    index = { cells = cells, pieces = pieceCells,
        pieceCount = #M.draft.pieces, stationCount = #M.draft.stations }
    return index
end

function socketIndex()
    if index and index.pieceCount == #M.draft.pieces and index.stationCount == #M.draft.stations then
        return index
    end
    return buildIndex()
end

---Half the shorter footprint side: the largest radius that can never refuse a
---legal grid neighbour (4 m tiles sit 4 m apart, a 2 m part 3 m from a 4 m tile).
local function footprint(asset)
    if not asset or not asset.bounds then return 0.0 end
    return math.min((asset.bounds.max.x - asset.bounds.min.x) * 0.5,
        (asset.bounds.max.y - asset.bounds.min.y) * 0.5)
end

---True when a piece already fills that spot: the identical asset, or another deck
---tile whose footprint would be driven through this one.
local function overlaps(idx, pose, assetId)
    local asset = MarinaAssets.catalog[assetId]
    local limit = Config.builder.occupiedDistance or 0.5
    local solid = asset ~= nil and SOLID[asset.category] == true
    local mine = footprint(asset)
    local cx, cy = math.floor(pose.x / CELL), math.floor(pose.y / CELL)
    for gx = cx - 1, cx + 1 do
        for gy = cy - 1, cy + 1 do
            local bucket = idx.pieces[gx .. ':' .. gy]
            for i = 1, bucket and #bucket or 0 do
                local piece = bucket[i]
                local other = MarinaAssets.catalog[piece.asset]
                local conflict = piece.asset == assetId
                    or (solid and other ~= nil and SOLID[other.category] == true)
                if conflict and math.abs((piece.z or 0.0) - pose.z) <= SEAM_Z then
                    local reach = math.max(limit, math.min(mine, footprint(other)) * 0.9)
                    if horizontal(piece, pose) < reach then return true end
                end
            end
        end
    end
    return false
end

---How far a thin edge part is pushed back from the seam so that it sits ON the deck
---instead of straddling the edge line. A rail centred on the edge leaves half of its
---collision hanging over the water, which is a walkable ledge: that is what made
---players float over the water next to a dock.
---@param child table catalog entry
---@return number metres along the socket normal
local function decorInset(child)
    if not child or not child.bounds then return 0.0 end
    local sx = child.bounds.max.x - child.bounds.min.x
    local sy = child.bounds.max.y - child.bounds.min.y
    local thin = math.min(sx, sy)
    if thin > 0.5 then return 0.0 end
    return thin * 0.5
end

---An L shaped part: square footprint, small, and its origin sits at a corner of that
---footprint rather than in the middle. Only fender_corner and rail_corner match.
---@param child table catalog entry
---@return boolean
local function isCorner(child)
    local b = child and child.bounds
    if not b then return false end
    local sx, sy = b.max.x - b.min.x, b.max.y - b.min.y
    if sx > 2.6 or sy > 2.6 or math.abs(sx - sy) > 0.3 or sx <= 0.6 then return false end
    return math.min(math.abs(b.min.x), math.abs(b.max.x)) <= 0.3
        and math.min(math.abs(b.min.y), math.abs(b.max.y)) <= 0.3
end

---Rails, fenders and ropes are modelled along their local X, and a socket heading
---already points out of the seam, so at the socket heading the local X axis IS the
---seam direction and no extra turn belongs on it. Only a part whose connectors sit
---on its local Y has to be turned across the socket.
---@param child table catalog entry
---@return number align degrees on top of the socket heading
---@return boolean edgePart true when the part carries its own edge connectors
local function decorAlign(child)
    local ax, ay, edges = 0.0, 0.0, 0
    for _, socket in ipairs(child.sockets or {}) do
        if socket.type == 'edge' or socket.type == 'hinge' then
            ax = ax + math.abs(socket.x or 0.0)
            ay = ay + math.abs(socket.y or 0.0)
            edges = edges + 1
        end
    end
    return ay > ax and -90.0 or 0.0, edges > 0
end

---@return integer

---@param child table catalog entry
---@param socket table the child's own socket, in local space
---@return number metres
local function seamSpan(child, socket)
    local bounds = child and child.bounds
    if not bounds then return 0.0 end
    local sx = bounds.max.x - bounds.min.x
    local sy = bounds.max.y - bounds.min.y
    return math.abs(math.cos(math.rad(socket.heading or 0.0))) > 0.5 and sx or sy
end

---@param child table catalog entry
---@param socket table the child's own socket
---@param parentType string the type of the socket it would mount on
---@return boolean
local function seamFits(child, socket, parentType)
    if socket.type ~= 'structure' and socket.type ~= 'hangar_segment' then return false end
    if parentType ~= 'half_edge' then return true end
    return seamSpan(child, socket) <= HALF_EDGE_SPAN
end

---@param a number
---@param b number
---@return number
local function headingGap(a, b)
    local d = math.abs((a - b) % 360)
    return d > 180 and 360 - d or d
end

---How far the candidate sits off the centre of the seam, measured along the edge.
---This is what makes a 2 m part land on a half edge socket and a 4 m part on the
---edge centre, without hardcoding which socket names belong together.
local function tangentOffset(socketWorld, pose)
    local h = math.rad(socketWorld.heading or 0)
    -- socket facing is (-sin, cos), so the seam runs along (cos, sin)
    return math.abs((pose.x - socketWorld.x) * math.cos(h) + (pose.y - socketWorld.y) * math.sin(h))
end

---Finds the best snap for the aim point, or free placement when nothing fits.
---Everything is ranked by horizontal distance on the deck, so hovering height and
---the camera position never decide the seam.
---@param hit table aim point
---@return table pose
---@return table? match parent claim, nil for a corner (its socket is derived, not authored)
---@return boolean snapped true whenever the pose came from a socket
local function resolve(hit)
    local idx = socketIndex()
    local child = MarinaAssets.catalog[selected]
    local maxSnap = Config.builder.snapDistance or 2.5
    if child and DECOR_CATEGORIES[child.category] then
        -- Small parts have to land where the player is looking: with the deck radius
        -- a rail three metres away won the socket and ended up across a corner.
        maxSnap = Config.builder.snapDistanceDecor or 1.5
        -- A corner part is the exception: an outside corner is a single point and
        -- nothing else competes for it, so it keeps the wider deck reach. With the
        -- small radius an L part simply never found one.
        if isCorner(child) then maxSnap = Config.builder.snapDistance or 3.5 end
    end
    local best, match, bestScore, bestKey, snapped

    ---The seam chosen last frame keeps a discount, so two sockets that score almost
    ---the same no longer trade the preview back and forth every frame. The piece that
    ---was just placed keeps a bigger one: building continues along the chain instead
    ---of jumping to whatever other tile happens to be a few centimetres closer.
    local function consider(pose, candidate, score, key)
        if lastKey and key == lastKey then score = score - STICKY end
        if lastPlaced and candidate and candidate.parentId == lastPlaced then score = score - CONTINUE end
        if not bestScore or score < bestScore then
            best, match, bestScore, bestKey, snapped = pose, candidate, score, key, true
        end
    end

    if snapEnabled and (stage == 'piece' or stage == 'station') and (child or stage == 'station') then
        local station = stage == 'station'
        local decor = not station and DECOR_CATEGORIES[child.category] == true
        local wide = not station and (child.bounds.max.x - child.bounds.min.x) >= WIDE_PIECE
        local align, edgePart, inset, corner = 0.0, false, 0.0, false
        if decor then
            align, edgePart = decorAlign(child)
            inset = decorInset(child)
            corner = isCorner(child)
        end
        local span = math.ceil(maxSnap / CELL)
        local cx, cy = math.floor(hit.x / CELL), math.floor(hit.y / CELL)

        for gx = cx - span, cx + span do
            for gy = cy - span, cy + span do
                local bucket = idx.cells[gx .. ':' .. gy]
                for i = 1, bucket and #bucket or 0 do
                    local entry = bucket[i]
                    local flat = horizontal(hit, entry)
                    if flat <= maxSnap and not entry.claimed and not entry.shared then
                        local socket = entry.socket
                        if station then
                            if entry.type == 'structure' then
                                consider({ x = entry.x, y = entry.y, z = entry.z,
                                    heading = ((entry.heading or 0) + rotation) % 360 },
                                    { parentId = entry.pieceId, parentSocket = socket.name }, flat,
                                    entry.pieceId .. '#' .. socket.name)
                            end
                        elseif decor then
                            -- A 4 m rail belongs on the edge centre (structure socket); a 2 m
                            -- part belongs on the quarter points (edge / half_edge sockets).
                            -- A part with its own edge connectors is a railing, a fender or a
                            -- ladder: those only ever belong on an edge, never on the deck
                            -- centre, which is what the top socket is. An L shaped part only
                            -- ever belongs on a derived corner, and nothing else does.
                            local suitable
                            if corner then
                                suitable = entry.type == 'corner'
                            else
                                suitable = entry.type ~= 'corner' and (wide and entry.type == 'structure'
                                    or (not wide and (entry.type == 'edge' or entry.type == 'half_edge'
                                        or (entry.type == 'top' and not edgePart))))
                            end
                            if suitable then
                                local pose = { x = entry.x, y = entry.y, z = entry.z,
                                    heading = ((entry.heading or 0) + align + rotation) % 360 }
                                if corner then
                                    -- Both arms flush with the two edges: the origin is the inner
                                    -- corner of the L, so step in along both of them.
                                    local d = math.max(-child.bounds.min.x, -child.bounds.min.y, 0.0)
                                    if d > 0.0 then
                                        local h = math.rad(pose.heading)
                                        pose.x = pose.x + (math.cos(h) - math.sin(h)) * d
                                        pose.y = pose.y + (math.sin(h) + math.cos(h)) * d
                                    end
                                    -- The socket is derived, not authored, so it carries no claim
                                    -- the server could validate: geometry only.
                                    consider(pose, nil, flat, entry.pieceId .. '#' .. socket.name)
                                else
                                    if inset > 0.0 and entry.type ~= 'top' then
                                        -- socket normal points out of the deck, step back along it
                                        local h = math.rad(entry.heading or 0)
                                        pose.x = pose.x + math.sin(h) * inset
                                        pose.y = pose.y - math.cos(h) * inset
                                    end
                                    consider(pose, { parentId = entry.pieceId, parentSocket = socket.name }, flat,
                                        entry.pieceId .. '#' .. socket.name)
                                end
                            end
                        elseif SEAM_TYPES[entry.type] then
                            local options, byHeading = {}, {}
                            for _, own in ipairs(child.sockets or {}) do
                                if SEAM_TYPES[own.type] and seamFits(child, own, entry.type) then
                                    local pose = Math.snap(entry.piece, socket, own)
                                    if not overlaps(idx, pose, selected) then
                                        local score = flat + tangentOffset(entry, pose) * 2.0
                                            + (entry.type == 'half_edge' and HALF_EDGE_COST or 0.0)
                                        local turn = math.floor(pose.heading % 360 + 0.5) % 360
                                        local seat = byHeading[turn]
                                        if not seat then
                                            options[#options + 1] = { pose = pose, name = own.name,
                                                score = score, heading = turn }
                                            byHeading[turn] = options[#options]
                                        elseif score < seat.score then
                                            seat.pose, seat.name, seat.score = pose, own.name, score
                                        end
                                    end
                                end
                            end
                            if #options > 0 then
                                table.sort(options, function(a, b) return a.heading < b.heading end)
                                local wanted = ((M.draft.coords.heading or 0.0) + rotation) % 360
                                local chosen, pickRank
                                for _, option in ipairs(options) do
                                    local rank = headingGap(option.heading, wanted) + option.score * 4.0
                                    if not pickRank or rank < pickRank then chosen, pickRank = option, rank end
                                end
                                local headings = {}
                                for k, option in ipairs(options) do headings[k] = option.heading end
                                consider(chosen.pose, { parentId = entry.pieceId, parentSocket = socket.name,
                                    childSocket = chosen.name, headings = headings, heading = chosen.heading }, chosen.score,
                                    entry.pieceId .. '#' .. socket.name)
                            end
                        end
                    end
                end
            end
        end
    end

    if not best then
        local heading = freeHeading()
        -- The first tile defines the grid for the whole marina, so a free deck piece
        -- lands on the rotation step instead of the exact heading the player faces.
        if stage == 'station' or (child ~= nil and SOLID[child.category] == true) then
            local step = Config.builder.wheelStep or 15.0
            heading = (math.floor(heading / step + 0.5) * step) % 360
        end
        best = { x = hit.x, y = hit.y, z = hit.z, heading = heading }
        -- Decks, coast pieces and stations all live on the one deck plane.
        if stage == 'station' or (child and (child.category == 'floor' or child.category == 'coast')) then
            local z = deckHeight(hit.x, hit.y)
            if z then best.z = z end
        end
    end

    lastKey = bestKey
    seamHeadings = match and match.headings and { list = match.headings, current = match.heading } or nil
    if match then match.headings, match.heading = nil, nil end
    best.z = best.z + height
    -- A hand height offset keeps the claim: it never moves the seam horizontally,
    -- which is all the server validates, but a piece lifted clear of its host is
    -- free placement again.
    if math.abs(height) > 2.0 then match, snapped = nil, false end
    return best, match, snapped == true
end

-------------------------------------------------------------------------------
-- One predicate for the preview colour and for the click
-------------------------------------------------------------------------------

---@param pose table?
---@param snapped boolean? true when the pose came from a socket
---@param hasSurface boolean
---@return boolean ok, string? reason
local function evaluate(pose, snapped, hasSurface)
    if not pose then return false, 'no_surface' end
    if not hasSurface and not snapped then return false, 'no_surface' end

    local maxDistance = (Config.builder.maxPlacementDistance or 10.0) + (Config.builder.snapDistance or 2.5)
    if horizontal(pose, GetEntityCoords(PlayerPedId())) > maxDistance then return false, 'out_of_reach' end
    if #M.draft.pieces > 0 and Math.distance(pose, M.draft.coords) > Config.limits.buildRadius then
        return false, 'out_of_bounds'
    end

    if stage == 'station' then
        if #M.draft.stations >= Config.limits.maxStations then return false, 'station_limit' end
        local probe = MarinaAssets.station(selected, { x = pose.x, y = pose.y, z = pose.z, heading = pose.heading })
        local water = GetWaterHeight(probe.exit.x, probe.exit.y, probe.exit.z + 20.0)
        if not water then return false, 'exit_needs_water' end
    elseif stage == 'piece' then
        if #M.draft.pieces >= Config.limits.maxPieces then return false, 'piece_limit' end
        if overlaps(socketIndex(), pose, selected) then return false, 'occupied' end
        if not Config.builder.allowFreePlacement and #M.draft.pieces > 0 and not snapped then
            return false, 'snap_required'
        end
    end

    return true
end

local REASONS = {
    no_surface = 'No ground, deck or water under the preview.',
    out_of_reach = 'Too far from you.',
    out_of_bounds = 'Outside the build radius of this marina.',
    station_limit = 'Station limit reached.',
    piece_limit = 'Piece limit reached.',
    occupied = 'This position is already occupied.',
    snap_required = 'Snap this object to an existing dock socket.',
    exit_needs_water = 'The launch exit must be over water.',
}

-------------------------------------------------------------------------------
-- Placing
-------------------------------------------------------------------------------

local function place()
    if not position then return end

    local ok, reason = evaluate(position, attachSnapped, surfaceKind ~= nil)
    if not ok then
        MarinaClientBridge.notify({ type = 'error', description = REASONS[reason] or 'You cannot place that here.' })
        return
    end

    if stage == 'terminal' then
        stationDraft.terminal = clone(position)
        pushHistory()
        M.draft.stations[#M.draft.stations+1] = stationDraft
        stationDraft, stage = nil, nil
        indexInvalidate()
        M.panel()
        return
    end
    if stage == 'exit' or stage == 'pickup' or stage == 'terminal_edit' then
        pushHistory()
        stationDraft[stage == 'terminal_edit' and 'terminal' or stage] = clone(position)
        stationDraft = nil
        indexInvalidate()
        M.panel()
        return
    end
    if stage == 'station' then
        stationDraft = MarinaAssets.station(selected,clone(position))
        local _, waterZ = GetWaterHeight(stationDraft.exit.x,stationDraft.exit.y,stationDraft.exit.z+20)
        stationDraft.exit.z = waterZ
        if selected == 'boat' then stationDraft.spawn.z = waterZ end
        stationDraft.id = uid('station')
        if attach then for k,v in pairs(attach) do stationDraft[k]=v end end
        M.pendingStation = stationDraft
        M.select('ff_marina_tablet_stand','terminal')
        return
    end

    pushHistory()
    local piece = clone(position)
    piece.id, piece.asset = uid('piece'), selected
    if attach then for k,v in pairs(attach) do piece[k] = v end end
    M.draft.pieces[#M.draft.pieces+1] = piece
    lastPlaced = piece.id
    indexInvalidate()
    if #M.draft.pieces == 1 then M.draft.coords = {x=piece.x,y=piece.y,z=piece.z,heading=piece.heading} end
    PlaySoundFrontend(-1,'SELECT','HUD_FRONTEND_DEFAULT_SOUNDSET',true)
end

---Every build input, whatever saw the press. The control natives can be made blind
---by a second resource that disables the same control, and a mouse button can be
---taken by a NUI, so a key mapping and the page feed the same funnel. A key is only
---debounced across DIFFERENT sources, so one physical press never acts twice.
---@param key string
---@param source string 'control' | 'key' | 'page'
local deleteTarget, deleteEntity

local function removeById(id, kind)
    pushHistory()
    local list = kind == 'station' and M.draft.stations or M.draft.pieces
    for i, piece in ipairs(list) do if piece.id == id then table.remove(list, i) break end end
    for _, piece in ipairs(M.draft.pieces) do
        if piece.parentId == id then piece.parentId, piece.parentSocket, piece.childSocket = nil, nil, nil end
    end
    for _, station in ipairs(M.draft.stations) do
        if station.parentId == id then station.parentId, station.parentSocket = nil, nil end
    end
    if lastPlaced == id then lastPlaced = nil end
    dirty = true
    indexInvalidate()
end

local function deleteHighlight(entity)
    if deleteEntity == entity then return end
    if deleteEntity and DoesEntityExist(deleteEntity) then SetEntityDrawOutline(deleteEntity, false) end
    deleteEntity = entity
    if entity then
        SetEntityDrawOutline(entity, true)
        if lookMode == 'edit' then SetEntityDrawOutlineColor(0, 229, 180, 255) else SetEntityDrawOutlineColor(255, 70, 70, 255) end
    end
end

local lookMode = 'delete'

function M.startDelete(mode)
    if not M.active then return end
    lookMode = mode == 'edit' and 'edit' or 'delete'
    M.placing, M.pendingStation, M.deleting = false, nil, true
    ghostClear()
    stationDraft, stage = nil, nil
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
    SendNUIMessage({ action = 'deleting', mode = lookMode, count = #M.draft.pieces + #M.draft.stations })
end

function M.stopDelete()
    M.deleting = false
    deleteHighlight(nil)
    deleteTarget = nil
end

local function recordFor(entity)
    for _, record in pairs(MarinaWorld.objects or {}) do
        if record.entity == entity and record.meta then
            if record.meta.pieceId then return { id = record.meta.pieceId, kind = 'piece', entity = entity } end
            if record.meta.stationId then return { id = record.meta.stationId, kind = 'station', entity = entity } end
        end
    end
end

local deleteTraceAt = 0
local function deleteAim()
    local ped = PlayerPedId()
    local cam = GetGameplayCamCoord ~= nil and GetGameplayCamCoord() or GetEntityCoords(ped)
    local rot = GetGameplayCamRot(2)
    local yaw, pitch = math.rad(rot.z), math.rad(rot.x)
    local dir = { x = -math.sin(yaw) * math.cos(pitch), y = math.cos(yaw) * math.cos(pitch), z = math.sin(pitch) }
    local reachOut = (Config.builder.maxPlacementDistance or 10.0) + 6.0
    local handle = StartExpensiveSynchronousShapeTestLosProbe(cam.x, cam.y, cam.z,
        cam.x + dir.x * reachOut, cam.y + dir.y * reachOut, cam.z + dir.z * reachOut, 17, ped, 7)
    local _, hit, coords, _, entity = GetShapeTestResult(handle)
    local found = didHit(hit) and entity and entity ~= 0 and recordFor(entity) or nil
    local point = didHit(hit) and coords or nil
    if not found then
        local at = point or aim()
        local best, bestD
        for _, record in pairs(MarinaWorld.objects or {}) do
            if record.meta and record.entity and DoesEntityExist(record.entity) then
                local c = GetEntityCoords(record.entity)
                local d = horizontal({ x = c.x, y = c.y }, { x = at.x, y = at.y })
                if d < 2.6 and math.abs(c.z - at.z) < 3.0 and (not bestD or d < bestD) then best, bestD = record, d end
            end
        end
        if best then found = recordFor(best.entity) end
    end
    if Config.debug and GetGameTimer() - deleteTraceAt > 1000 then
        deleteTraceAt = GetGameTimer()
        print(('[marina] delete aim hit=%s entity=%s found=%s'):format(tostring(didHit(hit)), tostring(entity), found and (found.kind .. ' ' .. tostring(found.id)) or 'nil'))
    end
    return found
end


function M.input(key, source)
    if M.active and M.deleting then
        local now = GetGameTimer()
        if inputSource[key] ~= nil and inputSource[key] ~= source and now - (inputAt[key] or 0) < 250 then return end
        inputSource[key], inputAt[key] = source, now
        if key == 'confirm' then
            if deleteTarget and lookMode == 'edit' then
                local id, kind = deleteTarget.id, deleteTarget.kind
                if kind ~= 'piece' then
                    MarinaClientBridge.notify({ type = 'error', description = 'Stations are moved from the Stations tab (Tablet / Exit / Pickup).' })
                    return
                end
                local piece
                for _, p in ipairs(M.draft.pieces) do if p.id == id then piece = p break end end
                if not piece then return end
                deleteHighlight(nil)
                deleteTarget = nil
                removeById(id, kind)
                M.stopDelete()
                M.select(piece.asset, 'piece')
                rotation = ((piece.heading or 0) - (M.draft.coords.heading or 0)) % 360
                MarinaClientBridge.notify({ type = 'inform', description = 'Picked up. Place it again, scroll to rotate.' })
            elseif deleteTarget then
                local id, kind = deleteTarget.id, deleteTarget.kind
                deleteHighlight(nil)
                deleteTarget = nil
                removeById(id, kind)
                MarinaClientBridge.notify({ type = 'success', description = kind == 'station' and 'Station removed.' or 'Object removed.' })
                SendNUIMessage({ action = 'deleting', mode = lookMode, count = #M.draft.pieces + #M.draft.stations })
            end
        elseif key == 'palette' then
            M.stopDelete()
            M.panel()
        end
        return
    end
    if not (M.active and M.placing) then return end
    local now = GetGameTimer()
    if inputSource[key] ~= nil and inputSource[key] ~= source and now - (inputAt[key] or 0) < 250 then
        return
    end
    inputSource[key], inputAt[key] = source, now
    if source ~= 'control' then taps[source == 'key' and 'key' or 'page'] = taps[source == 'key' and 'key' or 'page'] + 1 end
    if Config.debug then print(('[marina] input %s via %s'):format(tostring(key), source)) end

    if key == 'confirm' then
        if ghost then place()
        else MarinaClientBridge.notify({ type = 'error', description = 'The preview is still loading.' }) end
    elseif key == 'rotate' or key == 'rotateback' then
        local step = key == 'rotate' and Config.builder.rotationStep or -Config.builder.rotationStep
        if seamHeadings and #seamHeadings.list > 1 then
            local list, at = seamHeadings.list, 1
            for k, h in ipairs(list) do if h == seamHeadings.current then at = k end end
            local target = list[(at - 1 + (step > 0 and 1 or -1)) % #list + 1]
            rotation = (target - (M.draft.coords.heading or 0.0)) % 360
        else
            rotation = (rotation + step) % 360
        end
    elseif key == 'fine' then rotation = (rotation + 5) % 360
    elseif key == 'fineback' then rotation = (rotation - 5) % 360
    elseif key == 'wheelup' then rotation = (rotation + (Config.builder.wheelStep or 15.0)) % 360
    elseif key == 'wheeldown' then rotation = (rotation - (Config.builder.wheelStep or 15.0)) % 360
    elseif key == 'snap' then snapEnabled = not snapEnabled
    elseif key == 'up' then height = height + Config.builder.fineStep
    elseif key == 'down' then height = height - Config.builder.fineStep
    elseif key == 'near' then
        reach = math.max(Config.builder.minPlacementDistance or 1.5, reach - 0.5)
    elseif key == 'far' then
        reach = math.min(Config.builder.maxPlacementDistance or 10.0, reach + 0.5)
    elseif key == 'palette' then M.panel()
    end
end

-- Key mappings are handled by the CFX input layer, so they arrive even when the
-- control natives report nothing. All rebindable under Settings, Key bindings, FiveM.
local BINDS = {
    { 'marinaplace', 'confirm', 'Marina creator: place object', 'MOUSE_BUTTON', 'MOUSE_LEFT', true },
    { 'marinaplacekey', 'confirm', 'Marina creator: place object (keyboard)', 'keyboard', 'E', true },
    { 'marinarotate', 'rotate', 'Marina creator: rotate', 'keyboard', 'R' },
    { 'marinafine', 'fine', 'Marina creator: fine rotate', 'keyboard', 'T' },
    { 'marinasnap', 'snap', 'Marina creator: toggle snapping', 'keyboard', 'G' },
    { 'marinaup', 'up', 'Marina creator: raise', 'keyboard', 'PAGEUP' },
    { 'marinadown', 'down', 'Marina creator: lower', 'keyboard', 'PAGEDOWN' },
    { 'marinawheelup', 'wheelup', 'Marina creator: rotate (wheel up)', 'MOUSE_WHEEL', 'IOM_WHEEL_UP' },
    { 'marinawheeldown', 'wheeldown', 'Marina creator: rotate (wheel down)', 'MOUSE_WHEEL', 'IOM_WHEEL_DOWN' },
    { 'marinanear', 'near', 'Marina creator: pull closer', 'keyboard', 'Z' },
    { 'marinafar', 'far', 'Marina creator: push away', 'keyboard', 'X' },
    { 'marinapalette', 'palette', 'Marina creator: palette', 'keyboard', 'TAB' },
}
for _, bind in ipairs(BINDS) do
    local command, key, label, mapper, default, hold = bind[1], bind[2], bind[3], bind[4], bind[5], bind[6]
    if hold then
        RegisterCommand('+' .. command, function() M.input(key, 'key') end, false)
        RegisterCommand('-' .. command, function() end, false)
        command = '+' .. command
    else
        RegisterCommand(command, function() M.input(key, 'key') end, false)
    end
    if RegisterKeyMapping then RegisterKeyMapping(command, label, mapper, default) end
end

RegisterCommand('marinasnapdiag', function()
    local ped = GetEntityCoords(PlayerPedId())
    local placing = M.active and M.placing
    if placing then
        local hit, hasSurface, kind = aim()
        print(('[marina] stage=%s sel=%s pieces=%d stations=%d snap=%s reach=%.1f rotation=%.0f'):format(
            tostring(stage), tostring(selected), #M.draft.pieces, #M.draft.stations, tostring(snapEnabled), reach, rotation))
        print(('[marina] ped=(%.2f %.2f %.2f) target=(%.2f %.2f %.2f) surface=%s kind=%s draftZ=%.2f draftH=%.0f'):format(
            ped.x, ped.y, ped.z, hit.x, hit.y, hit.z, tostring(hasSurface), tostring(kind), M.draft.coords.z or 0, M.draft.coords.heading or 0))
    else
        print(('[marina] ped=(%.2f %.2f %.2f) creator=%s'):format(ped.x, ped.y, ped.z, tostring(M.active)))
    end
    local probe = StartExpensiveSynchronousShapeTestLosProbe(ped.x, ped.y, ped.z + 0.2, ped.x, ped.y, ped.z - 3.0, 17, PlayerPedId(), 7)
    local _, under, underAt, _, underEntity = GetShapeTestResult(probe)
    local model = didHit(under) and underEntity and underEntity ~= 0 and GetEntityModel(underEntity) or nil
    print(('[marina] under ped: hit=%s at z=%.2f entity=%s model=%s heightAboveGround=%.2f'):format(
        tostring(didHit(under)), underAt and underAt.z or 0, tostring(underEntity), tostring(model),
        GetEntityHeightAboveGround and GetEntityHeightAboveGround(PlayerPedId()) or -1))
    for key, record in pairs(MarinaWorld.objects or {}) do
        if record.entity and DoesEntityExist(record.entity) then
            local c = GetEntityCoords(record.entity)
            if #(c - vector3(ped.x, ped.y, ped.z)) < 4.0 then
                print(('[marina]  prop %s at=(%.2f %.2f %.2f) h=%.0f collision=%s'):format(tostring(record.model), c.x, c.y, c.z,
                    GetEntityHeading(record.entity), tostring(GetEntityCollisionDisabled ~= nil and not GetEntityCollisionDisabled(record.entity))))
            end
        end
    end
    if not placing then return end
    local hit = aim()
    local idx = socketIndex()
    local near = {}
    for _, bucket in pairs(idx.cells) do
        for _, entry in ipairs(bucket) do
            near[#near + 1] = { d = horizontal(hit, entry), e = entry }
        end
    end
    table.sort(near, function(a, b) return a.d < b.d end)
    for i = 1, math.min(8, #near) do
        local e = near[i].e
        print(('[marina]  socket %s#%s type=%s d=%.2f at=(%.2f %.2f %.2f) h=%.0f claimed=%s shared=%s'):format(
            tostring(e.pieceId), tostring(e.socket and e.socket.name), tostring(e.type), near[i].d, e.x, e.y, e.z, e.heading or 0,
            tostring(e.claimed), tostring(e.shared)))
    end
    for i, piece in ipairs(M.draft.pieces) do
        if i <= 6 then print(('[marina]  piece %s %s at=(%.2f %.2f %.2f) h=%.0f'):format(tostring(piece.id), tostring(piece.asset), piece.x, piece.y, piece.z, piece.heading or 0)) end
    end
end, false)

RegisterCommand(Config.command,function()
    if M.active then M.panel(); return end
    CreateThread(function()
        local data = MarinaRPC.call('snapshot',{})
        if not data or not data.ok then MarinaClientBridge.notify(data and data.error or 'Connection failed.'); return end
        MarinaWorld.receive(data)
        SetNuiFocus(true,true)
        SendNUIMessage({action='manager',marinas=data.marinas,admin=data.admin,roles=data.roles})
    end)
end,false)

RegisterNUICallback('builder',function(data,cb)
    local op = data.operation
    if op == 'new' then
        local snapshot = MarinaRPC.call('snapshot',{})
        if not snapshot or not snapshot.admin then cb({ok=false,error='Administrator permission required.'}); return end
        local p = GetEntityCoords(PlayerPedId())
        M.start({id=uid('draft'),revision=0,name=data.name or 'New marina',mode=data.mode or 'public',purchasePrice=Config.business.defaultPurchasePrice,coords={x=p.x,y=p.y,z=p.z-1,heading=GetEntityHeading(PlayerPedId())},blip={enabled=true,sprite=410,color=3,scale=0.75},pieces={},stations={}})
    elseif op == 'edit' then
        local result = MarinaRPC.call('edit',{id=data.id})
        if not result.ok then cb(result); return end
        M.start(result.editable or result.marina)
    elseif op == 'close' then M.close()
    elseif op == 'delete' then
        local result = MarinaRPC.call('delete',{id=data.id}); cb(result); return
    elseif not M.active then cb({ok=false,error='Creator is not open.'}); return
    elseif op == 'select' then
        if data.asset == 'jetski' or data.asset == 'boat' then M.select(data.asset,'station')
        elseif MarinaAssets.catalog[data.asset] then M.select(data.asset) end
    elseif op == 'input' then
        -- Placement keys as seen by the page: while any NUI keeps the cursor, the game
        -- never receives the press at all.
        M.input(data.key == 'rotate' and data.fine and 'fine' or data.key, 'page')
    elseif op == 'panel' then M.panel()
    elseif op == 'settings' then
        pushHistory()
        M.draft.name = tostring(data.name or M.draft.name):sub(1,64)
        M.draft.mode = data.mode or M.draft.mode
        M.draft.purchasePrice = tonumber(data.purchasePrice) or M.draft.purchasePrice
        M.draft.blip = data.blip or M.draft.blip
        M.panel()
    elseif op == 'remove' then
        removeById(data.id, data.kind)
        M.panel()
    elseif op == 'lookdelete' then
        M.startDelete('delete')
    elseif op == 'lookedit' then
        M.startDelete('edit')
    elseif op == 'anchor' then
        for _, station in ipairs(M.draft.stations) do
            if station.id == data.id and (data.anchor == 'exit' or data.anchor == 'pickup' or data.anchor == 'terminal') then
                stationDraft = station
                M.select(data.anchor == 'terminal' and 'ff_marina_tablet_stand' or 'ff_marina_bollard',data.anchor == 'terminal' and 'terminal_edit' or data.anchor)
                break
            end
        end
    elseif op == 'undo' then
        local last = table.remove(history)
        if last then M.draft = last; dirty = true end
        indexInvalidate()
        M.panel()
    elseif op == 'save' then
        local result = MarinaRPC.call(M.draft.revision == 0 and 'create' or 'save',M.draft)
        if result.ok then
            dirty = false
            M.close()
            MarinaClientBridge.notify({type='success',description='Marina saved. All players receive the updated layout.'})
            local snapshot = MarinaRPC.call('snapshot',{}); if snapshot.ok then MarinaWorld.receive(snapshot) end
        end
        cb(result); return
    end
    cb({ok=true})
end)

-------------------------------------------------------------------------------
-- Preview loop
-------------------------------------------------------------------------------

---Preview extents for a model. The authored catalogue is exact, but station
---assemblies also use parts that are not catalogue entries, so those are measured
---at runtime instead of being guessed.
local dimensionCache = {}
local function boundsFor(model)
    local asset = MarinaAssets.catalog[model]
    if asset and asset.bounds then return asset.bounds end
    if dimensionCache[model] then return dimensionCache[model] end

    local ok, mn, mx = pcall(GetModelDimensions, joaat(model))
    if ok and type(mn) == 'table' and type(mx) == 'table' and mx.z then
        dimensionCache[model] = { min = { x = mn.x, y = mn.y, z = mn.z }, max = { x = mx.x, y = mx.y, z = mx.z } }
        return dimensionCache[model]
    end
    return { min = { x = -0.5, y = -0.5, z = 0.0 }, max = { x = 0.5, y = 0.5, z = 1.0 } }
end

---Translucent box around the preview, red when the placement is refused. Together
---with the entity outline this is what the player actually reads; the ghost model
---itself keeps its own textures, so no shared texture is ever replaced.
local function drawBounds(pose, model, r, g, b, valid)
    local bounds = boundsFor(model)
    if not bounds then return end

    local h = math.rad(pose.heading or 0)
    local c, s = math.cos(h), math.sin(h)
    local minX, minY, maxX, maxY
    for _, corner in ipairs({ { bounds.min.x, bounds.min.y }, { bounds.max.x, bounds.min.y },
        { bounds.max.x, bounds.max.y }, { bounds.min.x, bounds.max.y } }) do
        local x = pose.x + corner[1] * c - corner[2] * s
        local y = pose.y + corner[1] * s + corner[2] * c
        minX = math.min(minX or x, x) maxX = math.max(maxX or x, x)
        minY = math.min(minY or y, y) maxY = math.max(maxY or y, y)
    end

    DrawBox(minX, minY, pose.z + bounds.min.z, maxX, maxY, pose.z + bounds.max.z, r, g, b, valid and 60 or 90)
end

local held, armed, placingLast, traceAt = {}, {}, false, 0

---Every signal the game offers for one control. IsDisabledControlJustPressed on its
---own drops the frame whenever a second resource disables the same control, and the
---undisabled pair still reports a press the disabled pair can miss.
local function isDown(control)
    if IsDisabledControlPressed(0, control) == true then return true end
    return IsControlPressed ~= nil and IsControlPressed(0, control) == true
end

local function isJust(control)
    if IsDisabledControlJustPressed(0, control) == true then return true end
    return IsControlJustPressed ~= nil and IsControlJustPressed(0, control) == true
end

---A press, rebuilt from the held state when the edge itself went missing. Only on
---the press, never on the release, and nothing that was already held when placement
---started counts: the palette is clicked with the same button.
local function tapped(control)
    local down, just = isDown(control), isJust(control)
    if not armed[control] then
        if just or not down then armed[control] = true end
        held[control] = down
        return just == true
    end
    local rise = just or (down and not held[control])
    held[control] = down or just
    if rise and taps[control] then taps[control] = taps[control] + 1 end
    return rise == true
end

CreateThread(function()
    while true do
        if M.active and M.deleting then
            for _, control in ipairs({14,15,16,17,24,25,37,44,45,47,140,141,142,143,257,263,264}) do
                DisableControlAction(0, control, true)
            end
            DisablePlayerFiring(PlayerId(), true)
            if IsNuiFocused ~= nil and IsNuiFocused() then SetNuiFocus(false, false) SetNuiFocusKeepInput(false) end
            deleteTarget = deleteAim()
            deleteHighlight(deleteTarget and deleteTarget.entity or nil)
            if tapped(24) or tapped(38) then M.input('confirm', 'control') end
            if tapped(200) or tapped(37) then M.input('palette', 'control') end
            if IsEntityDead(PlayerPedId()) then M.close() end
            Wait(0)
        else
            if deleteEntity then deleteHighlight(nil) end
            Wait(250)
        end
    end
end)

CreateThread(function()
    while true do
        if M.active and M.placing then
            if not placingLast then held, armed, placingLast = {}, {}, true end
            -- Keep native walking, sprinting, jumping and mouse look intact.
            -- Block only actions that conflict with placement (shoot/reload/etc.).
            for _, control in ipairs({14,15,16,17,19,24,25,26,36,37,38,44,45,47,140,141,142,143,172,173,200,257,263,264}) do
                DisableControlAction(0,control,true)
            end
            DisablePlayerFiring(PlayerId(),true)
            -- A NUI that still owns the cursor swallows every mouse button and key
            -- before the game sees it, so the placement loop insists on its own state.
            if IsNuiFocused ~= nil and IsNuiFocused() then
                SetNuiFocus(false, false)
                SetNuiFocusKeepInput(false)
            end
            if Config.debug then tapped(32) end
            if tapped(45) then
                M.input(IsDisabledControlPressed(0,19) and 'fine' or 'rotate', 'control')
            end
            if tapped(47) then M.input('snap', 'control') end
            if tapped(172) then M.input('up', 'control') end
            if tapped(173) then M.input('down', 'control') end
            if tapped(14) then M.input(IsDisabledControlPressed(0,19) and 'fineback' or 'wheeldown', 'control') end
            if tapped(15) then M.input(IsDisabledControlPressed(0,19) and 'fine' or 'wheelup', 'control') end

            local hit, hasSurface, kind = aim()
            surfaceKind = hasSurface and kind or nil
            position, attach, attachSnapped = resolve(hit)
            local reason
            placementValid, reason = evaluate(position, attachSnapped, hasSurface)

            local mode = (not snapEnabled and 'off') or (attachSnapped and 'snap' or 'free')
            if mode ~= lastMode then
                lastMode = mode
                SendNUIMessage({ action = 'mode', mode = mode })
            end

            -- Mint is a real socket, amber is free placement. The gap people report
            -- comes from free placing while believing the piece snapped.
            local r, g, b = 255, 60, 60
            if placementValid then
                if attachSnapped then r, g, b = 0, 229, 180 else r, g, b = 255, 200, 90 end
            end

            if ghost then
                if #ghostParts == 0 then MarinaWorld.place(ghost,position,{0,0,0}) end
                SetEntityAlpha(ghost, placementValid and 170 or 120, false)
                for _, part in ipairs(ghostParts) do
                    MarinaWorld.place(part.entity,position,part.position,part.q)
                    SetEntityAlpha(part.entity, placementValid and 170 or 120, false)
                end
                -- One colour for the whole preview, including every assembly part.
                SetEntityDrawOutlineColor(r, g, b, 255)
            end

            if Config.builder.showBounds then
                if #ghostParts == 0 then
                    drawBounds(position, selected, r, g, b, placementValid)
                else
                    for _, part in ipairs(ghostParts) do
                        local world = Math.world(position, { x = part.position[1], y = part.position[2], z = part.position[3] })
                        drawBounds({ x = world.x, y = world.y, z = world.z, heading = position.heading },
                            part.model, r, g, b, placementValid)
                    end
                end
            end

            DrawMarker(28,position.x,position.y,position.z,0,0,0,0,0,0,0.12,0.12,0.12,r,g,b,190,false,false,2,false,nil,nil,false)
            if stage == 'station' and selected then
                local probe = MarinaAssets.station(selected, position)
                local sp, ex, pk = probe.spawn, probe.exit, probe.pickup
                DrawLine(sp.x, sp.y, sp.z + 0.6, ex.x, ex.y, ex.z + 0.6, r, g, b, 220)
                DrawLine(ex.x, ex.y, ex.z + 0.6, pk.x, pk.y, pk.z + 0.6, r, g, b, 120)
                for i = 1, 4 do
                    local f = i / 5
                    DrawMarker(20, sp.x + (ex.x - sp.x) * f, sp.y + (ex.y - sp.y) * f, sp.z + (ex.z - sp.z) * f + 0.6,
                        0, 0, 0, 90.0, 0, ((probe.root.heading or 0) + 180) % 360, 0.9, 0.9, 0.9, r, g, b, 200, false, false, 2, false, nil, nil, false)
                end
                DrawMarker(25, ex.x, ex.y, ex.z + 0.05, 0, 0, 0, 0, 0, 0, 3.0, 3.0, 0.5, r, g, b, 140, false, false, 2, false, nil, nil, false)
                DrawMarker(25, pk.x, pk.y, pk.z + 0.05, 0, 0, 0, 0, 0, 0, 2.0, 2.0, 0.5, 255, 255, 255, 90, false, false, 2, false, nil, nil, false)
            end
            -- Left click or E: a mouse button can be swallowed while any NUI still
            -- owns the cursor, so the keyboard confirm is always available too.
            local confirm = tapped(24)
            if tapped(38) or confirm then M.input('confirm', 'control') end
            local backOut = tapped(37)
            if tapped(200) or backOut then M.input('palette', 'control') end
            if Config.debug and GetGameTimer() - traceAt > 1000 then
                traceAt = GetGameTimer()
                local gx, gy, gz, gh = 0.0, 0.0, 0.0, 0.0
                if ghost and DoesEntityExist(ghost) then
                    local c = GetEntityCoords(ghost)
                    gx, gy, gz, gh = c.x, c.y, c.z, GetEntityHeading(ghost)
                end
                print(('[marina] nui=%s/%s ctrl=%s stage=%s sel=%s parts=%d reach=%.1f valid=%s reason=%s lmb=%s/%s e=%s/%s')
                    :format(tostring(IsNuiFocused ~= nil and IsNuiFocused()),
                        tostring(IsNuiFocusKeepingInput ~= nil and IsNuiFocusKeepingInput()),
                        tostring(IsPlayerControlOn ~= nil and IsPlayerControlOn(PlayerId())),
                        tostring(stage), tostring(selected), #ghostParts, reach,
                        tostring(placementValid), tostring(reason),
                        tostring(isDown(24)), tostring(isJust(24)), tostring(isDown(38)), tostring(isJust(38))))
                local objects = 0
                for _ in pairs(MarinaWorld.objects or {}) do objects = objects + 1 end
                print(('[marina] ghost=(%.2f %.2f %.2f h=%.1f) target=(%.2f %.2f %.2f h=%.1f) pieces=%d streamed=%d')
                    :format(gx, gy, gz, gh, position.x, position.y, position.z, position.heading or 0.0,
                        #M.draft.pieces, objects))
                -- W is never disabled here: if it counts and the rest does not, the
                -- press is being taken before the control natives see it.
                print(('[marina] presses lmb=%d e=%d w=%d keybind=%d page=%d')
                    :format(taps[24], taps[38], taps[32], taps.key, taps.page))
            end
            if IsEntityDead(PlayerPedId()) then M.close() end
            Wait(0)
        else
            placingLast = false
            Wait(250)
        end
    end
end)

AddEventHandler('onResourceStop',function(name) if name == GetCurrentResourceName() then M.close() end end)
