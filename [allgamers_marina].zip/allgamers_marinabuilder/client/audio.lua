-- Local positional audio, sampled from the same server-authoritative stages.
-- No sound event is sent over the network on each frame.
CreateThread(function()
    local settings = MarinaConfig.audio
    if not settings.enabled then return end
    local playing = {}
    while true do
        local wanted = {}
        local camera,rotation = GetFinalRenderedCamCoord(),GetFinalRenderedCamRot(2)
        local yaw,pitch = math.rad(rotation.z),math.rad(rotation.x)
        local fx,fy,fz = -math.sin(yaw)*math.cos(pitch),math.cos(yaw)*math.cos(pitch),math.sin(pitch)
        local rx,ry = math.cos(yaw),math.sin(yaw)
        for key,entry in pairs(MarinaWorld.stations) do
            local travel = MarinaWorld.travels[key]
            if travel then
                local phase,duration = travel.phase,travel.duration
                if phase == 'active' then phase,duration = 'closing',MarinaConfig.rental.closingSeconds*1000 end
                local elapsed = MarinaWorld.now()-travel.phaseAt
                local file = settings[phase]
                local p = entry.station.root
                local dx,dy,dz = p.x-camera.x,p.y-camera.y,p.z-camera.z
                if file and elapsed >= 0 and elapsed < duration and dx*dx+dy*dy+dz*dz < settings.distance^2 then
                    local id = key .. ':' .. tostring(travel.rentalId) .. ':' .. phase
                    wanted[id]=true
                    SendNUIMessage({action='marinaAudio',id=id,file=file,offset=elapsed/1000,
                        volume=settings.volume,ref=settings.referenceDistance,max=settings.distance,
                        x=dx*rx+dy*ry,y=dx*ry*fz-dy*rx*fz+dz*(rx*fy-ry*fx),z=-(dx*fx+dy*fy+dz*fz)})
                end
            end
        end
        for id in pairs(playing) do if not wanted[id] then SendNUIMessage({action='marinaAudio',id=id,stop=true}) end end
        playing=wanted
        Wait(next(wanted) and 100 or 500)
    end
end)
