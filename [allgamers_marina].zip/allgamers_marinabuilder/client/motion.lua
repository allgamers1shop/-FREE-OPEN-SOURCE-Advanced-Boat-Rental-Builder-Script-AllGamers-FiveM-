-- Only animate local props and the current network owner's rented boat.
-- Every client uses the same phase timestamp; no per-frame network events.
local World, Math, Config = MarinaWorld, MarinaMath, MarinaConfig
local seenPhase = {}

local function applyParts(entry, openness)
    local samples = MarinaAssets.animations.samples
    local frame = 1 + Math.clamp(openness,0,1) * (#samples-1)
    local low = math.floor(frame)
    local a,b = samples[low],samples[math.min(low+1,#samples)]
    for model,key in pairs(entry.parts) do
        local object = World.objects[key]
        local pa,pb = a.parts[model],b.parts[model]
        if object and pa and pb and object.openness ~= openness then
            local pos = {}
            for i=1,3 do pos[i]=Math.lerp(pa.position[i],pb.position[i],frame-low) end
            World.place(object.entity,entry.station.root,pos,Math.nlerp(pa.quaternion_wxyz,pb.quaternion_wxyz,frame-low))
            object.openness = openness
        end
    end
end

---@param vehicle number
---@param moving boolean
---@param mine boolean true when this is the local player's rental
local function applyFlags(vehicle,moving,mine)
    FreezeEntityPosition(vehicle,moving)
    SetEntityInvincible(vehicle,moving)
    SetEntityCollision(vehicle,not moving,true)
    if not moving then
        SetEntityVisible(vehicle,true,false)
    end
    if NetworkHasControlOfEntity(vehicle) then
        SetVehicleDoorsLocked(vehicle,moving and 2 or 1)
        if not moving then SetVehicleFuelLevel(vehicle,100.0) end
        return true
    end
    if not moving and mine then
        NetworkRequestControlOfEntity(vehicle)
        SetVehicleDoorsLocked(vehicle,1)
        return NetworkHasControlOfEntity(vehicle) == true
    end
    return true
end

local function applyVehicle(t,entry,progress)
    if not t.netId or not NetworkDoesEntityExistWithNetworkId(t.netId) then return end
    local vehicle = NetToVeh(t.netId)
    if vehicle == 0 or not DoesEntityExist(vehicle) then return end
    local key = tostring(t.rentalId or t.id) .. ':' .. t.phase
    local moving = t.phase ~= 'active' and t.phase ~= 'idle'
    if seenPhase[vehicle] ~= key then
        local rental = World.rental
        if applyFlags(vehicle,moving,rental ~= nil and rental ~= false and rental.netId == t.netId) then
            seenPhase[vehicle] = key
        end
    end
    -- Passive peers never fight the current owner for network control.
    if not NetworkHasControlOfEntity(vehicle) then return end
    local station = entry.station
    local offset = (MarinaAssets.vehicle(t.vehicleId) or {}).originOffset or 0
    if t.phase == 'opening' then
        local p,pitch = station.spawn,0
        if station.kind == 'jetski' then p,pitch = MarinaAssets.rampAnchor(station.root,progress) end
        SetEntityCoordsNoOffset(vehicle,p.x,p.y,p.z+offset,false,false,false)
        SetEntityRotation(vehicle,pitch,0,station.root.heading or 0,2,true)
    elseif t.phase == 'launching' or t.phase == 'returning' then
        local from,to = station.spawn,station.exit
        local rampPitch = 0
        if station.kind == 'jetski' then from,rampPitch=MarinaAssets.rampAnchor(station.root,1) end
        local amount = progress
        if t.phase == 'returning' then
            -- Let the ramp/door open before pulling the empty vehicle inward.
            amount = 1-Math.clamp((progress-0.35)/0.65,0,1)
        end
        local smooth = amount*amount*(3-2*amount)
        local p = Math.pointLerp(from,to,smooth)
        local pitch = rampPitch * (1-smooth)
        SetEntityCoordsNoOffset(vehicle,p.x,p.y,p.z+offset,false,false,false)
        SetEntityRotation(vehicle,pitch,0,station.root.heading or 0,2,true)
        SetEntityVelocity(vehicle,0,0,0)
    end
end

CreateThread(function()
    while true do
        local active = false
        for key,entry in pairs(World.stations) do
            local t = World.travels[key]
            local openness = 0
            if t then
                local progress = Math.clamp((World.now()-(t.phaseAt or World.now()))/math.max(1,t.duration or 8000),0,1)
                if t.phase == 'opening' then openness=progress
                elseif t.phase == 'launching' then openness=1
                elseif t.phase == 'returning' then openness=Math.clamp(progress/0.35,0,1)
                elseif t.phase == 'closing' then openness=1-progress
                elseif t.phase == 'active' then openness=1-Math.clamp((World.now()-t.phaseAt)/(Config.rental.closingSeconds*1000),0,1) end
                applyVehicle(t,entry,progress)
                if t.phase ~= 'idle' and (t.phase ~= 'active' or openness>0) then active=true end
            end
            applyParts(entry,openness)
        end
        Wait(active and 0 or 300)
    end
end)

CreateThread(function()
    local done = {}
    while true do
        local delay = 1500
        local rental = World.rental
        if rental and rental.phase == 'active' and rental.id and not done[rental.id] and rental.netId then
            if NetworkDoesEntityExistWithNetworkId(rental.netId) then
                local vehicle = NetToVeh(rental.netId)
                if vehicle ~= 0 and DoesEntityExist(vehicle) then
                    if applyFlags(vehicle,false,true) then done[rental.id] = true end
                end
            end
            delay = 300
        elseif not rental then
            done = {}
        end
        Wait(delay)
    end
end)

-- A return prompt works independently of the tablet. Engine state is irrelevant.
CreateThread(function()
    local cooldown = 0
    while true do
        local delay, candidate, hint = 500,nil,nil
        local ped = PlayerPedId()
        local p = GetEntityCoords(ped)
        if not MarinaDui.active and not MarinaBuilder.active and not IsEntityDead(ped) then
            local rental = World.rental
            if rental and rental.phase == 'active' and rental.netId and NetworkDoesEntityExistWithNetworkId(rental.netId) then
                local vehicle = NetToVeh(rental.netId)
                for _,entry in pairs(World.stations) do
                    if entry.marina.id == rental.marinaId and entry.station.kind == (MarinaAssets.vehicle(rental.vehicleId) or {}).kind then
                        if Math.distance(GetEntityCoords(vehicle),entry.station.exit)<Config.rental.returnDistance and Math.distance(p,entry.station.exit)<Config.rental.returnDistance+5 then
                            if IsPedInVehicle(ped,vehicle,false) then hint='Park here, then step out to return your rental'
                            else candidate=entry; hint='Return rental · deposit calculated automatically' end
                            break
                        end
                    end
                end
            end
            if not candidate and not hint then
                for _,entry in pairs(World.stations) do
                    if Math.distance(p,entry.station.terminal)<Config.rental.interactionDistance and MarinaClientBridge.usesKey() then
                        candidate=entry; hint=entry.marina.name .. ' · rentals & business'; break
                    end
                end
            end
        end
        MarinaClientBridge.prompt(hint,candidate and 'E' or nil)
        if candidate then
            delay=0
            if IsControlJustReleased(0,38) and GetGameTimer()>cooldown then
                cooldown=GetGameTimer()+1000
                if hint:find('Return rental',1,true) then
                    local result=MarinaRPC.call('return',{marinaId=candidate.marina.id,stationId=candidate.station.id})
                    MarinaClientBridge.notify({type=result.ok and 'success' or 'error',description=result.ok and 'Return accepted. Your marina is recovering the vehicle.' or result.error})
                else MarinaDui.open(candidate.marina.id,candidate.station.id) end
            end
        end
        Wait(delay)
    end
end)
