-- Real CEF-to-texture DUI. NUI is only an invisible mouse/keyboard relay.
-- Shared replacements show the neutral attract screen. The selected tablet's
-- private menu is drawn on its own physical plane, not every nearby screen.
MarinaDui = { active = false }
local M, Math, Config = MarinaDui, MarinaMath, MarinaConfig
local resource = GetCurrentResourceName()
local handles, readyPages = {}, {}
local txdName = 'marina_dui_' .. GetGameTimer()
local runtimeTxd, camera, current, creating, busy = nil,nil,nil,false,false
local corners, txdSerial = nil, 0
local SCREEN_MODELS <const> = { 'ff_marina_tablet_stand', 'ff_marina_tablet_wall',
    'ff_marina_sign_pylon', 'ff_marina_sign_overhead' }

local function screenCorners(root)
    return {
        Math.world(root,{x=-0.23,y=-0.080,z=1.3925}),
        Math.world(root,{x=0.23,y=-0.080,z=1.3925}),
        Math.world(root,{x=-0.23,y=-0.080,z=1.0275}),
        Math.world(root,{x=0.23,y=-0.080,z=1.0275}),
    }
end
local function send(kind,payload)
    if handles[kind] and IsDuiAvailable(handles[kind]) then SendDuiMessage(handles[kind],json.encode(payload)) end
end

local function destroy()
    RemoveReplaceTexture('ff_marina_shared','ffm_dui_tablet_screen_d')
    RemoveReplaceTexture('ff_marina_shared','ffm_dui_capsule_sign_d')
    RemoveReplaceTexture('ff_marina_shared','ffm_dui_hangar_sign_d')
    for _,handle in pairs(handles) do DestroyDui(handle) end
    handles,readyPages = {},{}
    runtimeTxd = nil
end

function M.ensure()
    if handles.service and readyPages.service then return true end
    if creating then return false end
    creating = true
    if not runtimeTxd then
        txdSerial = txdSerial + 1
        txdName = ('marina_dui_%d_%d'):format(GetGameTimer(), txdSerial)
        runtimeTxd = CreateRuntimeTxd(txdName)
    end
    local SIZES <const> = { sign = { 1800, 300 }, pylon = { 600, 1160 } }
    for _,kind in ipairs({'idle','idlejet','service','sign','pylon'}) do
        if not handles[kind] then
            local size = SIZES[kind]
            handles[kind] = CreateDui(('https://cfx-nui-%s/web/dui.html?resource=%s&kind=%s'):format(resource,resource,kind),size and size[1] or Config.display.width,size and size[2] or Config.display.height)
            local deadline=GetGameTimer()+10000
            while (not IsDuiAvailable(handles[kind]) or not readyPages[kind]) and GetGameTimer()<deadline do Wait(30) end
            if not IsDuiAvailable(handles[kind]) or not readyPages[kind] then
                destroy(); creating=false; return false
            end
            CreateRuntimeTextureFromDuiHandle(runtimeTxd,kind,GetDuiHandle(handles[kind]))
            send(kind,{action='config',display=Config.display})
        end
    end
    AddReplaceTexture('ff_marina_shared','ffm_dui_tablet_screen_d',txdName,'idle')
    AddReplaceTexture('ff_marina_shared','ffm_dui_capsule_sign_d',txdName,'pylon')
    AddReplaceTexture('ff_marina_shared','ffm_dui_hangar_sign_d',txdName,'sign')
    if MarinaWorld and MarinaWorld.restream then MarinaWorld.restream(SCREEN_MODELS) end
    creating=false
    return true
end

function M.prime()
    if creating or (handles.service and readyPages.service) then return end
    CreateThread(function() M.ensure() end)
end

function M.close()
    M.active,current,busy=false,nil,false
    send('service',{action='idle'})
    SendNUIMessage({action='duiInput',enabled=false})
    SetNuiFocus(false,false); SetNuiFocusKeepInput(false)
    if camera then RenderScriptCams(false,true,300,true,true); DestroyCam(camera,false); camera=nil end
end

function M.open(marinaId,stationId)
    if M.active or creating or busy or MarinaBuilder.active then return end
    busy=true
    if not M.ensure() then busy=false; MarinaClientBridge.notify('Tablet is loading. Please try again.'); return end
    local response=MarinaRPC.call('menu',{marinaId=marinaId,stationId=stationId})
    busy=false
    if not response or not response.ok then MarinaClientBridge.notify(response and response.error or 'Connection failed.'); return end
    local entry=MarinaWorld.stations[tostring(marinaId)..':'..tostring(stationId)]
    if not entry then return end
    current={marinaId=marinaId,stationId=stationId,terminal=entry.station.terminal}
    local root=current.terminal
    current.terminalStation=entry.station
    local centre=Math.world(root,{x=0,y=-0.079,z=1.21})
    local eye=Math.world(root,{x=0,y=-0.079-Config.display.cameraDistance,z=1.21})
    corners=screenCorners(root)
    camera=CreateCam('DEFAULT_SCRIPTED_CAMERA',true)
    SetCamCoord(camera,eye.x,eye.y,eye.z); PointCamAtCoord(camera,centre.x,centre.y,centre.z)
    SetCamFov(camera,Config.display.cameraFov); RenderScriptCams(true,true,450,true,true)
    M.active=true
    send('service',{action='menu',data=response,display=Config.display,vehicles=Config.vehicles,plans=Config.plans})
    SendNUIMessage({action='duiInput',enabled=true})
    SetNuiFocus(true,true); SetNuiFocusKeepInput(true)
    MarinaClientBridge.prompt(nil)
end

RegisterNUICallback('duiReady',function(data,cb)
    if data.kind=='idle' or data.kind=='idlejet' or data.kind=='service' or data.kind=='sign' or data.kind=='pylon' then readyPages[data.kind]=true end
    cb({ok=true})
end)
RegisterNUICallback('duiPointer',function(data,cb)
    if M.active and corners and handles.service and type(data.x)=='number' and type(data.y)=='number' then
        local a,l,t=GetScreenCoordFromWorldCoord(corners[1].x,corners[1].y,corners[1].z)
        local b,r,bt=GetScreenCoordFromWorldCoord(corners[4].x,corners[4].y,corners[4].z)
        if a and b and r>l and bt>t then
            local u,v=(data.x-l)/(r-l),(data.y-t)/(bt-t)
            if u>=0 and u<=1 and v>=0 and v<=1 then
                SendDuiMouseMove(handles.service,math.floor(u*(Config.display.width-1)),math.floor(v*(Config.display.height-1)))
                if data.event=='down' then SendDuiMouseDown(handles.service,'left')
                elseif data.event=='up' then SendDuiMouseUp(handles.service,'left')
                elseif data.event=='wheel' then SendDuiMouseWheel(handles.service,(tonumber(data.delta) or 0)>0 and -150 or 150,0) end
            elseif data.event=='up' then SendDuiMouseUp(handles.service,'left') end
        end
    end
    cb({ok=true})
end)
RegisterNUICallback('duiTextFocus',function(data,cb)
    if M.active then SendNUIMessage({action='duiTextFocus',value=data.value or '',selection=data.selection or 0}) end
    cb({ok=true})
end)
RegisterNUICallback('duiText',function(data,cb)
    if M.active and type(data.value)=='string' and #data.value<2048 then send('service',{action='text',value=data.value,selection=data.selection}) end
    cb({ok=true})
end)
RegisterNUICallback('duiKey',function(data,cb)
    if M.active then
        if data.key=='Escape' then M.close()
        elseif data.key=='Tab' or data.key=='Enter' then send('service',{action='key',key=data.key,shift=data.shift}) end
    end
    cb({ok=true})
end)
RegisterNUICallback('duiAction',function(data,cb)
    if not M.active or not current then cb({ok=false,error='Open a marina terminal first.'}); return end
    if data.action=='close' then M.close(); cb({ok=true}); return end
    if busy then cb({ok=false,error='Please wait for the current request.'}); return end
    if data.action=='build' then
        local id=current.marinaId
        local result=MarinaRPC.call('edit',{id=id})
        if result.ok then M.close(); MarinaBuilder.start(result.editable or result.marina) end
        cb(result); return
    end
    if not ({menu=true,buy=true,rent=true,business=true,['return']=true})[data.action] then cb({ok=false,error='Unknown action.'}); return end
    busy=true
    local payload=type(data.payload)=='table' and data.payload or {}
    payload.marinaId,payload.stationId=current.marinaId,current.stationId
    local result=MarinaRPC.call(data.action,payload)
    busy=false
    cb(result)
    if not M.active or not current then return end
    if result.ok and (data.action=='rent' or data.action=='return') then
        M.close(); MarinaClientBridge.notify({type='success',description='Request accepted. Follow the launch bay.'})
    elseif result.ok then
        local response=data.action=='menu' and result or MarinaRPC.call('menu',{marinaId=current.marinaId,stationId=current.stationId})
        if response.ok then send('service',{action='menu',data=response,display=Config.display,vehicles=Config.vehicles,plans=Config.plans}) end
    end
end)

local function triangle(a,b,c,ua,va,ub,vb,uc,vc,tex)
    Citizen.InvokeNative(0x29280002282F1928,a.x,a.y,a.z,b.x,b.y,b.z,c.x,c.y,c.z,255,255,255,255,txdName,tex or 'service',ua,va,1.0,ub,vb,1.0,uc,vc,1.0)
end
local function drawScreen(c,tex)
    triangle(c[1],c[3],c[2],0.0,0.0,0.0,1.0,1.0,0.0,tex)
    triangle(c[2],c[3],c[4],1.0,0.0,0.0,1.0,1.0,1.0,tex)
end
local idleScreens, idleScan = {}, 0
CreateThread(function()
    while true do
        if M.active then
            DisableAllControlActions(0)
            SetEntityLocallyInvisible(PlayerPedId())
            drawScreen(corners,'service')
            if IsEntityDead(PlayerPedId()) or Math.distance(GetEntityCoords(PlayerPedId()),current.terminal)>Config.rental.interactionDistance+2 then M.close() end
            Wait(0)
        elseif handles.idle and readyPages.idle and next(idleScreens) then
            for _,c in ipairs(idleScreens) do drawScreen(c.corners,c.tex) end
            Wait(0)
        else Wait(300) end
    end
end)
CreateThread(function()
    while true do
        local list = {}
        if handles.idle and readyPages.idle and MarinaWorld and MarinaWorld.stations then
            local p = GetEntityCoords(PlayerPedId())
            for _,entry in pairs(MarinaWorld.stations) do
                local root = entry.station and entry.station.terminal
                if root and (not current or entry.station ~= current.terminalStation) and Math.distance(p,root) < (Config.display.idleDrawDistance or 35.0) then
                    local tex = (entry.station.kind == 'jetski' and handles.idlejet and readyPages.idlejet) and 'idlejet' or 'idle'
                    list[#list+1] = { corners = screenCorners(root), tex = tex }
                end
            end
        end
        idleScreens = list
        Wait(500)
    end
end)
CreateThread(function()
    local emptySince
    while true do
        if next(MarinaWorld.stations) then
            emptySince=nil
            M.prime()
        elseif not M.active then
            emptySince=emptySince or GetGameTimer()
            if next(handles) and GetGameTimer()-emptySince>15000 then destroy() end
        end
        Wait(2000)
    end
end)
RegisterCommand('marinaduidiag',function()
    print(('[marina] dui txd=%s runtime=%s creating=%s active=%s idleScreens=%d'):format(txdName,tostring(runtimeTxd~=nil),tostring(creating),tostring(M.active),#idleScreens))
    for _,kind in ipairs({'idle','idlejet','service','sign','pylon'}) do
        print(('[marina]  %s handle=%s available=%s ready=%s'):format(kind,tostring(handles[kind]),tostring(handles[kind] and IsDuiAvailable(handles[kind])),tostring(readyPages[kind])))
    end
    local n=0 for _ in pairs(MarinaWorld.stations or {}) do n=n+1 end
    print(('[marina]  visible stations=%d'):format(n))
end,false)
AddEventHandler('onResourceStop',function(name) if name==resource then M.close(); destroy() end end)
