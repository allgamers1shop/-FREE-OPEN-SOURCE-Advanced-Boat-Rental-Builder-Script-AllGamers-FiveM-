-- Persisted props are streamed as NON-networked local objects on every client.
-- Rental boats are different: their network entity is owned by the server.
MarinaWorld = { marinas = {}, objects = {}, stations = {}, travels = {}, rental = false }
local M, Math, Config = MarinaWorld, MarinaMath, MarinaConfig
local resource = GetCurrentResourceName()
local blips, revision, objectCount, stopped = {}, -1, 0, false
local epochBase, tickBase = GetCloudTimeAsInt() * 1000, GetGameTimer()

function M.now() return epochBase + GetGameTimer() - tickBase end
function M.clock(serverNow)
    if type(serverNow) == 'number' then epochBase, tickBase = serverNow, GetGameTimer() end
end

function M.model(model)
    local hash = type(model) == 'string' and joaat(model) or model
    if not IsModelInCdimage(hash) then return nil end
    local deadline = GetGameTimer() + 6000
    RequestModel(hash)
    while not HasModelLoaded(hash) and GetGameTimer() < deadline and not stopped do Wait(20) end
    return HasModelLoaded(hash) and hash or nil
end

function M.place(entity, root, position, quaternion)
    local p = Math.world(root, position)
    SetEntityCoordsNoOffset(entity, p.x, p.y, p.z, false, false, false)
    if quaternion then
        local q = Math.quaternion(root, quaternion)
        SetEntityQuaternion(entity, q[2], q[3], q[4], q[1])
    else SetEntityHeading(entity, root.heading or 0) end
end

local noCollision
local function isDecoration(model)
    if not noCollision then
        noCollision = {}
        for _, name in ipairs(Config.noCollision or {}) do noCollision[name] = true end
    end
    return noCollision[model] == true
end

function M.create(model, root, position, quaternion, ghost)
    local hash = M.model(model)
    if not hash then return nil end
    local p = Math.world(root, position or {0, 0, 0})
    local entity = CreateObjectNoOffset(hash, p.x, p.y, p.z, false, false, false)
    SetModelAsNoLongerNeeded(hash)
    if entity == 0 then return nil end
    SetEntityAsMissionEntity(entity, true, true)
    M.place(entity, root, position or {0, 0, 0}, quaternion)
    if ghost then SetEntityCollision(entity, false, false); SetEntityAlpha(entity, 150, false)
    elseif isDecoration(model) then SetEntityCollision(entity, false, false) end
    FreezeEntityPosition(entity, true)
    return entity
end

---@return boolean nearPlayer true when the deleted object was close enough to have
---been the ground under the ped
local function drop(key, playerCoords)
    local record = M.objects[key]
    if not record then return false end
    local near = false
    MarinaClientBridge.removeTarget(record.target)
    if record.entity and DoesEntityExist(record.entity) then
        if playerCoords then
            near = Math.distance(GetEntityCoords(record.entity), playerCoords) < 6.0
        end
        DeleteEntity(record.entity)
    end
    M.objects[key] = nil
    objectCount = math.max(0, objectCount - 1)
    return near
end

---@param models table list of model names
function M.restream(models)
    local names = {}
    for _, name in ipairs(models or {}) do names[name] = true end
    for key, record in pairs(M.objects) do
        if names[record.model] then drop(key) end
    end
end

local function blipUpdate()
    for _, blip in pairs(blips) do RemoveBlip(blip) end
    blips = {}
    for id, marina in pairs(M.marinas) do
        local spec = marina.blip
        if spec and spec.enabled then
            local b = AddBlipForCoord(marina.coords.x, marina.coords.y, marina.coords.z)
            SetBlipSprite(b, spec.sprite or 410)
            SetBlipColour(b, spec.color or 3)
            SetBlipScale(b, spec.scale or 0.75)
            SetBlipAsShortRange(b, true)
            BeginTextCommandSetBlipName('STRING'); AddTextComponentString(marina.name); EndTextCommandSetBlipName(b)
            blips[id] = b
        end
    end
end

local function vehicleLabel(id)
    for _, def in ipairs(Config.vehicles or {}) do
        if def.id == id then return def.label end
    end
    return id
end

function M.setRental(data)
    M.rental = data or false
    local rental = M.rental and {
        vehicleId = M.rental.vehicleId, vehicleLabel = vehicleLabel(M.rental.vehicleId),
        plate = M.rental.plate, phase = M.rental.phase, expiresAt = M.rental.expiresAt,
    } or false
    SendNUIMessage({ action = 'rentalHud', rental = rental, serverNow = M.now() / 1000, config = Config.display.rentalHud })
end

function M.receive(data)
    if type(data) ~= 'table' then return end
    if data.serverNow then M.clock(data.serverNow) end
    if data.revision and data.revision < revision then return end
    revision = data.revision or revision
    M.marinas = {}
    for _, marina in pairs(data.marinas or {}) do M.marinas[marina.id] = marina end
    if data.rental ~= nil then M.setRental(data.rental) end
    if data.travels then
        M.travels = {}
        for _, travel in pairs(data.travels) do M.travel(travel,true) end
    end
    blipUpdate()
end

function M.travel(t, fromSnapshot)
    if type(t) ~= 'table' or not t.stationId or not t.marinaId then return end
    local key = tostring(t.marinaId) .. ':' .. tostring(t.stationId)
    -- A snapshot's travel records retain their original broadcast time.
    -- Only its top-level serverNow is a fresh clock sample.
    if t.serverNow and not fromSnapshot then M.clock(t.serverNow) end
    if t.rentalId and t.phase ~= 'idle' then
        -- Returning at a different compatible bay must remove the old bay's
        -- active stage, or two local controllers fight over the same vehicle.
        for otherKey,other in pairs(M.travels) do
            if otherKey ~= key and other.rentalId == t.rentalId then
                if (other.phaseAt or 0) > (t.phaseAt or 0) then return end
                M.travels[otherKey] = nil
            end
        end
    end
    local previous = M.travels[key]
    if t.phase == 'idle' then
        if not previous or not t.rentalId or previous.rentalId == t.rentalId then M.travels[key] = nil end
    elseif not previous or (t.phaseAt or 0) >= (previous.phaseAt or 0) then
        M.travels[key] = t
    end
end

---A streamed object is identified by WHAT it is, not by which record it came from.
---Keying on marina and piece ids meant the first save of a draft (the server assigns
---the real marina id) changed every key, so the whole dock was deleted and rebuilt
---under the player's feet: the ped is left hovering or drops into a crouch. With a
---content key an unchanged piece keeps its entity through saves and re-syncs.
---@return string key
local function desire(wanted, model, root, position, quaternion, meta)
    position = position or { 0, 0, 0 }
    local key = ('%s|%.3f|%.3f|%.3f|%.1f|%.3f,%.3f,%.3f'):format(model, root.x or 0.0, root.y or 0.0,
        root.z or 0.0, root.heading or 0.0, position[1] or 0.0, position[2] or 0.0, position[3] or 0.0)
    wanted[key] = { model = model, root = root, position = position, quaternion = quaternion, meta = meta }
    return key
end

function M.refresh()
    local p = GetEntityCoords(PlayerPedId())
    local wanted, visibleStations = {}, {}
    local marinas = {}
    for _, m in pairs(M.marinas) do
        if not (MarinaBuilder and MarinaBuilder.active and MarinaBuilder.draft.id == m.id) then marinas[#marinas+1] = m end
    end
    if MarinaBuilder and MarinaBuilder.active then marinas[#marinas+1] = MarinaBuilder.draft end
    for _, marina in ipairs(marinas) do
        local maxRadius = Config.streaming.radius + Config.limits.buildRadius + Config.streaming.hysteresis
        if Math.distance(p, marina.coords) < maxRadius then
            for _, piece in ipairs(marina.pieces or {}) do
                local asset = MarinaAssets.catalog[piece.asset]
                if asset then
                    local radius = Config.streaming.radius
                        + (M.objects[desire({}, asset.model, piece)] and Config.streaming.hysteresis or 0)
                    if Math.distance(p, piece) < radius then desire(wanted, asset.model, piece, nil, nil, { pieceId = piece.id }) end
                end
            end
            local stations = {}
            for _, station in ipairs(marina.stations or {}) do stations[#stations+1]=station end
            local pending = MarinaBuilder and MarinaBuilder.active and MarinaBuilder.draft == marina and MarinaBuilder.pendingStation
            if pending then stations[#stations+1]=pending end
            for _, station in ipairs(stations) do
                if Math.distance(p, station.root) < Config.streaming.radius then
                    local key = marina.id .. ':' .. station.id
                    visibleStations[key] = { marina = marina, station = station, parts = {} }
                    for _, part in ipairs(MarinaAssets.assemblies[station.kind] or {}) do
                        desire(wanted, part.model, station.root, part.position, part.quaternion_wxyz, { stationId = station.id })
                    end
                    for model, part in pairs(MarinaAssets.animations.samples[1].parts) do
                        if (station.kind == 'jetski' and model:find('_capsule_',1,true)) or (station.kind == 'boat' and model:find('_hangar_',1,true)) then
                            visibleStations[key].parts[model] = desire(wanted, model, station.root,
                                part.position, part.quaternion_wxyz, { moving = true, stationId = station.id })
                        end
                    end
                    if station ~= pending then
                        desire(wanted, 'ff_marina_tablet_stand', station.terminal, nil, nil,
                            { marinaId = marina.id, stationId = station.id, tablet = true })
                    end
                end
            end
        end
    end
    M.stations = visibleStations
    if MarinaDui and MarinaDui.prime and next(visibleStations) then MarinaDui.prime() end

    -- Create first, delete afterwards: a player standing on a dock must never lose
    -- the collision under their feet between two batches of this pass.
    local batch, lostNearby = 0, false
    for key, value in pairs(wanted) do
        local record = M.objects[key]
        if not record and objectCount < Config.streaming.maxObjects and not stopped then
            local entity = M.create(value.model, value.root, value.position, value.quaternion)
            if entity then
                record = { entity = entity, model = value.model, meta = value.meta }
                M.objects[key] = record
                objectCount = objectCount + 1
                if value.meta and value.meta.tablet then
                    local mid, sid = value.meta.marinaId, value.meta.stationId
                    record.target = MarinaClientBridge.addTarget(key, value.root, function() MarinaDui.open(mid, sid) end)
                end
                batch = batch + 1
                if batch % Config.streaming.batchSize == 0 then Wait(0) end
            end
        end
    end
    for key in pairs(M.objects) do
        if not wanted[key] and drop(key, p) then lostNearby = true end
    end

    if lostNearby then
        local ped = PlayerPedId()
        local airborne = GetEntityHeightAboveGround == nil or GetEntityHeightAboveGround(ped) > 0.5
        if airborne and not IsPedInAnyVehicle(ped, false) and not IsPedRagdoll(ped) then
            local c = GetEntityCoords(ped)
            SetEntityCoordsNoOffset(ped, c.x, c.y, c.z, false, false, false)
        end
    end
end

RegisterNetEvent(resource .. ':sync', function(data) if source == 65535 then M.receive(data) end end)
RegisterNetEvent(resource .. ':travel', function(data) if source == 65535 then M.travel(data) end end)
RegisterNetEvent(resource .. ':rental', function(data) if source == 65535 then M.setRental(data) end end)
RegisterNetEvent(resource .. ':notify', function(data) if source == 65535 then MarinaClientBridge.notify(data) end end)

CreateThread(function()
    Wait(1000)
    while not stopped do
        local response = MarinaRPC.call('snapshot', {})
        if response and response.ok then M.receive(response); break end
        Wait(5000)
    end
    while not stopped do M.refresh(); Wait(Config.streaming.tickMs) end
end)

AddEventHandler('onResourceStop', function(name)
    if name ~= resource then return end
    stopped = true
    for key in pairs(M.objects) do drop(key) end
    for _, b in pairs(blips) do RemoveBlip(b) end
    MarinaClientBridge.prompt(nil)
end)
