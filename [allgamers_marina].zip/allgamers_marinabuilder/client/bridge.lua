-- CUSTOMER INTEGRATIONS
-- Select adapters in config.lua. This file stays editable under Asset Escrow.
-- Custom functions run locally; they must never decide ownership or money.
MarinaClientBridge = {}
local M, Config = MarinaClientBridge, MarinaConfig
local Custom = {}

-- Draw your own hint. key is normally 'E'; nil means informational text.
function Custom.showPrompt(text, key) end
function Custom.hidePrompt() end
-- data = { description = string, type = 'success' | 'error' | 'inform' }
function Custom.notify(data) end
-- Return a handle for your target integration and invoke onSelect when selected.
function Custom.addTarget(id, coords, onSelect) return nil end
function Custom.removeTarget(handle) end

local lastPrompt
function M.notify(data)
    if type(data) == 'string' then data = { description = data, type = 'inform' } end
    if Config.notify == 'custom' then Custom.notify(data)
    elseif Config.notify == 'ox_lib' and GetResourceState('ox_lib') == 'started' then
        TriggerEvent('ox_lib:notify', data)
    elseif Config.notify == 'native' then
        BeginTextCommandThefeedPost('STRING')
        AddTextComponentSubstringPlayerName(data.description or '')
        EndTextCommandThefeedPostTicker(false, false)
    else SendNUIMessage({ action = 'toast', data = data }) end
end

function M.usesKey()
    if Config.interaction == 'ox_target' or Config.interaction == 'qb-target' then
        return GetResourceState(Config.interaction) ~= 'started'
    end
    return true
end

function M.prompt(text, key)
    if lastPrompt == text then return end
    lastPrompt = text
    if Config.interaction == 'custom' then
        if text then Custom.showPrompt(text, key) else Custom.hidePrompt() end
    elseif Config.interaction == 'ox_lib' and GetResourceState('ox_lib') == 'started' then
        if text then exports.ox_lib:showTextUI((key and '[' .. key .. '] ' or '') .. text)
        else exports.ox_lib:hideTextUI() end
    else SendNUIMessage({ action = 'prompt', text = text or false, key = key or false }) end
end

function M.addTarget(id, coords, select)
    local point = vector3(coords.x, coords.y, coords.z + 1.2)
    if Config.interaction == 'custom' then return { kind = 'custom', id = Custom.addTarget(id, point, select) } end
    if Config.interaction == 'ox_target' and GetResourceState('ox_target') == 'started' then
        return { kind = 'ox_target', id = exports.ox_target:addSphereZone({
            coords = point, radius = 0.5,
            options = {{ name = 'marina_' .. id, label = 'Marina terminal', icon = 'fa-solid fa-anchor', distance = Config.rental.interactionDistance, onSelect = select }},
        }) }
    elseif Config.interaction == 'qb-target' and GetResourceState('qb-target') == 'started' then
        local name = 'marina_' .. id
        exports['qb-target']:AddCircleZone(name, point, 0.5, { name = name, useZ = true }, {
            options = {{ label = 'Marina terminal', icon = 'fas fa-anchor', action = select }}, distance = Config.rental.interactionDistance,
        })
        return { kind = 'qb-target', id = name }
    end
end

function M.removeTarget(handle)
    if not handle then return end
    if handle.kind == 'custom' then Custom.removeTarget(handle.id)
    elseif handle.kind == 'ox_target' and GetResourceState('ox_target') == 'started' then exports.ox_target:removeZone(handle.id)
    elseif handle.kind == 'qb-target' and GetResourceState('qb-target') == 'started' then exports['qb-target']:RemoveZone(handle.id) end
end
