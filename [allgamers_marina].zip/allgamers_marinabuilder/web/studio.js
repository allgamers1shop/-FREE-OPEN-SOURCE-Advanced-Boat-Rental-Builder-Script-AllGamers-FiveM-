'use strict';
const studio = document.querySelector('#studio');
const hud = document.querySelector('#build-hud');
const keyboard = document.querySelector('#keyboard');
function ask(text) {
    const dialog=document.querySelector('#confirm-dialog');
    document.querySelector('#confirm-text').textContent=text;
    dialog.showModal();
    return new Promise(resolve=>{
        const finish=value=>{dialog.close();resolve(value);};
        document.querySelector('#confirm-yes').onclick=()=>finish(true);
        document.querySelector('#confirm-no').onclick=()=>finish(false);
        dialog.oncancel=event=>{event.preventDefault();finish(false);};
    });
}
const state = { draft: null, catalog: [], tab: 'floor', search: '', marinas: [], admin: false, roles: {}, dui: false, placing: false };
const esc = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const resource = typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'allgamers_marinabuilder';
async function post(route, data) {
    if (location.search.includes('preview')) return {ok: true};
    try {
        const response = await fetch(`https://${resource}/${route}`, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
        return await response.json();
    } catch { return {ok:false,error:'Connection failed. Please try again.'}; }
}
function toast(text, type = '') {
    const box = document.createElement('div'); box.className = `toast ${type}`; box.textContent = text;
    document.querySelector('#toasts').append(box); setTimeout(() => box.remove(), 5500);
}
async function action(operation, data = {}) {
    const result = await post('builder', {operation,...data});
    if (!result.ok) toast(result.error || 'Action failed.', 'error');
    return result;
}
function shell(title, caption, sub, body) {
    return `<div class="topline"><div class="wordmark">ALL<i>GAMERS</i></div><button class="close" data-op="close"><kbd>ESC</kbd> Close</button></div>` +
        `<div class="heading"><div class="caption">${esc(caption)}</div><h1>${esc(title)}</h1>${sub ? `<p>${esc(sub)}</p>` : ''}</div>` +
        `<div class="body">${body}</div>`;
}
function manager() {
    studio.hidden = false; hud.hidden = true; state.draft = null; state.placing = false;
    const mine = state.marinas.filter(m => state.admin || state.roles[m.id] === 'owner' || state.roles[m.id] === 'manager');
    const list = mine.map(m => `<article class="station-card"><span class="tag">${esc(m.mode)}</span><h2>${esc(m.name)}</h2>` +
        `<p>${(m.pieces || []).length} pieces · ${(m.stations || []).length} launch bays</p>` +
        `<div class="actions"><button class="primary" data-edit="${esc(m.id)}">Open creator</button>` +
        `${state.admin ? `<button class="secondary danger" data-delete="${esc(m.id)}">Delete</button>` : ''}</div></article>`).join('')
        || '<p class="empty">No marinas yet. Create your first location to begin.</p>';
    studio.innerHTML = shell('A space by the sea', 'YOUR WATERFRONT', 'Build, connect and manage your marinas.',
        `<div class="section-title">Locations <span class="count">${mine.length}</span></div><div class="list">${list}</div>` +
        (state.admin ? '<div class="actions"><button class="primary" data-op="new">+ Create marina</button></div>' : ''));
}
const TABS = [['floor', 'Floors'], ['coast', 'Coast'], ['edge', 'Rails'], ['utility', 'Gear'],
    ['stations', 'Stations'], ['placed', 'Placed'], ['settings', 'Settings']];
function sidesBadge(a){const s=a.sides||[];if(!s.length)return '';return `<span class="sides-badge" aria-hidden="true">${['N','E','S','W'].map(k=>`<i class="${k.toLowerCase()} ${s.includes(k)?'on':''}"></i>`).join('')}</span>`;}
function describe(a){const s=a.sides||[];const n=s.length;const id=a.id||'';
    if(id.includes('shore_ramp'))return 'Ramp from land onto the dock';
    if(id.includes('shore_start'))return 'Shore anchor, dock starts here';
    if(id.includes('gangway'))return 'Gangway, joins front and back';
    if(a.category==='floor'||a.category==='coast'){
        if(n>=4)return 'Deck tile, joins on all four sides';
        if(n===3)return 'T junction, joins on three sides';
        if(n===2)return 'Corner, joins on two sides';
        if(n===1)return 'End cap';
        return 'Free standing piece';}
    if(a.category==='edge')return 'Mounts on a deck edge';
    if(a.category==='mooring')return 'Mounts on a deck edge, for boats';
    if(a.category==='support')return 'Goes under the deck';
    return 'Stands on the deck';}
const TAB_ASSETS = { floor: ['floor'], coast: ['coast', 'support'], edge: ['edge', 'mooring'], utility: ['utility', 'interaction', 'signage'] };
function render() {
    const d = state.draft; if (!d) return manager();
    studio.hidden = false; hud.hidden = true; state.placing = false;
    const chips = TABS.map(([id, label]) => `<button class="chip ${state.tab === id ? 'selected' : ''}" data-tab="${id}">${label}</button>`).join('');
    let body = '';
    if (state.tab === 'settings') {
        const b = d.blip || {};
        body = `<form id="settings" class="form"><label>Marina name<input name="name" maxlength="64" value="${esc(d.name)}" required></label>` +
            `<div class="two"><label>Ownership<select name="mode"><option value="public" ${d.mode === 'public' ? 'selected' : ''}>Public rental</option><option value="ownable" ${d.mode === 'ownable' ? 'selected' : ''}>Ownable</option></select></label>` +
            `<label>Price<input name="purchasePrice" type="number" min="0" max="1000000" value="${d.purchasePrice || 0}"></label></div>` +
            `<div class="two"><label>Map blip<select name="enabled"><option value="true" ${b.enabled ? 'selected' : ''}>Visible</option><option value="false" ${!b.enabled ? 'selected' : ''}>Hidden</option></select></label>` +
            `<label>Sprite<input name="sprite" type="number" min="1" max="999" value="${b.sprite || 410}"></label></div>` +
            `<div class="two"><label>Blip colour<input name="color" type="number" min="0" max="85" value="${b.color ?? 3}"></label>` +
            `<label>Blip scale<input name="scale" type="number" min="0.2" max="2" step="0.05" value="${b.scale || 0.75}"></label></div>` +
            `<button class="primary">Apply settings</button></form>`;
    } else if (state.tab === 'stations') {
        body = `<article class="station-card"><span class="tag">JET-SKI</span><h2>Capsule launch</h2><img src="assets/ff_marina_capsule_shell.png" alt="Jet ski capsule">` +
            `<p>Hydraulic ramp and synchronized launch.</p><div class="actions"><button class="primary" data-select="jetski">Place capsule</button></div></article>` +
            `<article class="station-card"><span class="tag">BOATS</span><h2>Private hangar</h2><img src="assets/ff_marina_hangar_front.png" alt="Boat hangar">` +
            `<p>Enclosed water bay with opening doors.</p><div class="actions"><button class="primary" data-select="boat">Place hangar</button></div></article>` +
            `<div class="section-title">Placed stations <span class="count">${d.stations.length}</span></div><div class="list">` +
            (d.stations.map(s => `<div class="row"><span>${esc(s.kind)}</span><button data-anchor="terminal" data-id="${esc(s.id)}">Tablet</button>` +
                `<button data-anchor="exit" data-id="${esc(s.id)}">Exit</button><button data-anchor="pickup" data-id="${esc(s.id)}">Pickup</button>` +
                `<button class="danger" data-remove="${esc(s.id)}" data-kind="station">✕</button></div>`).join('')
                || '<p class="empty">No stations yet.</p>') + '</div>';
    } else if (state.tab === 'placed') {
        body = `<div class="section-title">Objects <span class="count">${d.pieces.length}</span></div><div class="list">` +
            (d.pieces.slice().reverse().map(p => `<div class="row"><span>${esc(p.asset.replace('ff_marina_', '').replaceAll('_', ' '))}</span>` +
                `<small>${p.x.toFixed(1)}, ${p.y.toFixed(1)}</small><button class="danger" data-remove="${esc(p.id)}">✕</button></div>`).join('')
                || '<p class="empty">Choose a floor to start building.</p>') + '</div>';
    } else {
        const assets = state.catalog.filter(a => (TAB_ASSETS[state.tab] || []).includes(a.category));
        body = `<div class="section-title">${esc((TABS.find(t => t[0] === state.tab) || [])[1] || '')} <span class="count">${assets.length}</span></div>` +
            `<div class="assets"><div class="grid">${assets.map(a => `<button class="card" data-select="${esc(a.id)}" title="${esc(describe(a))}">` +
                `<img loading="lazy" src="${esc(a.image)}" alt="${esc(a.label)}">${sidesBadge(a)}<strong>${esc(a.label)}</strong><small>${esc(describe(a))}</small></button>`).join('')}</div></div>`;
    }
    studio.innerHTML = shell(d.name, 'MARINA CREATOR', null, `<div class="chips">${chips}</div>${body}` +
        `<div class="actions"><button class="secondary" data-op="lookedit">Look to edit</button><button class="secondary" data-op="lookdelete">Look to delete</button></div>` +
        `<div class="actions"><button class="primary" data-op="save">Save marina</button><button class="secondary" data-op="undo">Undo</button></div>` +
        `<p class="hint">${d.pieces.length} objects · ${d.stations.length} stations · 4 m grid. TAB returns here while placing.</p>`);
}
studio.addEventListener('click',async event=>{
    const b=event.target.closest('button'); if(!b)return;
    if(b.dataset.tab){state.tab=b.dataset.tab;state.search='';render();}
    else if(b.dataset.select) await action('select',{asset:b.dataset.select});
    else if(b.dataset.edit) await action('edit',{id:b.dataset.edit});
    else if(b.dataset.delete){if(await ask('Delete this marina and its placed objects?')){const r=await action('delete',{id:b.dataset.delete});if(r.ok){state.marinas=state.marinas.filter(m=>m.id!==b.dataset.delete);manager();}}}
    else if(b.dataset.remove)await action('remove',{id:b.dataset.remove,kind:b.dataset.kind});
    else if(b.dataset.anchor)await action('anchor',{id:b.dataset.id,anchor:b.dataset.anchor});
    else if(b.dataset.op==='new'){studio.innerHTML=shell('Start with the basics','NEW MARINA','Choose a name and ownership mode, then place your first dock.',`<form id="new-marina" class="form"><label>Marina name<input name="name" maxlength="48" placeholder="Vespucci Marina" required></label><label>Ownership mode<select name="mode"><option value="ownable">Ownable business</option><option value="public">Public rental</option></select></label><button class="primary">Start building</button></form>`);}
    else if(b.dataset.op){if(b.dataset.op==='close'&&state.draft&&!await ask('Close creator and discard unsaved layout changes?'))return;await action(b.dataset.op);if(b.dataset.op==='close'){studio.hidden=true;hud.hidden=true;}}
});
studio.addEventListener('input',event=>{if(event.target.id==='search'){const selection=event.target.selectionStart;state.search=event.target.value;render();const input=document.querySelector('#search');input.focus();input.setSelectionRange(selection,selection);}});
studio.addEventListener('submit',event=>{
    event.preventDefault();const f=new FormData(event.target);
    if(event.target.id==='new-marina')action('new',{name:f.get('name'),mode:f.get('mode')});
    if(event.target.id==='settings')action('settings',{name:f.get('name'),mode:f.get('mode'),purchasePrice:Number(f.get('purchasePrice')),blip:{enabled:f.get('enabled')==='true',sprite:Number(f.get('sprite')),color:Number(f.get('color')),scale:Number(f.get('scale'))}});
});
const rentalHud=document.getElementById('rental-hud');
let rentalNow={rental:null,offset:0};
const pad2=n=>String(n).padStart(2,'0');
function rentalClock(){
    const r=rentalNow.rental;
    if(!r)return'';
    if(r.phase!=='active')return'--:--';
    const left=Math.round((r.expiresAt||0)-(Date.now()/1000+rentalNow.offset));
    const a=Math.abs(left);
    const h=Math.floor(a/3600),m=Math.floor(a%3600/60),sec=a%60;
    return (left<0?'-':'')+(h>0?`${h}:${pad2(m)}:${pad2(sec)}`:`${m}:${pad2(sec)}`);
}
function placeRentalHud(cfg){
    const c=cfg||{};
    const clamp=v=>Math.min(90,Math.max(0,Number(v)||0));
    document.documentElement.style.setProperty('--rhud-x',`${clamp(c.offsetX??2.35)}vw`);
    document.documentElement.style.setProperty('--rhud-y',`${clamp(c.offsetY??4)}vh`);
    const anchor=String(c.anchor||'bottom-left').toLowerCase();
    document.body.classList.toggle('rhud-right',anchor.includes('right'));
    document.body.classList.toggle('rhud-top',anchor.includes('top'));
    document.body.classList.toggle('rhud-center',anchor.includes('center'));
}
function renderRentalHud(){
    const r=rentalNow.rental;
    if(!r||rentalNow.disabled){rentalHud.hidden=true;return;}
    const label=r.phase==='active'?'Rental active':(r.phase==='returning'||r.phase==='closing'?'Returning':'Launching');
    rentalHud.hidden=false;
    rentalHud.innerHTML=`<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg><span>${esc(label)}<small>${esc(r.vehicleLabel||r.vehicleId||'')}${r.plate?' · '+esc(r.plate):''}</small></span><b data-clock>${rentalClock()}</b>`;
    rentalHud.classList.toggle('late',r.phase==='active'&&(r.expiresAt||0)<Date.now()/1000+rentalNow.offset);
}
setInterval(()=>{
    if(!rentalNow.rental||rentalHud.hidden)return;
    const el=rentalHud.querySelector('[data-clock]');
    if(el)el.textContent=rentalClock();
    rentalHud.classList.toggle('late',rentalNow.rental.phase==='active'&&(rentalNow.rental.expiresAt||0)<Date.now()/1000+rentalNow.offset);
},1000);
window.addEventListener('message',event=>{
    const d=event.data;
    if(d.action==='rentalHud'){
        if(d.config){placeRentalHud(d.config);rentalNow.disabled=d.config.enabled===false;}
        if(typeof d.serverNow==='number')rentalNow.offset=d.serverNow-Date.now()/1000;
        rentalNow.rental=d.rental||null;
        renderRentalHud();
        return;
    }
    if(d.action==='manager'){state.placing=false;state.marinas=d.marinas||[];state.admin=d.admin;state.roles=d.roles||{};manager();}
    if(d.action==='builder'){state.placing=false;state.draft=d.draft;state.catalog=d.catalog;render();}
    if(d.action==='placing'){
        state.placing=true;studio.hidden=true;hud.hidden=false;
        hud.innerHTML=`<strong>${esc(d.label)}</strong>${d.sides?`<div class="sides">Connects on: <b>${esc(d.sides)}</b></div>`:''}${d.note?`<div class="sides">${esc(d.note)}</div>`:''}<div class="keys">`+
            `<div><kbd>Click</kbd><kbd>E</kbd><span>Place</span></div><div><kbd>Scroll</kbd><kbd>R</kbd><span>Rotate</span></div>`+
            `<div><kbd>ALT</kbd><kbd>Scroll</kbd><kbd>T</kbd><span>Fine rotate</span></div><div><kbd>G</kbd><span>Snapping</span></div>`+
            `<div><kbd>Z</kbd><kbd>X</kbd><span>Reach</span></div><div><kbd>PgUp</kbd><kbd>PgDn</kbd><span>Height</span></div>`+
            `<div><kbd>TAB</kbd><span>Palette</span></div><div><kbd>WASD</kbd><span>Walk</span></div>`+
            `</div><div class="snaptoggle"><span class="opt snap active">Snap to socket</span><span class="opt free">Free place</span><kbd>G</kbd><small>switch</small></div><span class="mode snap">Looking for a socket…</span>`;
    }
    if(d.action==='deleting'){
        state.placing=false;studio.hidden=true;hud.hidden=false;
        const edit=d.mode==='edit';
        hud.innerHTML=`<strong>${edit?'Edit mode':'Delete mode'}</strong><div class="sides">${edit?'Look at an object and press <b>E</b> or click to pick it up, then place it again (scroll rotates).':'Look at an object and press <b>E</b> or click to delete it.'} Highlighted = selected.</div><div class="keys"><div><kbd>E</kbd><kbd>Click</kbd><span>${edit?'Pick up':'Delete'}</span></div><div><kbd>TAB</kbd><span>Back to menu</span></div></div>${typeof d.count==='number'?`<span class="mode free">${d.count} objects</span>`:''}`;
    }
    if(d.action==='mode'){
        const el=hud.querySelector('.mode');
        if(el){
            el.className='mode '+(d.mode==='snap'?'snap':'free');
            el.textContent=d.mode==='snap'?'Snapped to socket':(d.mode==='off'?'Free placement':'Free placement — no socket in range');
        }
        const t=hud.querySelector('.snaptoggle');
        if(t){t.querySelector('.opt.snap').classList.toggle('active',d.mode!=='off');t.querySelector('.opt.free').classList.toggle('active',d.mode==='off');}
    }
    if(d.action==='builderClose'){state.placing=false;studio.hidden=true;hud.hidden=true;state.draft=null;document.querySelector('#confirm-dialog').close();}
    if(d.action==='toast')toast(d.data.description,d.data.type);
    if(d.action==='prompt'){const p=document.querySelector('#prompt');p.hidden=!d.text;p.innerHTML=`${d.key?`<kbd>${esc(d.key)}</kbd>`:''}${esc(d.text)}`;}
    if(d.action==='duiInput'){state.dui=d.enabled;if(!d.enabled)keyboard.blur();}
    if(d.action==='duiTextFocus'){keyboard.value=d.value;keyboard.focus({preventScroll:true});keyboard.setSelectionRange(d.selection,d.selection);}
});
let mouseAt=0;
function pointer(event,kind){if(!state.dui)return;const now=performance.now();if(kind==='move'&&now-mouseAt<16)return;mouseAt=now;post('duiPointer',{event:kind,x:event.clientX/innerWidth,y:event.clientY/innerHeight,delta:event.deltaY});}
window.addEventListener('mousemove',e=>pointer(e,'move'));
window.addEventListener('mousedown',e=>{if(state.dui){e.preventDefault();pointer(e,'down');}});
window.addEventListener('mouseup',e=>pointer(e,'up'));
window.addEventListener('wheel',e=>pointer(e,'wheel'),{passive:true});
keyboard.addEventListener('input',()=>post('duiText',{value:keyboard.value,selection:keyboard.selectionStart}));
window.addEventListener('keydown',async e=>{
    if(document.querySelector('#confirm-dialog').open)return;
    if(state.dui&&['Escape','Tab','Enter'].includes(e.key)){e.preventDefault();post('duiKey',{key:e.key,shift:e.shiftKey});}
    else if(e.key==='Escape'&&!studio.hidden){e.preventDefault();if(state.draft&&!await ask('Discard unsaved layout changes?'))return;action('close');studio.hidden=true;hud.hidden=true;}
});

// While a NUI keeps the cursor the game never receives these presses, so the page
// forwards them; Lua ignores whichever side arrives second.
const PLACE_KEYS={e:'confirm',enter:'confirm',r:'rotate',t:'fine',g:'snap',pageup:'up',pagedown:'down',arrowup:'up',arrowdown:'down',z:'near',x:'far',tab:'palette'};
window.addEventListener('mousedown',event=>{
    if(!state.placing||state.dui||event.button!==0)return;
    event.preventDefault();action('input',{key:'confirm'});
});
window.addEventListener('keydown',event=>{
    if(!state.placing||state.dui)return;
    const key=PLACE_KEYS[String(event.key).toLowerCase()];
    if(!key)return;
    event.preventDefault();action('input',{key,fine:event.altKey});
});
window.addEventListener('wheel',event=>{
    if(!state.placing||state.dui)return;
    const up=event.deltaY<0;
    action('input',{key:event.altKey?(up?'fine':'fineback'):(up?'wheelup':'wheeldown')});
});

const FORMS_ROOT=document.querySelector('#studio');
function enhanceForms(scope){
    scope.querySelectorAll('select:not([data-enhanced])').forEach(sel=>{
        sel.dataset.enhanced='1';sel.classList.add('native-hidden');
        const dd=document.createElement('div');dd.className='dd';dd.tabIndex=0;
        const btn=document.createElement('div');btn.className='dd-btn';
        const list=document.createElement('div');list.className='dd-list';
        const label=()=>{btn.innerHTML=`<span>${esc(sel.options[sel.selectedIndex]?.text||'')}</span><i class="dd-chev"></i>`;};
        Array.from(sel.options).forEach(o=>{const it=document.createElement('div');it.className='dd-item'+(o.selected?' on':'');it.textContent=o.text;
            it.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();sel.value=o.value;sel.dispatchEvent(new Event('change',{bubbles:true}));list.querySelectorAll('.dd-item').forEach(x=>x.classList.toggle('on',x===it));label();dd.classList.remove('open');});
            list.appendChild(it);});
        btn.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();document.querySelectorAll('.dd.open').forEach(x=>x!==dd&&x.classList.remove('open'));const open=!dd.classList.contains('open');dd.classList.toggle('open',open);if(open){const r=btn.getBoundingClientRect();const room=window.innerHeight-r.bottom;list.style.left=r.left+'px';list.style.width=r.width+'px';if(room<240&&r.top>room){list.style.top='auto';list.style.bottom=(window.innerHeight-r.top+3)+'px';}else{list.style.bottom='auto';list.style.top=(r.bottom+3)+'px';}}});
        label();dd.append(btn,list);sel.parentNode.insertBefore(dd,sel.nextSibling);const lb=sel.closest('label');if(lb)lb.classList.add('has-widget');
    });
    scope.querySelectorAll('input[type="number"]:not([data-enhanced])').forEach(inp=>{
        inp.dataset.enhanced='1';
        const wrap=document.createElement('div');wrap.className='stepper';
        inp.parentNode.insertBefore(wrap,inp);wrap.appendChild(inp);
        const mk=(t,fn)=>{const b=document.createElement('button');b.type='button';b.className='step';b.textContent=t;b.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();fn();inp.dispatchEvent(new Event('input',{bubbles:true}));inp.dispatchEvent(new Event('change',{bubbles:true}));b.blur();});return b;};
        wrap.insertBefore(mk('−',()=>inp.stepDown()),inp);wrap.appendChild(mk('+',()=>inp.stepUp()));const lb=inp.closest('label');if(lb)lb.classList.add('has-widget');
    });
}
document.addEventListener('click',e=>{if(e.target&&e.target.closest&&e.target.closest('.dd'))return;document.querySelectorAll('.dd.open').forEach(x=>x.classList.remove('open'));});
document.addEventListener('scroll',()=>document.querySelectorAll('.dd.open').forEach(x=>x.classList.remove('open')),true);
new MutationObserver(()=>enhanceForms(FORMS_ROOT)).observe(FORMS_ROOT,{childList:true,subtree:true});
enhanceForms(FORMS_ROOT);
