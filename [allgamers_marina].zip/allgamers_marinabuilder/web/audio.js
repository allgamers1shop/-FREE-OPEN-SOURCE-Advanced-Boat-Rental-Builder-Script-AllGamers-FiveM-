// Isolated WebAudio graph. Looping follows stage duration; leaving range stops it.
(()=>{
    let context;
    const active=new Map(),buffers=new Map();
    const getContext=()=>context||(context=new (window.AudioContext||window.webkitAudioContext)());
    async function buffer(file){
        if(!buffers.has(file))buffers.set(file,fetch('sounds/'+file).then(r=>{if(!r.ok)throw Error('audio');return r.arrayBuffer();}).then(b=>getContext().decodeAudioData(b)));
        try{return await buffers.get(file);}catch(e){buffers.delete(file);throw e;}
    }
    function update(item,data){
        item.data=data;
        if(!item.gain)return;
        const now=context.currentTime;
        item.gain.gain.setTargetAtTime(data.volume,now,0.04);
        for(const axis of ['X','Y','Z'])item.panner['position'+axis].setTargetAtTime(data[axis.toLowerCase()],now,0.03);
    }
    window.addEventListener('message',async event=>{
        const d=event.data;if(d.action!=='marinaAudio')return;
        const old=active.get(d.id);
        if(d.stop){
            active.delete(d.id);
            if(old?.source){old.gain.gain.setTargetAtTime(0,context.currentTime,0.025);old.source.stop(context.currentTime+0.12);}
            return;
        }
        if(old){update(old,d);return;}
        const item={data:d};active.set(d.id,item);
        try{
            const ctx=getContext(),decoded=await buffer(d.file);
            if(active.get(d.id)!==item)return;
            if(ctx.state==='suspended')await ctx.resume();
            if(active.get(d.id)!==item)return;
            item.source=ctx.createBufferSource();item.source.buffer=decoded;item.source.loop=true;
            item.gain=ctx.createGain();item.gain.gain.value=0;
            item.panner=ctx.createPanner();item.panner.panningModel='HRTF';item.panner.distanceModel='inverse';
            item.panner.refDistance=d.ref;item.panner.maxDistance=d.max;item.panner.rolloffFactor=1.4;
            item.source.connect(item.gain).connect(item.panner).connect(ctx.destination);
            update(item,item.data);
            item.source.onended=()=>{item.source.disconnect();item.gain.disconnect();item.panner.disconnect();};
            item.source.start(0,item.data.offset%decoded.duration);
        }catch{if(active.get(d.id)===item)active.delete(d.id);}
    });
})();
