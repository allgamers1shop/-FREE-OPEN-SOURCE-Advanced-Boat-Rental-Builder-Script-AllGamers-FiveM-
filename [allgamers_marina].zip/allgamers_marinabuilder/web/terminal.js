'use strict';
const params=new URLSearchParams(location.search);
const kind=params.get('kind')||'service';
const resource=params.get('resource')||'allgamers_marinabuilder';
const root=document.querySelector('#terminal');
const state={data:null,tab:'rent',vehicle:null,plan:'30m',account:'bank',accountPicked:false,display:{brand:'ALLGAMERS',subtitle:'MARINA CLUB',accent:'#00e5b4',currency:'$'},vehicles:[],plans:[],busy:false,confirm:null};
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=n=>esc(state.display.currency)+Number(n||0).toLocaleString('en-US',{maximumFractionDigits:0});
const image=id=>esc(state.vehicles.find(v=>v.id===id)?.image||`assets/${id}.webp`);
async function post(route,data){
    if(params.has('preview'))return {ok:true};
    try{const r=await fetch(`https://${resource}/${route}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});return await r.json();}
    catch{return {ok:false,error:'The terminal could not connect. Please try again.'};}
}
async function act(action,payload={}){
    if(state.busy)return;
    state.busy=true;root.querySelectorAll('button').forEach(b=>b.disabled=true);
    const r=await post('duiAction',{action,payload});
    state.busy=false;root.querySelectorAll('button').forEach(b=>b.disabled=false);
    const error=document.querySelector('.feedback');if(error)error.textContent=r.ok?'':r.error||'Action failed.';
    return r;
}
function business(operation,payload={}){return act('business',{operation,...payload});}
function idle(){
    if(kind==='sign'||kind==='pylon'){
        const logo=state.display.logo?(params.has('preview')?`../${state.display.logo}`:`https://cfx-nui-${resource}/${state.display.logo}`):null;
        root.innerHTML=`<div class="sign ${kind}"><img class="logo" hidden alt=""><strong>${esc(state.display.brand)}</strong><span>${esc(state.display.subtitle)}</span></div>`;
        const box=root.firstChild;
        if(!logo){box.classList.add('nologo');return;}
        const out=box.querySelector('img.logo');
        out.onload=()=>{out.hidden=false;box.classList.remove('nologo');};
        out.onerror=()=>{out.remove();box.classList.add('nologo');};
        out.src=logo;return;}
    const jet=kind==='idlejet';
    root.innerHTML=`<div class="idle"><div class="eyebrow">${esc(state.display.brand)} / ${jet?'CAPSULE LAUNCH':'PRIVATE BOATHOUSE'}</div><h1>${jet?'Ride the<br><em>surf.</em>':'Your next<br><em>escape.</em>'}</h1><p>${jet?'Jet ski capsule. Launch in seconds.':'Open water. Your own pace.'}</p><img src="${jet?'assets/seashark.webp':'assets/speeder.webp'}" alt=""><div class="foot">APPROACH THE TERMINAL TO BEGIN ↗</div></div>`;
}
function rentView(){
    const d=state.data,vehicles=d.catalog||[];
    const v=vehicles.find(v=>v.id===state.vehicle)||vehicles[0];
    if(!v)return '<h1>No vessels available.</h1><p>The owner has not enabled a vessel for this launch bay.</p>';
    state.vehicle=v.id;
    const plans=d.plans||state.plans,plan=plans.find(p=>p.id===state.plan)||plans[0];
    if(plan)state.plan=plan.id;
    const cost=Math.floor(v.price*(plan?.multiplier||1)),available=v.available??v.stock??1;
    const blocked=available<=0||v.enabled===false||!!d.rental;
    pickAccount(cost+v.deposit);
    let blockNote='';
    if(d.rental)blockNote='<p class="note">You already have an active rental. Return it first.</p>';
    else if(v.enabled===false)blockNote='<p class="note">This vessel is paused by the marina owner.</p>';
    else if(available<=0)blockNote=d.business
        ?'<p class="note">No stock in the fleet. Open <strong>Fleet</strong>, deposit business funds in <strong>Finance</strong> if needed, then use <strong>Buy vessel</strong>.</p>'
        :'<p class="note">No vessels available at this bay right now. Try again later.</p>';
    return `<div class="eyebrow">${esc(d.station?.kind==='jetski'?'CAPSULE LAUNCH':'PRIVATE BOATHOUSE')}</div><h1>Find your open water.</h1><div class="rental-layout"><div><div class="hero"><span class="tag">${available>0?'READY TO LAUNCH':'CURRENTLY UNAVAILABLE'}</span><h2>${esc(v.label)}</h2><img src="${image(v.id)}" alt="${esc(v.label)}"></div><div class="vehicles">${vehicles.map(x=>`<button class="vehicle ${x.id===v.id?'selected':''}" data-vehicle="${esc(x.id)}"><img src="${image(x.id)}" alt=""><strong>${esc(x.label)}</strong><small>${money(x.price)} / base plan · ${x.available??0} ready</small></button>`).join('')}</div><p class="note">Your vessel is prepared inside the bay, then delivered to the pickup point.</p></div><div class="checkout"><div class="section-label">TIME ON THE WATER</div><div class="options">${plans.map(p=>`<button class="${p.id===state.plan?'selected':''}" data-plan="${esc(p.id)}">${p.minutes}<small> min</small></button>`).join('')}</div>${accountOptions(cost+v.deposit)}<div class="amount"><span>Available balance</span><span>${money(d.accounts?.[state.account])}</span></div><div class="amount"><span>Rental fee</span><span>${money(cost)}</span></div><div class="amount"><span>Refundable deposit</span><span>${money(v.deposit)}</span></div><div class="amount total"><span>TOTAL</span><strong>${money(cost+v.deposit)}</strong></div>${blockNote}<button class="primary" data-action="rent" ${blocked?'disabled':''}>Reserve & launch ↗</button><p class="note">Return your empty vessel at a compatible bay. Damage or late charges may reduce the deposit.</p></div></div>`;
}
function activeView(){
    const r=state.data.rental;
    if(!r)return '<h1>No active rental.</h1><p>Your next trip starts from the rental catalog.</p>';
    return `<div class="eyebrow">YOUR RESERVATION</div><h1>${esc(state.vehicles.find(v=>v.id===r.vehicleId)?.label||r.vehicleId)}</h1><div class="hero"><span class="tag">${esc(r.phase||'ACTIVE')}</span><img src="${image(r.vehicleId)}" alt="Rented vessel"></div><div class="stats"><div class="stat"><small>Registration</small><strong>${esc(r.plate||'Preparing')}</strong></div><div class="stat"><small>Return by</small><strong>${r.expiresAt?new Date(r.expiresAt*1000).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'}):'On handover'}</strong></div><div class="stat"><small>Deposit</small><strong>${money(r.deposit)}</strong></div></div><p>Park near the launch bay, leave the vessel and press E to return. You can also request a return here.</p><button class="primary" data-action="return" ${r.phase!=='active'?'disabled':''}>Return my vessel ↗</button>`;
}
function overview(){
    const b=state.data.business;
    const days=Array.from({length:7},(_,i)=>{const d=new Date();d.setDate(d.getDate()-6+i);d.setHours(0,0,0,0);return {at:+d,value:0,label:d.toLocaleDateString('en',{weekday:'short'})};});
    for(const row of b.history||[]){if(row.amount>0&&['rental','rental_income','rent'].includes(row.kind)){const at=row.at>1e12?row.at:row.at*1000;const day=days.find(d=>at>=d.at&&at<d.at+86400000);if(day)day.value+=row.amount;}}
    const max=Math.max(1,...days.map(d=>d.value));
    return `<div class="eyebrow">BUSINESS OVERVIEW / ${esc(b.role)}</div><h1>A good day on the coast.</h1><div class="stats"><div class="stat"><small>Business balance</small><strong>${money(b.balance)}</strong></div><div class="stat"><small>Lifetime earnings</small><strong>${money(b.earnings)}</strong></div><div class="stat"><small>Rental bookings</small><strong>${b.rentalCount||0}</strong></div></div><div class="panels"><div class="panel"><h2>Rental income · last 7 days</h2><div class="chart">${days.map(d=>`<div class="bar" style="height:${Math.max(2,d.value/max*100)}%" title="${money(d.value)}"><span>${d.label}</span></div>`).join('')}</div><small>Based on the retained transaction history.</small></div><div class="panel"><h2>Your fleet, at a glance.</h2>${(b.fleet||[]).map(v=>`<div class="row"><span class="grow">${esc(v.label)}</span><strong>${v.available||0}</strong><small>available / ${v.stock||0}</small></div>`).join('')}</div></div><div class="row"><span class="grow"><h2>Shape your marina.</h2><small>Add docks, railings and launch bays.</small></span>${state.data.canBuild?'<button class="primary" data-action="build">Open marina builder ↗</button>':''}</div>`;
}
function fleetView(){return `<div class="eyebrow">FLEET MANAGEMENT</div><h1>Keep your marina moving.</h1><p>Purchase vessels with the business balance. Service damaged or empty stock before renting it again.</p><div class="fleet">${(state.data.business.fleet||[]).map(v=>`<article class="fleet-item"><div class="row"><img src="${image(v.id)}" alt="${esc(v.label)}"><div class="grow"><h2>${esc(v.label)}</h2><small>${v.available} available · ${v.rented} rented · ${v.maintenance} service · ${v.stock} total</small></div><span class="tag">${v.enabled?'ENABLED':'PAUSED'}</span></div><form class="fleet-controls" data-fleet="${esc(v.id)}">${state.data.business.canEdit?`<label>Base rental price<input name="price" type="number" min="0" max="1000000" value="${v.price}" required></label><button type="submit">Save price</button><button type="button" data-fleet-buy="${esc(v.id)}">Buy vessel · ${money(v.purchasePrice)}</button>`:''}<button type="button" data-service="fleetRepair" data-id="${esc(v.id)}">Repair</button><button type="button" data-service="fleetRefuel" data-id="${esc(v.id)}">Refuel</button>${state.data.business.canEdit?`<button type="button" data-toggle="${esc(v.id)}" data-enabled="${!v.enabled}">${v.enabled?'Pause':'Enable'}</button>`:''}</form></article>`).join('')}</div>`;}
function financeView(){return `<div class="eyebrow">TREASURY</div><h1>Your business account.</h1><div class="stats"><div class="stat"><small>Available</small><strong>${money(state.data.business.balance)}</strong></div><div class="stat"><small>Earned</small><strong>${money(state.data.business.earnings)}</strong></div><div class="stat"><small>Personal bank</small><strong>${money(state.data.accounts?.bank)}</strong></div></div><form id="finance" class="form-grid panel"><label>Amount<input name="amount" type="number" min="1" max="1000000" required></label><label>Personal account<select name="account"><option value="bank">Bank</option><option value="cash">Cash</option></select></label><button name="operation" value="deposit">Deposit into business</button>${state.data.business.owner?.isYou?'<button name="operation" value="withdraw" class="primary">Withdraw to personal account</button>':''}</form><h2>Transaction history</h2>${historyView()}`;}
function historyView(){return (state.data.business.history||[]).slice(0,40).map(r=>`<div class="row"><div class="grow">${esc(r.kind.replaceAll('_',' '))}<small>${esc(r.detail||'')} · ${new Date(r.at>1e12?r.at:r.at*1000).toLocaleString()}</small></div><strong class="${r.amount>=0?'positive':'negative'}">${r.amount>=0?'+':''}${money(r.amount)}</strong></div>`).join('')||'<p>No transactions yet.</p>';}
function staffView(){return `<div class="eyebrow">YOUR TEAM</div><h1>Run it together.</h1><form id="staff" class="form-grid panel"><label>Online player server ID<input name="target" type="number" min="1" required></label><label>Role<select name="role"><option value="staff">Staff · service fleet</option>${state.data.business.owner?.isYou?'<option value="manager">Manager · prices, fleet & building</option>':''}</select></label><button class="primary full">Add employee</button></form><h2>Employees</h2>${(state.data.business.employees||[]).map(e=>`<div class="row"><div class="grow">${esc(e.name||e.identity)}<small>${esc(e.role)} · ${e.online?'Online':'Offline'}</small></div><button class="danger" data-fire="${esc(e.identity)}">Remove</button></div>`).join('')||'<p>No employees yet.</p>'}`;}
function settingsView(){return `<div class="eyebrow">BUSINESS SETTINGS</div><h1>The details matter.</h1><form id="business-settings" class="form-grid panel"><label class="full">Marina name<input name="name" maxlength="48" value="${esc(state.data.marina.name)}" required></label><button class="primary full">Save business settings</button></form>${state.data.business.owner?.isYou?`<h2>Ownership</h2><form id="transfer" class="form-grid panel"><label>New owner's online server ID<input name="target" type="number" min="1" required></label><button class="danger" type="submit">${state.confirm==='transfer'?'Confirm ownership transfer':'Transfer ownership'}</button></form><div class="row"><p class="grow">Sell this marina back to the server. Active rentals must be returned first.</p><button class="danger" data-sell>${state.confirm==='sell'?'Confirm sale':'Sell business'}</button></div>`:''}`;}
function buyView(){
    const price=state.data.marina.purchasePrice;
    pickAccount(price);
    return `<div class="eyebrow">OWN A PIECE OF THE COAST</div><h1>Your marina. Your business.</h1><div class="hero"><img src="assets/marina.png" alt="Marina"></div><p>Set rental prices, buy your fleet, hire a team and expand your waterfront.</p>`+
        accountOptions(price)+
        `<div class="amount total"><span>BUSINESS PURCHASE</span><strong>${money(price)}</strong></div><button class="primary" data-action="buy">Purchase with ${esc(state.account)} ↗</button>`;
}
// The default payment account is whichever one can cover the price. Defaulting to
// the bank told players with cash on hand that they had no money.
function pickAccount(cost){
    if(state.accountPicked)return state.account;
    const accounts=state.data?.accounts||{};
    const names=Object.keys(accounts);
    if(!names.length)return state.account;
    const afford=names.filter(n=>(accounts[n]||0)>=cost);
    const pool=afford.length?afford:names;
    state.account=pool.reduce((best,n)=>(accounts[n]||0)>(accounts[best]||0)?n:best,pool[0]);
    return state.account;
}
function accountOptions(cost){
    const accounts=state.data?.accounts||{cash:0,bank:0};
    return `<div class="section-label">PAYMENT ACCOUNT</div><div class="options">`+
        Object.entries(accounts).map(([k,v])=>`<button data-account="${esc(k)}" class="${k===state.account?'selected':''}">${esc(k.toUpperCase())}<small> ${money(v)}</small></button>`).join('')+
        `</div>`+((accounts[state.account]||0)<cost?`<p class="note">This account cannot cover ${money(cost)}.</p>`:'');
}
function render(){
    if(!state.data)return idle();const d=state.data;
    const tabs=[['rent','Rent a vessel'],['rental','My rental']];
    if(d.business){tabs.push(['overview','Overview'],['fleet','Fleet']);if(d.business.canEdit)tabs.push(['finance','Finance'],['staff','Team'],['settings','Settings']);}
    if(d.canBuy)tabs.push(['buy','Buy this marina']);
    if(!tabs.some(t=>t[0]===state.tab))state.tab='rent';
    const views={rent:rentView,rental:activeView,overview,fleet:fleetView,finance:financeView,staff:staffView,settings:settingsView,buy:buyView};
    root.innerHTML=`<header><div class="brand">${esc(state.display.brand)}</div><div><div class="eyebrow">${esc(d.marina.name)}</div><div class="subtitle">${esc(state.display.subtitle)}</div></div><div class="grow"></div><span class="tag">${d.station?.kind==='jetski'?'CAPSULE':'HANGAR'}</span><button class="close" data-action="close">×</button></header><nav>${tabs.map(([id,label])=>`<button data-tab="${id}" class="${state.tab===id?'selected':''}">${label}</button>`).join('')}</nav><div class="body">${views[state.tab]()}<div class="feedback" role="status"></div></div><footer><span>ALLGAMERS / WATERFRONT EXPERIENCES</span><span>SECURE TERMINAL · ESC TO CLOSE</span></footer>`;
}
root.addEventListener('click',event=>{
    const b=event.target.closest('button');if(!b||state.busy)return;
    if(b.dataset.tab){state.tab=b.dataset.tab;state.confirm=null;render();}
    else if(b.dataset.vehicle){state.vehicle=b.dataset.vehicle;render();}
    else if(b.dataset.plan){state.plan=b.dataset.plan;render();}
    else if(b.dataset.account){state.account=b.dataset.account;state.accountPicked=true;render();}
    else if(b.dataset.action){const a=b.dataset.action;act(a,a==='rent'?{vehicleId:state.vehicle,planId:state.plan,account:state.account}:a==='buy'?{account:state.account}:{});}
    else if(b.dataset.fleetBuy)business('fleetBuy',{vehicleId:b.dataset.fleetBuy,count:1});
    else if(b.dataset.service)business(b.dataset.service,{vehicleId:b.dataset.id,count:1});
    else if(b.dataset.toggle)business('settings',{enabled:{[b.dataset.toggle]:b.dataset.enabled==='true'}});
    else if(b.dataset.fire)business('employeeRemove',{identity:b.dataset.fire});
    else if(b.hasAttribute('data-sell')){if(state.confirm==='sell')business('sell',{account:'bank'});else{state.confirm='sell';render();}}
});
root.addEventListener('submit',event=>{
    event.preventDefault();const form=event.target,f=new FormData(form);
    if(form.dataset.fleet)business('settings',{prices:{[form.dataset.fleet]:Number(f.get('price'))}});
    else if(form.id==='finance')business(event.submitter?.value||'deposit',{amount:Number(f.get('amount')),account:f.get('account')});
    else if(form.id==='staff')business('employeeAdd',{target:Number(f.get('target')),role:f.get('role')});
    else if(form.id==='business-settings')business('settings',{name:f.get('name')});
    else if(form.id==='transfer'){if(state.confirm==='transfer')business('transfer',{target:Number(f.get('target'))});else{state.confirm='transfer';form.querySelector('button').textContent='Confirm ownership transfer';}}
});
let field=null;
root.addEventListener('focusin',e=>{if(e.target.matches('input,textarea')){field=e.target;post('duiTextFocus',{value:field.value,selection:field.selectionStart??field.value.length});}});
window.addEventListener('message',event=>{
    const d=event.data;
    if(d.display){state.display={...state.display,...d.display};document.documentElement.style.setProperty('--accent',state.display.accent);}
    if(d.action==='config')idle();
    if(d.action==='idle'){state.data=null;state.tab='rent';idle();}
    if(d.action==='menu'){state.data=d.data;state.vehicles=d.vehicles||state.vehicles;state.plans=d.plans||state.plans;state.busy=false;render();}
    if(d.action==='text'&&field&&field.isConnected){field.value=d.value;try{field.setSelectionRange(d.selection,d.selection);}catch{}field.dispatchEvent(new Event('input',{bubbles:true}));}
    if(d.action==='key'&&field){if(d.key==='Enter')field.form?.requestSubmit();if(d.key==='Tab'){const fields=[...root.querySelectorAll('input,select,button')];const i=fields.indexOf(field);fields[(i+(d.shift?-1:1)+fields.length)%fields.length]?.focus();}}
});
idle();post('duiReady',{kind});

const FORMS_ROOT=document.querySelector('#terminal');
function enhanceForms(scope){
    scope.querySelectorAll('select:not([data-enhanced])').forEach(sel=>{
        sel.dataset.enhanced='1';sel.classList.add('native-hidden');
        const dd=document.createElement('div');dd.className='dd';dd.tabIndex=0;
        const btn=document.createElement('div');btn.className='dd-btn';
        const list=document.createElement('div');list.className='dd-list';
        const label=()=>{btn.innerHTML=`<span>${esc(sel.options[sel.selectedIndex]?.text||'')}</span><i class="dd-chev"></i>`;};
        Array.from(sel.options).forEach(o=>{const it=document.createElement('div');it.className='dd-item'+(o.selected?' on':'');it.textContent=o.text;
            it.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();sel.value=o.value;sel.dispatchEvent(new Event('change',{bubbles:true}));list.querySelectorAll('.dd-item').forEach(x=>x.classList.toggle('on',x===it));label();dd.classList.remove('open');});
            list.appendChild(it);});
        btn.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();document.querySelectorAll('.dd.open').forEach(x=>x!==dd&&x.classList.remove('open'));const open=!dd.classList.contains('open');dd.classList.toggle('open',open);if(open){const r=btn.getBoundingClientRect();const room=window.innerHeight-r.bottom;list.style.left=r.left+'px';list.style.width=r.width+'px';if(room<240&&r.top>room){list.style.top='auto';list.style.bottom=(window.innerHeight-r.top+3)+'px';}else{list.style.bottom='auto';list.style.top=(r.bottom+3)+'px';}}});
        label();dd.append(btn,list);sel.parentNode.insertBefore(dd,sel.nextSibling);const lb=sel.closest('label');if(lb)lb.classList.add('has-widget');
    });
    scope.querySelectorAll('input[type="number"]:not([data-enhanced])').forEach(inp=>{
        inp.dataset.enhanced='1';
        const wrap=document.createElement('div');wrap.className='stepper';
        inp.parentNode.insertBefore(wrap,inp);wrap.appendChild(inp);
        const mk=(t,fn)=>{const b=document.createElement('button');b.type='button';b.className='step';b.textContent=t;b.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();fn();inp.dispatchEvent(new Event('input',{bubbles:true}));inp.dispatchEvent(new Event('change',{bubbles:true}));b.blur();});return b;};
        wrap.insertBefore(mk('−',()=>inp.stepDown()),inp);wrap.appendChild(mk('+',()=>inp.stepUp()));const lb=inp.closest('label');if(lb)lb.classList.add('has-widget');
    });
}
document.addEventListener('click',e=>{if(e.target&&e.target.closest&&e.target.closest('.dd'))return;document.querySelectorAll('.dd.open').forEach(x=>x.classList.remove('open'));});
document.addEventListener('scroll',()=>document.querySelectorAll('.dd.open').forEach(x=>x.classList.remove('open')),true);
new MutationObserver(()=>enhanceForms(FORMS_ROOT)).observe(FORMS_ROOT,{childList:true,subtree:true});
enhanceForms(FORMS_ROOT);
