-- Explicit, manifest-loaded RPC; never executes client-supplied code.
MarinaRPC = {}
local handlers, pending, windows = {}, {}, {}
local server = IsDuplicityVersion()
local resource = GetCurrentResourceName()
local sequence = 0
local requestEvent, replyEvent = resource .. ':rpc', resource .. ':reply'

function MarinaRPC.register(action, handler)
    assert(server and type(action) == 'string' and type(handler) == 'function')
    handlers[action] = handler
end

if server then
    RegisterNetEvent(requestEvent, function(id, action, payload)
        local src = source
        if src <= 0 or type(id) ~= 'number' or id % 1 ~= 0 or id < 1 or id > 2147483647 then return end
        if type(action) ~= 'string' or not handlers[action] or type(payload) ~= 'table' then return end
        local now = GetGameTimer()
        local window = windows[src]
        if not window or now - window.at > 1000 then window = { at = now, count = 0 }; windows[src] = window end
        window.count = window.count + 1
        if window.count > 15 then
            TriggerClientEvent(replyEvent, src, id, { ok = false, error = 'Please wait before trying again.', code = 'rate_limit' })
            return
        end
        local ok, result = pcall(handlers[action], src, payload)
        if not ok then
            print(('[%s] %s: %s'):format(resource, action, tostring(result)))
            result = { ok = false, error = 'The marina service is unavailable. Try again.', code = 'internal_error' }
        end
        TriggerClientEvent(replyEvent, src, id, result or { ok = false, error = 'No response from marina.' })
    end)
    AddEventHandler('playerDropped', function() windows[source] = nil end)
else
    function MarinaRPC.call(action, payload)
        sequence = sequence % 2147483647 + 1
        local id, promiseObject = sequence, promise.new()
        pending[id] = promiseObject
        SetTimeout(20000, function()
            if pending[id] == promiseObject then
                pending[id] = nil
                promiseObject:resolve({ ok = false, code = 'timeout', error = 'Connection timed out. Please try again.' })
            end
        end)
        TriggerServerEvent(requestEvent, id, action, payload or {})
        return Citizen.Await(promiseObject)
    end
    RegisterNetEvent(replyEvent, function(id, value)
        if source ~= 65535 or not pending[id] then return end
        local p = pending[id]
        pending[id] = nil
        p:resolve(value)
    end)
end
