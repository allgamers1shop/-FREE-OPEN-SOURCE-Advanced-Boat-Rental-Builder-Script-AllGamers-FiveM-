MarinaAssets = { catalog = {}, assemblies = {} }
local M = MarinaAssets
local resource = GetCurrentResourceName()

local function load(name)
    local raw = LoadResourceFile(resource, 'data/' .. name .. '.json')
    assert(raw, 'Missing marina data: ' .. name)
    return json.decode(raw)
end

local manifest, snaps = load('asset_manifest'), load('snap_points')
M.animations = load('animation_points')
local layout = load('assembled_layout')
for _, entry in ipairs(manifest.assets) do
    local sockets = snaps.assets[entry.asset_name] or {}
    -- Author metadata is clockwise; GTA headings are counter-clockwise.
    for _, socket in ipairs(sockets) do socket.heading = (-socket.heading) % 360 end
    local min, max = entry.aabb_local_m.min, entry.aabb_local_m.max
    if (entry.category == 'floor' or entry.category == 'coast')
        and not entry.asset_name:find('ramp', 1, true) and not entry.asset_name:find('triangle', 1, true)
        and not entry.asset_name:find('round', 1, true) then
        local present = {}
        for _, socket in ipairs(sockets) do
            if socket.type == 'structure' then present[math.floor(socket.heading / 90 + 0.5) % 4] = true end
        end
        local sides = {
            { 0, 'N', 0.0, max[2] }, { 1, 'W', min[1], 0.0 }, { 2, 'S', 0.0, min[2] }, { 3, 'E', max[1], 0.0 },
        }
        for _, side in ipairs(sides) do
            if not present[side[1]] then
                sockets[#sockets + 1] = { name = 'SNAP_' .. side[2] .. '_X', type = 'structure',
                    x = side[3], y = side[4], z = 0.0, heading = side[1] * 90 }
            end
        end
    end
    M.catalog[entry.asset_name] = {
        id = entry.asset_name,
        model = entry.asset_name,
        label = entry.asset_name:gsub('ff_marina_', ''):gsub('_', ' '),
        category = entry.category,
        bounds = { min = { x = min[1], y = min[2], z = min[3] }, max = { x = max[1], y = max[2], z = max[3] } },
        sockets = sockets,
        image = 'assets/' .. entry.asset_name .. '.png',
    }
end

for kind, prefix in pairs({ jetski = 'capsule', boat = 'hangar' }) do
    local parts, root = {}, layout[prefix .. '_root']
    for _, part in ipairs(layout.static_instances) do
        if part.model:find('ff_marina_' .. prefix .. '_', 1, true) then
            parts[#parts + 1] = {
                model = part.model,
                position = { part.position[1] - root[1], part.position[2] - root[2], part.position[3] - root[3] },
                quaternion_wxyz = part.quaternion_wxyz,
            }
        end
    end
    M.assemblies[kind] = parts
end

-- What the creator previews for a whole station: the static instances plus the
-- moving parts the streamer spawns from the first animation sample. Preview only;
-- MarinaWorld keeps spawning the two lists separately so nothing is doubled.
M.preview = {}
for kind, prefix in pairs({ jetski = 'capsule', boat = 'hangar' }) do
    local parts = {}
    for _, part in ipairs(M.assemblies[kind] or {}) do parts[#parts + 1] = part end
    for model, part in pairs(M.animations.samples[1].parts) do
        if model:find('ff_marina_' .. prefix .. '_', 1, true) then
            parts[#parts + 1] = { model = model, position = part.position,
                quaternion_wxyz = part.quaternion_wxyz }
        end
    end
    M.preview[kind] = parts
end

function M.vehicle(id)
    for _, vehicle in ipairs(MarinaConfig.vehicles) do if vehicle.id == id then return vehicle end end
end

-- Keep the jet-ski attached to its cradle as it travels along the tilting ramp.
function M.rampAnchor(root, openness)
    local samples = M.animations.samples
    local frame = 1 + MarinaMath.clamp(openness,0,1) * (#samples-1)
    local low = math.floor(frame)
    local a = samples[low].parts.ff_marina_capsule_cradle
    local b = samples[math.min(low+1,#samples)].parts.ff_marina_capsule_cradle
    local q = MarinaMath.nlerp(a.quaternion_wxyz,b.quaternion_wxyz,frame-low)
    local initial = samples[1].parts.ff_marina_capsule_cradle.position
    local spawn = M.animations.capsule.SPAWN_JETSKI
    local offset = MarinaMath.rotate(q,{spawn[1]-initial[1],spawn[2]-initial[2],spawn[3]-initial[3]})
    for i=1,3 do offset[i]=offset[i]+MarinaMath.lerp(a.position[i],b.position[i],frame-low) end
    return MarinaMath.world(root,offset),math.deg(2*math.atan(q[2],q[1]))
end

function M.station(kind, root)
    local jetski = kind == 'jetski'
    local motion = jetski and M.animations.capsule or M.animations.hangar
    return {
        kind = kind,
        root = root,
        terminal = MarinaMath.world(root, { x = -2, y = -1, z = 0 }),
        spawn = MarinaMath.world(root, jetski and motion.SPAWN_JETSKI or motion.SPAWN_BOAT),
        exit = MarinaMath.world(root, jetski and motion.RELEASE_JETSKI or motion.EXIT_BOAT),
        pickup = MarinaMath.world(root, { x = jetski and -3 or -4.5, y = jetski and 5 or 17, z = 0 }),
        enabled = true,
    }
end
