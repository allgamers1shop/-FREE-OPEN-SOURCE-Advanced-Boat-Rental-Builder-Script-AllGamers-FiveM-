-- Pure coordinate helpers, shared by validation, editor and animation.
MarinaMath = {}
local M = MarinaMath

function M.finite(n)
    return type(n) == 'number' and n == n and math.abs(n) < math.huge
end

function M.distance(a, b)
    return math.sqrt((a.x - b.x)^2 + (a.y - b.y)^2 + (a.z - b.z)^2)
end

function M.world(root, p)
    local h = math.rad(root.heading or 0)
    local x, y, z = p.x or p[1] or 0, p.y or p[2] or 0, p.z or p[3] or 0
    return {
        x = root.x + x * math.cos(h) - y * math.sin(h),
        y = root.y + x * math.sin(h) + y * math.cos(h),
        z = root.z + z,
        heading = ((root.heading or 0) + (p.heading or 0)) % 360,
    }
end

function M.lerp(a, b, t)
    return a + (b - a) * t
end

function M.pointLerp(a, b, t)
    return { x = M.lerp(a.x, b.x, t), y = M.lerp(a.y, b.y, t), z = M.lerp(a.z, b.z, t) }
end

function M.clamp(n, lo, hi)
    return math.max(lo, math.min(hi, n))
end

function M.quaternion(root, q)
    local h = math.rad(root.heading or 0) / 2
    local c, s = math.cos(h), math.sin(h)
    return { c*q[1]-s*q[4], c*q[2]-s*q[3], c*q[3]+s*q[2], c*q[4]+s*q[1] }
end

function M.nlerp(a, b, t)
    local dot, out, length = 0, {}, 0
    for i = 1, 4 do dot = dot + a[i] * b[i] end
    for i = 1, 4 do
        out[i] = M.lerp(a[i], b[i] * (dot < 0 and -1 or 1), t)
        length = length + out[i]^2
    end
    length = math.sqrt(length)
    for i = 1, 4 do out[i] = out[i] / length end
    return out
end

-- Rotate a local point by a unit quaternion in author order w,x,y,z.
function M.rotate(q, p)
    local x,y,z = p[1],p[2],p[3]
    local tx = 2 * (q[3]*z-q[4]*y)
    local ty = 2 * (q[4]*x-q[2]*z)
    local tz = 2 * (q[2]*y-q[3]*x)
    return {x+q[1]*tx+q[3]*tz-q[4]*ty,
        y+q[1]*ty+q[4]*tx-q[2]*tz,
        z+q[1]*tz+q[2]*ty-q[3]*tx}
end

-- Rotate the child's selected socket to face back at the parent's socket.
function M.snap(parent, parentSocket, childSocket)
    local target = M.world(parent, parentSocket)
    local heading = (target.heading + 180 - childSocket.heading) % 360
    local offset = M.world({ x = 0, y = 0, z = 0, heading = heading }, childSocket)
    return { x = target.x - offset.x, y = target.y - offset.y, z = target.z - offset.z, heading = heading }
end
