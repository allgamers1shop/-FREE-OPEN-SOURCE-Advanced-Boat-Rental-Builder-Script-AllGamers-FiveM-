-- ALLGAMERS MARINA BUILDER
-- This file and both bridge files remain editable with Asset Escrow.
-- All prices below are IN-GAME currency. No ox_lib dependency is required.
MarinaConfig = {
    -- auto detects Qbox, QBCore, ESX, then falls back to standalone credits.
    framework = 'auto', -- auto | qbx | qb | esx | standalone | custom
    interaction = 'allgamers_ui', -- allgamers_ui | ox_lib | ox_target | qb-target | custom
    notify = 'allgamers_ui', -- allgamers_ui | ox_lib | native | custom
    keys = 'auto', -- auto | qbx | qb | none | custom
    debug = false,

    command = 'marinacreator',
    adminAce = 'allgamers.marina',
    adminGroups = { 'group.admin' },
    accounts = { 'cash', 'bank' },
    standalone = {
        startingCash = 10000,
        startingBank = 100000,
    },

    limits = {
        maxMarinas = 64,
        maxPieces = 300,
        maxStations = 16,
        buildRadius = 180.0,
        minMarinaGap = 30.0,
        maxEmployees = 20,
        maxPrice = 1000000,
        maxFleet = 50,
    },

    builder = {
        -- The player keeps the normal gameplay camera and controls. The preview is
        -- projected in front of the PLAYER, on the deck plane, never at eye height.
        placementDistance = 6.0,   -- default reach in metres; the preview follows the crosshair up to this
        minPlacementDistance = 2.5, -- never closer than this to the player
        wheelStep = 15.0,          -- degrees per mouse wheel notch (ALT + wheel = 5)
        maxPlacementDistance = 10.0,
        eyeHeight = 0.9,           -- used to aim closer when looking down
        snapDistance = 3.5,        -- horizontal reach of a socket, in metres
        snapDistanceDecor = 1.5,   -- tighter reach for rails, fenders and equipment
        occupiedDistance = 0.5,    -- identical pieces closer than this are a duplicate
        fineStep = 0.05,
        rotationStep = 90.0,
        defaultDeckAboveWater = 1.05,
        allowFreePlacement = true,
        showBounds = false,        -- draw a translucent box around the preview (off: outline + marker only)
    },

    -- Pure decoration: streamed without collision. A lifering, a hose reel or an
    -- overhead sign is a solid box in the model, and its box top sits above the
    -- railing, so a player who climbs the railing ends up standing in mid air on it.
    -- Remove a model from this list if you want it solid.
    -- The fenders are rubber bumpers: their collision box stands 25 cm proud of the
    -- deck, so walking along the edge lifts the player onto it and looks like hovering.
    noCollision = {
        'ff_marina_lifering',
        'ff_marina_hose_reel',
        'ff_marina_cleat',
        'ff_marina_sign_overhead',
        'ff_marina_fender_4m',
        'ff_marina_fender_corner',
        'ff_marina_hangar_interior_fender',
    },

    streaming = {
        radius = 240.0,
        hysteresis = 40.0,
        tickMs = 1000,
        maxObjects = 900,
        batchSize = 12,
    },

    rental = {
        interactionDistance = 4.0,
        returnDistance = 12.0,
        openingSeconds = 8,
        launchSeconds = 7,
        closingSeconds = 6,
        reservationTimeout = 45,
        maxPerPlayer = 1,
        damageFee = 500,
        repairCost = 1000,
        refuelCost = 200,
    },

    business = {
        defaultPurchasePrice = 100000,
        ownerShare = 1.0,
        sellBackFraction = 0.5,
        -- Public (non-ownable) marinas use a replenishing virtual fleet.
        publicStockPerModel = 10,
    },

    audio = {
        enabled = true,
        volume = 0.35,
        distance = 40.0,
        referenceDistance = 4.0,
        -- Reuses the mechanical sound family from AllGamers CapsuleRent.
        opening = 'rise_v3.ogg',
        launching = 'fork_out.ogg',
        returning = 'fork_in.ogg',
        closing = 'door_close_v2.ogg',
    },

    display = {
        brand = 'ALLGAMERS',
        subtitle = 'MARINA CLUB',
        accent = '#00e5b4',
        currency = '$',
        cameraDistance = 0.68,
        cameraFov = 40.0,
        -- Actual supplied screen is landscape, 0.46 x 0.365 metres.
        width = 1440,
        height = 1140,
        idleDrawDistance = 35.0,   -- metres within which idle tablet screens are drawn
        logo = 'logo/logo.png',    -- drawn on the overhead and pylon signs; delete the file to show the brand text instead
        -- On-screen rental timer while a boat is out. anchor: 'bottom-left', 'bottom-right',
        -- 'top-left', 'top-right', 'top-center' or 'bottom-center'. Offsets are screen percentages.
        rentalHud = { enabled = true, anchor = 'bottom-left', offsetX = 2.35, offsetY = 4.0 },
        -- Screen-plane coordinates are defined in client/dui.lua for this mesh.
    },

    -- Stock in owned businesses is purchased through the owner's tablet.
    -- originOffset is the model's vertical correction above its launch anchor.
    -- Model identifiers are allowlisted here; UI prices never authorize payment.
    vehicles = {
        {
            id = 'seashark', model = 'seashark', label = 'Speedophile Seashark',
            kind = 'jetski', price = 500, deposit = 1000,
            purchasePrice = 10000, maxWidth = 2.24,
            image = 'assets/seashark.webp', originOffset = 0.15,
        },
        {
            id = 'dinghy', model = 'dinghy', label = 'Nagasaki Dinghy',
            kind = 'boat', price = 1200, deposit = 2500,
            purchasePrice = 35000, maxWidth = 5.8,
            image = 'assets/dinghy.webp', originOffset = 0.0,
        },
        {
            id = 'speeder', model = 'speeder', label = 'Pegassi Speeder',
            kind = 'boat', price = 1800, deposit = 4000,
            purchasePrice = 55000, maxWidth = 5.8,
            image = 'assets/speeder.webp', originOffset = 0.0,
        },
    },

    plans = {
        { id = '30m', minutes = 30, multiplier = 1.0 },
        { id = '60m', minutes = 60, multiplier = 1.7 },
        { id = '120m', minutes = 120, multiplier = 2.8 },
    },
}
